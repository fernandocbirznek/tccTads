﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Fisica.Dados.Migrations
{
    /// <inheritdoc />
    public partial class droptagnoticia : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Tags",
                table: "Noticia");

            migrationBuilder.AddColumn<DateTime>(
                name: "DataAtualizacao",
                table: "Noticia",
                type: "timestamp with time zone",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<long>(
                name: "Visualizacao",
                table: "Noticia",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DataAtualizacao",
                table: "Noticia");

            migrationBuilder.DropColumn(
                name: "Visualizacao",
                table: "Noticia");

            migrationBuilder.AddColumn<string>(
                name: "Tags",
                table: "Noticia",
                type: "text",
                nullable: false,
                defaultValue: "");
        }
    }
}
