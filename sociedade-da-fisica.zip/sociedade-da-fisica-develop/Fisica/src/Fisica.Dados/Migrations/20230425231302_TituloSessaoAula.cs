﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Fisica.Dados.Migrations
{
    /// <inheritdoc />
    public partial class TituloSessaoAula : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_VisualizacaoAula_Usuario_UsuarioId",
                table: "VisualizacaoAula");

            migrationBuilder.AlterColumn<long>(
                name: "UsuarioId",
                table: "VisualizacaoAula",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AddColumn<string>(
                name: "Titulo",
                table: "SessaoAula",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddForeignKey(
                name: "FK_VisualizacaoAula_Usuario_UsuarioId",
                table: "VisualizacaoAula",
                column: "UsuarioId",
                principalTable: "Usuario",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_VisualizacaoAula_Usuario_UsuarioId",
                table: "VisualizacaoAula");

            migrationBuilder.DropColumn(
                name: "Titulo",
                table: "SessaoAula");

            migrationBuilder.AlterColumn<long>(
                name: "UsuarioId",
                table: "VisualizacaoAula",
                type: "bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_VisualizacaoAula_Usuario_UsuarioId",
                table: "VisualizacaoAula",
                column: "UsuarioId",
                principalTable: "Usuario",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
