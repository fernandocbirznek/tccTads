﻿using Dapper;
using Fisica.Domains;
using Fisica.Interfaces;
using Fisica.Models;
using System.Security.Cryptography;
using System.Text;
using SHA256Managed = System.Security.Cryptography.SHA256Managed;

namespace Fisica.Dados.Repositories
{
    public static class RepositoryUsuarioExtension
    {
        public static string ObterHash(this IRepository<Usuario> repository, string senha, string salt)
        {
            return Sha256(senha + salt);
        }

        public static void CriptografarSenha(this IRepository<Usuario> repository, Usuario usuario)
        {
            string salt = CreateSalt();

            string hash = Sha256(usuario.Senha + salt);

            usuario.Senha = hash;
            usuario.Salt = salt;
        }

        private static string CreateSalt()
        {
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            byte[] buff = new byte[32];
            rng.GetBytes(buff);
            return Convert.ToBase64String(buff);
        }

        private static string Sha256(string randomString)
        {
            var crypt = new SHA256Managed();
            string hash = String.Empty;
            byte[] crypto = crypt.ComputeHash(Encoding.ASCII.GetBytes(randomString));
            foreach (byte theByte in crypto)
            {
                hash += theByte.ToString("x2");
            }
            return hash;
        }

        public static async Task<int> ObterQuantidadeUsuarios(this IRepository<Usuario> repository, int tipoUsuario)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""Usuario"" u
                            WHERE u.""TipoUsuario"" = :TipoUsuario
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { TipoUsuario = tipoUsuario });
        }

        public static async Task<IEnumerable<UsuarioComumModel>> ObterUsuariosSistema(this IRepository<Usuario> repository)
        {
            string sql = @"
                            select u.""Id"" as Id,
                            u.""TipoUsuario"" as TipoUsuario,
                            u.""Nome"" as Nome,
                            (
 	                           select count(*)
 	                           from ""ComentarioAula"" ca 
 	                           inner join ""Usuario"" u2 on (ca.""UsuarioId"" = u2.""Id"")
 	                           where u2.""Id"" = u.""Id"" 
                            ) as Comentario,
                            (
 	                           select count(*)
 	                           from ""Favorito"" f
 	                           inner join ""Usuario"" u2 on (f.""UsuarioId"" = u2.""Id"")
 	                           where u2.""Id"" = u.""Id"" 
 	                           and f.""AulaId"" is not null
                            ) as aulasFavoritadas,
                            (
 	                            select count(*)
 	                            from ""TopicoForum"" tf 
 	                            inner join ""Usuario"" u2 on (tf.""UsuarioId""  = u2.""Id"")
	                            where u2.""Id"" = u.""Id"" 
                             ) as Topico
                            from ""Usuario"" u 
                            where u.""TipoUsuario"" = 1
 
                          ";

            return await repository.Connection.QueryAsync<UsuarioComumModel>(sql);
        }

        public static async Task<IEnumerable<UsuarioProfessorModel>> ObterProfessorsSistema(this IRepository<Usuario> repository)
        {
            string sql = @"
                             select u.""Id"" as Id,
                             u.""Nome"" as Nome,
                             u.""TipoUsuario"" as TipoUsuario,
                             (
 	                            select count(*)
 	                            from ""ComentarioAula"" ca 
 	                            inner join ""Usuario"" u2 on (ca.""UsuarioId"" = u2.""Id"")
 	                            where u2.""Id"" = u.""Id"" 
                             ) as Comentario,
                             (
 	                            select count(*)
 	                            from ""Aula"" a
 	                            inner join ""Usuario"" u2 on (a.""ProfessorId"" = u2.""Id"")
 	                            where u2.""Id"" = u.""Id"" 
 	                            and  a.""ProfessorId"" = u.""Id"" 
                             ) as Aulas,
                             (
 	                            select count(*)
 	                            from ""TopicoForum"" tf 
 	                            inner join ""Usuario"" u2 on (tf.""UsuarioId""  = u2.""Id"")
	                            where u2.""Id"" = u.""Id"" 
                             ) as Topico
                             from ""Usuario"" u 
                             where u.""TipoUsuario"" in (2, 3)
                          ";

            return await repository.Connection.QueryAsync<UsuarioProfessorModel>(sql);
        }
    }
}
