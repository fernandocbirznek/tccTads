﻿using Dapper;
using Fisica.Domains;
using Fisica.Interfaces;
using Fisica.Models;

namespace Fisica.Dados.Repositories
{
    public static class RepositoryNoticiaExtensions
    {
        public static async Task<IEnumerable<NoticiaModel>> ObterUltimasNoticias(this IRepository<Noticia> repository)
        {
            string sql = @"
                            SELECT  n.Conteudo as Conteudo,
                                    n.DataCadastro as DataCadastro,
                                    u.Nome as AutorNome
                            FROM Noticia n
                            INNER JOIN Usuario u ON (u.Id = n.AutorId)
                            ORDER BY n.DataCadastro
                            LIMIT 10
                          ";

            return await repository.Connection.QueryAsync<NoticiaModel>(sql);
        }

        public static async Task<int> ObterQuantidadeNoticiasPostadas(this IRepository<Noticia> repository, long usuarioId)
        {
            string sql = @"
                            SELECT COUNT(*)
                            FROM ""Noticia"" n
                            WHERE n.""AutorId"" = :UsuarioId
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }

        public static async Task<int> ObterQuantidadeNoticias(this IRepository<Noticia> repository)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""Noticia""
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql);
        }
    }
}
