﻿using Dapper;
using Fisica.Domains;
using Fisica.Interfaces;

namespace Fisica.Dados.Repositories
{
    public static class RepositoryFavoritoExtensions
    {
        public static async Task<int> ObterQuantidadeFavoritos(this IRepository<Favorito> repository, long usuarioId)
        {
            string sql = @"
                            SELECT COUNT(*)
                            FROM ""Favorito"" f
                            WHERE f.""UsuarioId"" = :UsuarioId 
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }

        public static async Task<bool> SessaoFavorita(this IRepository<Favorito> repository, long usuarioId, long sessaoAulaId)
        {
            string sql = @"
	                        SELECT Count(*) 
	                        FROM ""Favorito"" f 
                            WHERE ""SessaoAulaId"" = :SessaoAulaId  
                                AND ""UsuarioId"" = :UsuarioId
                            ";

            return (await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId, SessaoAulaId = sessaoAulaId })) > 0;
        }
    }
}
