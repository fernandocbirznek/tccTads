﻿using Dapper;
using Fisica.Domains;
using Fisica.Interfaces;

namespace Fisica.Dados.Repositories
{
    public static class RepositoryComentarioAulaExtensions
    {
        public static async Task<int> ObterQuantidadeComentariosAulas(this IRepository<ComentarioAula> repository)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""ComentarioAula""
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql);
        }
    }
}
