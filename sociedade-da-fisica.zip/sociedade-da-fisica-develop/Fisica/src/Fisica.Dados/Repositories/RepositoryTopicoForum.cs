﻿using Dapper;
using Fisica.Domains;
using Fisica.Interfaces;
using Fisica.Models;

namespace Fisica.Dados.Repositories
{
    public static class RepositoryTopicoForum
    {
        public static async Task<IEnumerable<TopicoForumModel>> ObterTopicosByForum(this IRepository<TopicoForum> repository, long forumId)
        {
            string select = @"
                            SELECT  t.""Id"" as Id,
                                    t.""Titulo"" as Titulo,
                                    t.""Descricao"" as Descricao,
                                    t.""DataCadastro"" as DataCadastro,
                                    u.""Nome"" as UsuarioCadastro,
                                    (
                                        SELECT COUNT(*)
                                        FROM ""RespostaTopico"" r
                                        WHERE r.""TopicoForumId"" = t.""Id""
                                    ) as QuantidadeRespostas
                            FROM ""TopicoForum"" t
                            INNER JOIN ""Usuario"" u ON (u.""Id"" = t.""UsuarioId"")
                            WHERE t.""ForumId"" = :ForumId
                            ";

            return await repository.Connection.QueryAsync<TopicoForumModel>(select, new { ForumId = forumId });
        }

        public static async Task<int> ObterQuantidadeTopicos(this IRepository<TopicoForum> repository, long usuarioId)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""TopicoForum"" t
                            WHERE t.""UsuarioId"" = :UsuarioId
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }

        public static async Task<int> ObterQuantidadeRespostas(this IRepository<TopicoForum> repository, long usuarioId)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""RespostaTopico"" r
                            WHERE r.""UsuarioId"" = :UsuarioId
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }

        public static async Task<int> ObterQuantidadeTopicos(this IRepository<TopicoForum> repository)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""TopicoForum""
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql);
        }
    }
}
