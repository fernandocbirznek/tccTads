﻿using Dapper;
using Fisica.Domains;
using Fisica.Interfaces;

namespace Fisica.Dados.Repositories
{
    public static class RepositoryWidgetExtension
    {
        public static async Task<int> ObterQuantidadeParaCursar(this IRepository<Widget> repository, long usuarioId)
        {
            string sql = @"
                            SELECT COUNT(*)
                            FROM ""WidgetAula"" wa
                                INNER JOIN ""Widget"" w ON (w.""Id"" = wa.""WidgetId"")
                            WHERE w.""UsuarioId"" = :UsuarioId 
                                AND w.""Descricao"" = 'Para Cursar'
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }

        public static async Task<int> ObterQuantidadeCursando(this IRepository<Widget> repository, long usuarioId)
        {
            string sql = @"
                            SELECT COUNT(*)
                            FROM ""WidgetAula"" wa
                                INNER JOIN ""Widget"" w ON (w.""Id"" = wa.""WidgetId"")
                            WHERE w.""UsuarioId"" = :UsuarioId 
                                AND w.""Descricao"" = 'Cursando'
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }

        public static async Task<int> ObterQuantidadeConcluidas(this IRepository<Widget> repository, long usuarioId)
        {
            string sql = @"
                            SELECT COUNT(*)
                            FROM ""WidgetAula"" wa
                                INNER JOIN ""Widget"" w ON (w.""Id"" = wa.""WidgetId"")
                            WHERE w.""UsuarioId"" = :UsuarioId 
                                AND w.""Descricao"" = 'Concluídas'
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }
    }
}
