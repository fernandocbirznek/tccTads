﻿using Dapper;
using Fisica.Domains;
using Fisica.Interfaces;
using Fisica.Models;

namespace Fisica.Dados.Repositories
{
    public static class RepositoryAulaExtensions
    {
        public static async Task<int> ObterQuantidadeAulasPostadas(this IRepository<Aula> repository, long usuarioId)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""Aula"" a
                            WHERE a.""ProfessorId"" = :UsuarioId
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }

        public static async Task<int> ObterQuantidadeAulasAcessadas(this IRepository<Aula> repository, long usuarioId)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""VisualizacaoAula"" v
                            WHERE v.""UsuarioId"" = :UsuarioId
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }

        public static async Task<IEnumerable<AulaModel>> ObterAulasPorAreaFisica(this IRepository<Aula> repository, long areaFisicaId)
        {
            string sql = @"
                            SELECT  a.""Id"",
                                    a.""Titulo"" as Titulo,
                                    a.""Descricao"" as Descricao,
                                    TO_CHAR(a.""DataCadastro"", 'dd/MM/yyyy HH:mm') as DataCadastroExtenso,
                                    u.""Nome"" as ProfessorNome,
                                    u.""Id"" as ProfessorId,
                                    u.""Login"" as ProfessorLogin,
                                    (
        	                            SELECT Count(*)
        	                            FROM ""VisualizacaoAula"" va 
        	                            WHERE va.""AulaId"" = a.""Id"" 
                                    ) as Visualizacoes,
                                    (
                                        SELECT STRING_AGG (""Conteudo"" || ' ' || ""Titulo"",' ') 
                                        FROM ""SessaoAula"" sa 
                                        WHERE sa.""AulaId"" = a.""Id""
                                        AND sa.""TipoSessao"" IN (1,2,5)
                                    ) as ConteudoPesquisa
                            FROM ""Aula"" a
                                INNER JOIN ""Usuario"" u ON (u.""Id"" = a.""ProfessorId"")
                            WHERE a.""AreaFisicaId"" = :AreaFisicaId
                          ";

            return await repository.Connection.QueryAsync<AulaModel>(sql, new { AreaFisicaId = areaFisicaId });
        }

        public static async Task<IEnumerable<AulaModel>> ObterAulaPorTitulo(this IRepository<Aula> repository, string conteudo)
        {
            string sql = @"

                            SELECT  a.""Id"",
                                    a.""Titulo"" as Titulo,
                                    a.""Descricao"" as Descricao,
                                    TO_CHAR(a.""DataCadastro"", 'dd/MM/yyyy') as DataCadastroExtenso,
                                    u.""Nome"" as ProfessorNome,
                                    u.""Id"" as ProfessorId,
                                    u.""Login"" as ProfessorLogin
                            FROM ""Aula"" a
                                INNER JOIN ""Usuario"" u ON (u.""Id"" = a.""ProfessorId"")
                            WHERE a.""Titulo"" LIKE :Conteudo
                          ";

            return await repository.Connection.QueryAsync<AulaModel>(sql, new { Conteudo = "%" + conteudo + "%" });

        }

        public static async Task<int> ObterQuantidadeAulasSistema(this IRepository<Aula> repository)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""VisualizacaoAula""
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql);
        }

        public static async Task<IEnumerable<AulaProfessorModel>> ObterAulasProfessor(this IRepository<Aula> repository, long professorId)
        {
            string sql = @"
                            select a.""Id"" as Id,
                            a.""Titulo"" as Titulo,
                            a.""DataCadastro"" as DataCadastro,
                            (
	                            select count(*)
	                            from ""ComentarioAula"" ca 
	                            where ca.""AulaId"" = a.""Id"" 
                            ) as Comentarios,
                            (
	                            select count(*)
	                            from ""VisualizacaoAula"" va 
	                            where va.""AulaId"" = a.""Id"" 
                            ) as Visualizacoes,
                            (
	                            select Count(*)
	                            from ""Favorito"" f 
	                            where f.""AulaId"" = a.""Id"" 
                            ) as Favoritos
                            from ""Aula"" a 
                            WHERE a.""ProfessorId"" = :ProfessorId
                         ";

            return await repository.Connection.QueryAsync<AulaProfessorModel>(sql, new { ProfessorId = professorId });
        }
    }
}
