﻿using Dapper;
using Fisica.Domains;
using Fisica.Interfaces;

namespace Fisica.Dados.Repositories
{
    public static class RepositoryInstituicaoExtensions
    {
        public static async Task<int> ObterQuantidadeInstituicoes(this IRepository<Instituicao> repository)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""Instituicao""
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql);
        }

        public static async Task<int> ObterQantidadeProfessores(this IRepository<Instituicao> repository, long instituicaoId)
        {
            string sql = @"
                            SELECT Count(*)
                            FROM ""Usuario"" u
                            WHERE u.""InstituicaoId"" = :InstituicaoId
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { InstituicaoId = instituicaoId});
        }
    }
}
