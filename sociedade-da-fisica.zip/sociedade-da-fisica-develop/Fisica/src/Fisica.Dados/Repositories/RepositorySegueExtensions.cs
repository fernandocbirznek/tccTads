﻿using Dapper;
using Fisica.Domains;
using Fisica.Interfaces;

namespace Fisica.Dados.Repositories
{
    public static class RepositorySegueExtensions
    {
        public static async Task<int> ObterQuantidadeSeguindo(this IRepository<Segue> repository, long usuarioId)
        {
            string sql = @"
                            SELECT COUNT(*)
                            FROM ""Segue"" s
                            WHERE s.""UsuarioId"" = :UsuarioId
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }

        public static async Task<int> ObterQuantidadeSeguidores(this IRepository<Segue> repository, long usuarioId)
        {
            string sql = @"
                            SELECT COUNT(*)
                            FROM ""Segue"" s
                            WHERE s.""ProfessorId"" = :UsuarioId
                          ";

            return await repository.Connection.QuerySingleAsync<int>(sql, new { UsuarioId = usuarioId });
        }
    }
}
