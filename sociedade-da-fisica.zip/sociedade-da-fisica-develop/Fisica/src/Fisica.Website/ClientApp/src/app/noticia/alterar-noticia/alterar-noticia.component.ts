import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Noticia, Tag } from 'src/app/shared';
import { atualizarNoticia, getNoticiaById } from 'src/app/store';

@Component({
  selector: 'app-alterar-noticia',
  templateUrl: './alterar-noticia.component.html',
  styleUrls: ['./alterar-noticia.component.css']
})
export class AlterarNoticiaComponent implements OnInit {
  noticiaAlterar$: Observable<Noticia> = new Observable<Noticia>();
  noticiaAlterar: Noticia = new Noticia();
  noticiaAlterarId: number = 0;

  formAlterarNoticia: FormGroup = null as any;
  titulo = new FormControl('', [Validators.required]);
  //resumo = new FormControl('', [Validators.required]);
  noticia = new FormControl('', [Validators.required]);

  tags: Tag[] = [];
  tagsSelecionadas: Tag[] = [];

  constructor(
    public store: Store,
    public router: Router,
    private route: ActivatedRoute,
  ) {
    this.tags = [
      {id: 1, nome: "Mecânica", checked: false},
      {id: 2, nome: "Termodinâmica", checked: false},
      {id: 3, nome: "Ondulatória", checked: false},
      {id: 4, nome: "Física moderna", checked: false},
      {id: 5, nome: "Eletromagnetismo", checked: false},
      {id: 6, nome: "Matemática", checked: false},
      {id: 7, nome: "Outros", checked: false},
    ]

    this.criarFormularioAlterarNoticia(new Noticia());
  }

  ngOnInit(): void {
    if (!this.route.snapshot.paramMap.get('noticiaAtualizar')) {
      this.router.navigate([`professor-perfil/${localStorage.getItem("loginUsuario")}`]);
    }
    this.noticiaAlterarId = parseInt(this.route.snapshot.paramMap.get('noticiaAtualizar')!);

    this.noticiaAlterar$ = this.store.select(getNoticiaById(this.noticiaAlterarId));
    this.noticiaAlterar$.subscribe(item => {
      this.noticiaAlterar = item;
      this.setarTagsSelecionadas(item);
      this.setarFormulario(item);
    })
  }

  criarFormularioAlterarNoticia(noticia: Noticia) {
    this.formAlterarNoticia = new FormGroup({
      cadastrar_noticia: new FormControl(noticia.conteudo),
      titulo: new FormControl(noticia.titulo),
      //resumo: new FormControl(noticia.resumo),
    })
  }

  setarTagsSelecionadas(noticia: Noticia) {
    let tags: Tag[] = JSON.parse(noticia.tags);
    tags.forEach(tag => {
      this.tags = [...this.tags].map(item => {
        if(item.nome == tag.nome)
          return {...tag, checked: true};
        return item;
      })
    })
  }

  setarFormulario(noticia: Noticia) {
    this.formAlterarNoticia.setValue({
      cadastrar_noticia: noticia.conteudo,
      titulo: noticia.titulo,
      //resumo: noticia.resumo
    })
  }

  tagSelecionada(tag: Tag) {
    if(!this.tagsSelecionadas.find(item => item.id == tag.id))
      this.tagsSelecionadas.push(tag)
    else 
      this.tagsSelecionadas = this.tagsSelecionadas.filter(item => item.id != tag.id)
  }

  cadastrar() {
    let noticia: Noticia = new Noticia();
    noticia.conteudo = this.formAlterarNoticia.get("cadastrar_noticia")?.value;
    noticia.titulo = this.formAlterarNoticia.get("titulo")?.value;
    //noticia.resumo = this.formAlterarNoticia.get("resumo")?.value;
    noticia.id = this.noticiaAlterarId;
    if(this.tagsSelecionadas.length == 0)
      noticia.tags = ""
    else
      noticia.tags = JSON.stringify(this.tagsSelecionadas);
    // noticia.autorId = this.formNoticia.get("autor_id")?.value;
    // noticia.autorNome = this.formNoticia.get("autor_nome")?.value;
    this.store.dispatch(atualizarNoticia({ noticiaAlterar: noticia }));
    this.router.navigate([`professor-perfil/${localStorage.getItem("loginUsuario")}`]);
  }

  voltar() {
    this.router.navigate([`professor-perfil/${localStorage.getItem("loginUsuario")}`]);
  }
}
