import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromNoticia from '../reducers/noticia.reducers';
import { Noticia } from 'src/app/shared';

export const selectNoticiaState = createFeatureSelector<fromNoticia.NoticiaState>(
    fromNoticia.noticiaFeatureKey
);

export const getNoticias = createSelector(selectNoticiaState, (state) => {
    return state.noticias;
})

export const getNoticiaById = (noticiaId: number) => createSelector(getNoticias, (noticias) => {
    let noticia = noticias.find(item => item.id == noticiaId);
    if(noticia == undefined)
        return new Noticia();
    return noticia;
})

export const getNoticiasByIdProfessor = (professorId: number) => createSelector(selectNoticiaState, (state) => {
    return state.noticias.filter(noticia => noticia.autorId == professorId);
})