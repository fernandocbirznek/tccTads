import { Action, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/aula.actions';
import { Aula } from '../../../../shared/models/aula.model';


export const aulaFeatureKey = 'aula';

export interface AulaState {
  professorAulas: Aula[];
  aula: Aula;
  isSuccess: boolean;
  isLoading: boolean;
  isFailure: boolean;
  mensagem: string;
}

export const aulaInitialState: AulaState = {
  professorAulas: [],
  aula: new Aula(),
  isSuccess: false,
  isLoading: false,
  isFailure: false,
  mensagem: "",
};

export const aulaReducer = createReducer(
  aulaInitialState,

  //on(actions.selecionarAula, state => {
  //  return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  //}),
  //on(actions.selecionarAulaSuccess, (state, action) => {
  //  let itens: TopicoForum[] = action.response;
  //
  //  return { 
  //    ...state, 
  //    topicosForum: itens,
  //    tituloForum: setarTitulo(action.forumId),
  //    isLoading: false, 
  //    isSuccess: true, 
  //    isFailure: false, 
  //  };
  //}),
  //on(actions.selecionarTemaForumFailure, (state, action) => {
  //  return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar os tópicos do fórum"};
  //}),

  on(actions.selecionarAulaByProfessorId, state => {
   return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarAulaByProfessorIdSuccess, (state, action) => {
   let aulas: Aula[] = action.response;
  
   return { 
     ...state, 
     professorAulas: aulas,
     isLoading: false, 
     isSuccess: true, 
     isFailure: false, 
   };
  }),
  on(actions.selecionarAulaByProfessorIdFailure, (state, action) => {
   return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar as aulas do professor"};
  }),

  on(actions.inserirAula, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.inserirAulaSuccess, (state, action) => {
    let aula: Aula = {
      ...action.aula,
    }
    return {
      ...state,
      aula: aula,
      isLoading: false,
      isSuccess: true,
      isFailure: false,
    };
  }),
  on(actions.inserirAulaFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao cadastrar Aula." };
  }),

  on(actions.atualizarAula, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.atualizarAulaSuccess, (state, action) => {
    let aula: Aula = {
      ...action.aula,
    }
    return {
      ...state,
      aula: aula,
      isLoading: false,
      isSuccess: true,
      isFailure: false,
    };
  }),
  on(actions.atualizarAulaFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao atualizar Aula." };
  }),

  on(actions.excluirAula, state => {
   return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.excluirAulaSuccess, (state, action) => {
   let itens: Aula[] = state.professorAulas.filter(item => item.id != action.aulaId);
  
   return { 
     ...state, 
     professorAulas: itens,
     isLoading: false, 
     isSuccess: true, 
     isFailure: false, 
   };
  }),
  on(actions.excluirAulaFailure, (state, action) => {
   return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao excluir aula"};
  }),
);
