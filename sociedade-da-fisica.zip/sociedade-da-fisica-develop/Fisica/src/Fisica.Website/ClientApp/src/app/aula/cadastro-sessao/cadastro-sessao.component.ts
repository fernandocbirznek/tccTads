import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { arrayBuffer } from 'stream/consumers';
import { Aula } from '../../shared/models/aula.model';
import { SessaoAula } from '../../shared/models/sessao-aula.model';
import { NotificacoesService } from '../../shared/services/notificacoes.service';

@Component({
  selector: 'app-cadastro-sessao',
  templateUrl: './cadastro-sessao.component.html',
  styleUrls: ['./cadastro-sessao.component.css']
})
export class CadastroSessaoComponent implements OnInit {

  @ViewChild("editor", { static: false }) editor: any;

  rows = 10;

  tipoSessao = new FormControl('', [Validators.required]);
  conteudo = new FormControl('', [Validators.required, Validators.maxLength(8000)]);
  titulo = new FormControl('', [Validators.required, Validators.maxLength(200)]);

  formSessao: FormGroup = null as any;

  exemploEquacao: string = "y = 5 + \\sqrt{100} - \\sum (x+1) + \\int z \\Delta z";

  constructor(
    public dialogRef: MatDialogRef<CadastroSessaoComponent>,
    public notificacoesService: NotificacoesService,
    @Inject(MAT_DIALOG_DATA) public aula: Aula
  ) { }

  public ngOnInit(): void {
    this.criarFormularioSessao(new SessaoAula());
  }

  private criarFormularioSessao(sessao: SessaoAula) {
    this.formSessao = new FormGroup({
      titulo_sessao: new FormControl(sessao.titulo),
      conteudo_sessao: new FormControl(sessao.conteudo),
      tipo_sessao: new FormControl(sessao.tipoSessao)
    })
  }

  public salvar(): void {
    let sessao: SessaoAula = new SessaoAula();
    sessao.titulo = this.formSessao.get("titulo_sessao")?.value;
    
    switch(this.formSessao.get("tipo_sessao")?.value) { 
      case "1":
      case "5":
        sessao.conteudo = this.editor._data;
        break; 
      case "2":
      case "3":
        sessao.conteudo = this.formSessao.get("conteudo_sessao")?.value;
        break;
   } 
    
    sessao.tipoSessao = this.formSessao.get("tipo_sessao")?.value;
    sessao.ordem = this.aula.sessoes!.length + 1;
    if (sessao.titulo == "" || sessao.titulo == null) {
      this.notificacoesService.mostrarAviso("Insira um titulo.");
      return;
    }

    if (sessao.tipoSessao == null) {
      this.notificacoesService.mostrarAviso("Escolha um tipo de sessão.");
      return;
    }
    if (sessao.tipoSessao == 3 && (sessao.conteudo == "" || sessao.conteudo == null)) {
      this.notificacoesService.mostrarAviso("Escolha uma imagem para continuar.")
      return;
    }

    if (this.formSessao.get("tipo_sessao")?.value == 2 && (sessao.conteudo == "" || sessao.conteudo == null)) {
      this.notificacoesService.mostrarAviso("Insira um conteúdo para a sessão.")
      return;
    }

    if ((this.formSessao.get("tipo_sessao")?.value == 1 || this.formSessao.get("tipo_sessao")?.value == 5)  && (this.editor._data == "" || this.editor._data == null)) {
      this.notificacoesService.mostrarAviso("Insira um conteúdo para a sessão.")
      return;
    }

    this.aula.sessoes!.push(sessao);
    this.fecharModal();
  }

  public fecharModal() {
    this.dialogRef.close();
  }

  public calcularRows() {

    this.formSessao.get("conteudo_sessao")?.setValue("");
    switch (parseInt(this.formSessao.get("tipo_sessao")?.value)) {
      case 1:
        this.rows = 3;
        break;
      case 2:
        this.rows = 3;
        break;
      case 5:
        this.rows = 10;
        break;
      default:
        break;
    }
  }

  public async changeImagem(event: any) {
    const fileList = event.target.files;

    var base64 = this._arrayBufferToBase64(await (fileList[0].arrayBuffer()));
    this.formSessao.get("conteudo_sessao")?.setValue('data:image/png;base64, ' + base64);

  }


  public _arrayBufferToBase64(buffer: any) {
    var binary = '';
    var bytes = new Uint8Array(buffer);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }
}
