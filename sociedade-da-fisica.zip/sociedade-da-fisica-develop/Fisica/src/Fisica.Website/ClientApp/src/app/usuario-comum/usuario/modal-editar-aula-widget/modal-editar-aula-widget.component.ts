import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { atualizarAulaWidget } from 'src/app/store';

@Component({
  selector: 'app-modal-editar-aula-widget',
  templateUrl: './modal-editar-aula-widget.component.html',
  styleUrls: ['./modal-editar-aula-widget.component.css']
})
export class ModalEditarAulaWidgetComponent implements OnInit {

  widgetNovo: string = "Para Cursar";
  
  constructor(
    public dialogRef: MatDialogRef<ModalEditarAulaWidgetComponent>,
    public store: Store,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
  }

  public ngOnInit(): void {
  }

  public editarAula(widget: string) {
    this.widgetNovo = widget;
  }

  public salvar() {
    this.store.dispatch(atualizarAulaWidget({ aula: this.data.aula, widgetAntigo: this.data.widget , widgetNovo: this.widgetNovo }));
    this.dialogRef.close();
  }

  public fechar() {
    this.dialogRef.close();
  }
}
