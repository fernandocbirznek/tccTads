import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Replica } from '../../../shared/models/replica.model';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastComponent } from 'src/app/components-genericos';
import { Store } from '@ngrx/store';
import { MatSnackBar } from '@angular/material/snack-bar';
import { atualizarReplicaTopico } from 'src/app/store';
import { NotificacoesService } from '../../../shared/services/notificacoes.service';

@Component({
  selector: 'app-modal-edicao-replica',
  templateUrl: './modal-edicao-replica.component.html',
  styleUrls: ['./modal-edicao-replica.component.css']
})
export class ModalEdicaoReplicaComponent implements OnInit {

  @ViewChild("editor", { static: false }) editor: any;

  formReplicaTopico: FormGroup = null as any;
  descricao = new FormControl('', [Validators.required]);

  constructor(
    public dialogRef: MatDialogRef<ModalEdicaoReplicaComponent>,
    public store: Store,
    private notificacoesService: NotificacoesService,
    @Inject(MAT_DIALOG_DATA) public replica: Replica
  ) { }

  public ngOnInit(): void {
    this.criarFormularioTopico(new Replica());
    this.setFormReplica();
  }

  setFormReplica() {
    this.formReplicaTopico.setValue({
      replica: this.replica.descricao
    })
  }

  criarFormularioTopico(replicaTopico: Replica) {
    this.formReplicaTopico = new FormGroup({
      replica: new FormControl(replicaTopico.descricao)
    })
  }

  public fechar(): void {
    this.dialogRef.close();
  }

  public salvar() {
    if (this.verificarCampo(this.editor._data)) {
      this.notificacoesService.mostrarAviso('A replica deve ser preenchida.');
    }
    else {
      this.atualizarReplica();
      this.notificacoesService.mostrarSucesso('Replica atualizada com sucesso!');
      this.fechar();
    }
  }

  private atualizarReplica() {
    let replicaTopico: Replica = new Replica();
    replicaTopico.descricao = this.editor._data;
    replicaTopico.id = this.replica.id;
    this.store.dispatch(atualizarReplicaTopico({ atualizarReplicaTopico: replicaTopico }));
  }

  verificarCampo(campo: any) {
    if(campo == "" || campo == undefined || campo == null)
      return true;
    return false;
  }
}
