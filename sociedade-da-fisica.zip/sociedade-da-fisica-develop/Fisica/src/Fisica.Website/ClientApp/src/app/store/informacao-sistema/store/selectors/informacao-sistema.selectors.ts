import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromInformacaoSistema from '../reducers/informacao-sistema.reducers';

export const selectInformacaoSistemaState = createFeatureSelector<fromInformacaoSistema.InformacaoSistemaState>(
    fromInformacaoSistema.informacaoSistemaFeatureKey
);

export const getInformacaoSistema = createSelector(selectInformacaoSistemaState, (state) => {
    return state.itens;
})