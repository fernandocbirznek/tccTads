import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ModalExcluirComponent } from 'src/app/components-genericos';
import { Aula } from 'src/app/shared';
import { excluirAula, getAulasProfessor } from 'src/app/store';

@Component({
  selector: 'app-professor-tabela-aula',
  templateUrl: './professor-tabela-aula.component.html',
  styleUrls: ['./professor-tabela-aula.component.css']
})
export class ProfessorTabelaAulaComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = ['titulo', 'data-postagem', 'comentarios', 'visualizacoes', 'favoritado', 'acao'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  aulas$: Observable<Aula[]> = new Observable<Aula[]>();

  constructor(
    public router: Router,
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.aulas$ = this.store.select(getAulasProfessor);
  }

  public ngOnInit() {
    this.aulas$.subscribe(item => {
      this.dataSource = new MatTableDataSource(item);
    })
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  aplicarFiltro(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  criarAula() {
    this.router.navigate(['aula/cadastro']);
  }

  acessarAula(item: Aula) {
    
  }

  editarAula(item: Aula) {
    this.router.navigate([`aula/editar/${item.id}`]);
  }

  excluirAula(item: Aula) {
    this.dialog.open(ModalExcluirComponent, {
      data: 'Notícia'
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.store.dispatch(excluirAula({ aulaId: item.id! }));
      }
    });
  }
}
