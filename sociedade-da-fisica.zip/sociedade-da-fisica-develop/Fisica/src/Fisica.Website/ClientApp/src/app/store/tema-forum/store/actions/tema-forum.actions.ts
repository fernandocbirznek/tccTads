import { createAction, props } from '@ngrx/store';
import { TopicoForum } from 'src/app/shared/models/topico-forum.model';

export const selecionarTemaForum = createAction(
  '[TemaForum] selecionarTemaForum',
  props<{ forumId: number }>()
);

export const selecionarTemaForumSuccess = createAction(
  '[TemaForum] selecionarTemaForum Success',
  props<{ forumId: number, response: TopicoForum[] }>()
);

export const selecionarTemaForumFailure = createAction(
  '[TemaForum] selecionarTemaForum Failure',
  props<{ error: any }>()
);

export const inserirTopicoForum = createAction(
  '[TemaForum] inserirTopico',
  props<{ topicoForum: TopicoForum }>()
);

export const inserirTopicoSuccess = createAction(
  '[TemaForum] inserirTopico Success',
  props<{ topicoForum: TopicoForum, response: TopicoForum }>()
);

export const inserirTopicoFailure = createAction(
  '[TemaForum] inserirTopico Failure',
  props<{ error: any }>()
);

export const excluirTopicoForum = createAction(
  '[TopicoForum] excluirTopico',
  props<{ excluirTopicoForumId: number }>()
);

export const excluirTopicoSuccess = createAction(
  '[TopicoForum] excluirTopico Success',
  props<{ excluirTopicoForumId: number }>()
);

export const excluirTopicoFailure = createAction(
  '[TopicoForum] excluirTopico Failure',
  props<{ error: any }>()
);