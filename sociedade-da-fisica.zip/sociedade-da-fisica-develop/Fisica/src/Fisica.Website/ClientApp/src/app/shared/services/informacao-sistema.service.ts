import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AbstractHttpService } from './abstract-http.service';
import { InformacaoSistema } from '../models';

@Injectable({
  providedIn: 'root'
})
export class InformacaoSistemaService extends AbstractHttpService {

  constructor(@Inject('BASE_URL') baseUrl: string, httpClient: HttpClient) {
    super(baseUrl, httpClient, 'api/informacaoSistema');
  }

  public getInformacaoSistema(): Observable<InformacaoSistema> {
    return this.get<InformacaoSistema>('buscar-informacoes-sistema');
  }
}
