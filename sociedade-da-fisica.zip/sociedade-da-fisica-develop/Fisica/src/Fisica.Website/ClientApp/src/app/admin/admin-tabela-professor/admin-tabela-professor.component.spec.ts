import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTabelaProfessorComponent } from './admin-tabela-professor.component';

describe('AdminTabelaProfessorComponent', () => {
  let component: AdminTabelaProfessorComponent;
  let fixture: ComponentFixture<AdminTabelaProfessorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminTabelaProfessorComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminTabelaProfessorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
