import { Component } from '@angular/core';

@Component({
  selector: 'app-especiais',
  templateUrl: './especiais.component.html',
  styleUrls: ['./especiais.component.css']
})
export class EspeciaisComponent {

}
