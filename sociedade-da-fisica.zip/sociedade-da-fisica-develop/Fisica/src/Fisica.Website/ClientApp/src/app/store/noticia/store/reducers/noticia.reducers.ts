import { Action, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/noticia.actions';
import { Noticia } from 'src/app/shared/models/noticia.model';

export const noticiaFeatureKey = 'noticia';

export interface NoticiaState {
    noticias: Noticia[];
    noticia: Noticia;
    isSuccess: boolean;
    isLoading: boolean;
    isFailure: boolean;
    mensagem: string;
}

export const noticiaInitialState:  NoticiaState = {
    noticias: [],
    noticia: null as any,
    isSuccess: false,
    isLoading: false,
    isFailure: false,
    mensagem: "",
};

export const noticiaReducer = createReducer(
    noticiaInitialState,

  on(actions.selecionarNoticias, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarNoticiasSuccess, (state, action) => {
    let itens: Noticia[] = action.response;

    return { 
      ...state, 
      noticias: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.selecionarNoticiasFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar as notícias"};
  }),

  on(actions.selecionarNoticiaById, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarNoticiaByIdSuccess, (state, action) => {
    let item: Noticia = action.response;

    return { 
      ...state, 
      noticia: item,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.selecionarNoticiaByIdFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar as notícias"};
  }),

  on(actions.inserirNoticia, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.inserirNoticiaSuccess, (state, action) => {
    let noticia: Noticia = {
      ...action.noticia,
      id: action.response.id,
      dataCadastro: action.response.dataCadastro,
      vizualizacao: action.response.vizualizacao
    }
    let itens: Noticia[] = [...state.noticias, noticia];
    return { 
      ...state, 
      noticias: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.inserirNoticiaFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao cadastrar notícia"};
  }),

  on(actions.atualizarNoticia, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.atualizarNoticiaSuccess, (state, action) => {
    let itens: Noticia[] = [...state.noticias].map(item => {
      if(item.id = action.noticiaAlterar.id) {
        let noticia = {...item, 
          titulo: action.noticiaAlterar.titulo,
          resumo: action.noticiaAlterar.resumo,
          conteudo: action.noticiaAlterar.conteudo,
          tags: action.noticiaAlterar.tags
        }
        return noticia;
      }
      return item;
    });
    return { 
      ...state, 
      noticias: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.atualizarNoticiaFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao excluir notícia"};
  }),

  on(actions.excluirNoticia, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.excluirNoticiaSuccess, (state, action) => {
    let itens: Noticia[] = [...state.noticias].filter(item => item.id != action.noticiaId);
    return { 
      ...state, 
      noticias: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.excluirNoticiaFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao excluir notícia"};
  }),
);
