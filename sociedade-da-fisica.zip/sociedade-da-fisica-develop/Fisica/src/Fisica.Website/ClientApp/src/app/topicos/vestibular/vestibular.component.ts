import { Component } from '@angular/core';

@Component({
  selector: 'app-vestibular',
  templateUrl: './vestibular.component.html',
  styleUrls: ['./vestibular.component.css']
})
export class VestibularComponent {

}
