export class Perfil {
  constructor(
    public id?: number,
    public descricao?: string,
    public foto?: string,
    public aniversario?: Date,
    public idade?: number
  ) { } 
}
