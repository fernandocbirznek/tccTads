import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { Replica } from '../../../shared/models/replica.model';
import { RespostaTopico } from '../../../shared/models/resposta-topico.model';
import { TopicoForum } from '../../../shared/models/topico-forum.model';
import { UsuarioService } from '../../../shared/services/usuario.service';
import { ModalEdicaoReplicaComponent } from '../modal-edicao-replica/modal-edicao-replica.component';
import { ModalEdicaoRespostaComponent } from '../modal-edicao-resposta/modal-edicao-resposta.component';
import { ModalEdicaoTopicoComponent } from '../modal-edicao-topico/modal-edicao-topico.component';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';

import { 
  excluirReplicaTopicoForum, excluirRespostaTopicoForum, excluirTopicoForum, getTopicoForum, inserirReplicaTopicoForum, 
  inserirRespostaTopicoForum, selecionarTopicoForum 
} from 'src/app/store';
import { ModalExcluirComponent, ToastComponent } from 'src/app/components-genericos';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NotificacoesService } from '../../../shared/services/notificacoes.service';

@Component({
  selector: 'app-topico-forum',
  templateUrl: './topico-forum.component.html',
  styleUrls: ['./topico-forum.component.css']
})
export class TopicoForumComponent implements OnInit {

  /**
   *	Deve carregar os comentários do tópico.                                     -> buscarTopicoForum();         OK
   *  Deve ser possível alterar o comentário.                                                                     OK
   *  Não deve ser possível alterar o comentário com informações inconsistentes.                                  OK
   *  Deve ser possível responder comentários do tópico.                          -> inserirResposta();           OK
   *  Não deve ser possível responder comentário com informações inconsistentes.                                  OK
   *  Deve ser possível excluir um comentário.                                    -> excluirResposta();           OK
   *  Deve ser possível clicar no perfil do usuário.                              -> abrirPerfilUsuario();        OK
   *  Deve ser possível acessar o menu.                                                                           OK
   *  Deve ser possível voltar para a tela anterior.                                                              OK
   *
   * */

  @ViewChild("editor", { static: false }) editor: any;
  @ViewChild("editorReplica", { static: false }) editorReplica: any;

  initialDataResposta: string = "<p>Escreva sua resposta aqui : )</p>";
  initialDataReplica: string = "<p>Escreva sua replica : )</p>";

  exibirLoading: boolean = true;
  usuarioId: number = 0;

  //topicoForum: TopicoForum = new TopicoForum();
  topicoForumId: number = 0;

  topicoForum$: Observable<TopicoForum> = new Observable<TopicoForum>();
  topicoForum: TopicoForum = new TopicoForum();

  //textoResposta: string = "";
  //textoReplica: string = "";
  exibirReplica: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private dialog: MatDialog,
    private usuarioService: UsuarioService,
    private modalService: MatDialog,
    public store: Store,
    private notificacoesService: NotificacoesService
  ) {
    this.usuarioId = parseInt(this.usuarioService.getUsuarioId());
  }

  public async ngOnInit(): Promise<void> {
    this.store.dispatch(selecionarTopicoForum({topicoForumId: parseInt(this.route.snapshot.paramMap.get('topicoForumId')!)}));
    this.topicoForum$ = this.store.select(getTopicoForum);
    this.topicoForum$.subscribe(item => this.topicoForum = item);

    if (!this.route.snapshot.paramMap.get('topicoForumId')) {
      //TO-DO: redirecionar pois nao veio topico
    }
    this.topicoForumId = parseInt(this.route.snapshot.paramMap.get('topicoForumId')!);
    this.exibirLoading = false;
  }

  public responderTopico() {
    if (this.editor._data == null || this.editor._data == "" || this.editor._data == undefined) {
      this.notificacoesService.mostrarAviso('A resposta deve ser preenchida.');
    } else {
      let resposta = new RespostaTopico();
      resposta.descricao = this.editor._data;
      resposta.topicoForumId = this.topicoForumId;
      this.store.dispatch(inserirRespostaTopicoForum( {respostaTopico: resposta} ));
      this.initialDataResposta = "<p>Escreva sua resposta : )</p>";
    }
  }

  public removerResposta(respostaId: number) {
    this.dialog.open(ModalExcluirComponent, {
      data: 'Resposta'
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.store.dispatch(excluirRespostaTopicoForum( {excluirRespostaTopicoId: respostaId} ));
      }
    });
  }

  public inserirReplica(respostaId: number) {
    let replica = new Replica();
    replica.respostaTopicoId = respostaId;
    replica.descricao = this.editorReplica._data;
    this.store.dispatch(inserirReplicaTopicoForum( {replicaTopico: replica} ));
    this.cancelarReplica(respostaId);
    this.initialDataReplica = "<p>Escreva sua replica : )</p>";
  }

  public removerReplica(replicaId: number) {
    this.dialog.open(ModalExcluirComponent, {
      data: 'Replica'
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.store.dispatch(excluirReplicaTopicoForum( {excluirReplicaTopicoId: replicaId, topicoForumId: this.topicoForumId} ));
      }
    });
  }

  public async removerTopico(): Promise<void> {
    this.dialog.open(ModalExcluirComponent, {
      data: 'Tópico'
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.router.navigate(['/forum/tema-forum', this.topicoForum.forumId]);
        this.store.dispatch(excluirTopicoForum( {excluirTopicoForumId: this.topicoForumId} ));
      }
    });
  }

  public exibirResponder(respostaId: number): void {
    document.getElementById(respostaId.toString())?.classList.remove('collapse');
  }

  public cancelarReplica(respostaId: number): void {
    document.getElementById(respostaId.toString())?.classList.add('collapse');
  }

  public abrirPerfilUsuario(login?: string): void {
    this.router.navigate([]).then(result => { window.open('/#/perfil' + '/' + login, '_blank'); });
  }

  public editarTopico(): void {
    this.dialog.open(ModalEdicaoTopicoComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: this.topicoForum
    });
  }

  public editarResposta(resposta: RespostaTopico): void {
    this.dialog.open(ModalEdicaoRespostaComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: resposta
    });
  }

  public editarReplica(replica: Replica): void {
    this.dialog.open(ModalEdicaoReplicaComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: replica
    });
  }
}
