import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { LoadingComponent } from './components/loading/loading.component';
import { NoticiasComponent } from './components/noticias/noticias.component';
import { HttpErrorInterceptor } from './interceptor/http-error.interceptor';
import { FilterPipe } from './pipes/filter.pipe';
import { AulaService } from './services/aula.service';
import { CidadeService } from './services/cidade.service';
import { ComentarioAulaService } from './services/comentario-aula.service';
import { FavoritoService } from './services/favorito.service';
import { InstituicaoService } from './services/instituicao.service';
import { NoticiaService } from './services/noticia.service';
import { NotificacoesService } from './services/notificacoes.service';
import { ReplicaService } from './services/replica.service';
import { RespostaTopicoService } from './services/resposta-topico.service';
import { SegueService } from './services/segue.service';
import { TopicoForumService } from './services/topico-forum.service';
import { WidgetService } from './services/widget.service';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';
import { ConfirmDialogService } from './services/confirm-dialog.service';
import { AdministrarInstituicaoComponent } from './components/administrar-instituicao/administrar-instituicao.component';
import { NgSelectModule } from '@ng-select/ng-select';

@NgModule({
  declarations: [
    NoticiasComponent,
    DashboardComponent,
    FilterPipe,
    LoadingComponent,
    ConfirmDialogComponent,
    AdministrarInstituicaoComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    NgSelectModule
  ],
  exports: [
    DashboardComponent,
    MatDialogModule,
    FilterPipe,
    LoadingComponent
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true
    },
    InstituicaoService,
    CidadeService,
    NotificacoesService,
    NoticiaService,
    AulaService,
    SegueService,
    FavoritoService,
    ComentarioAulaService,
    WidgetService,
    TopicoForumService,
    RespostaTopicoService,
    ReplicaService,
    ConfirmDialogService
  ]
})
export class SharedModule { }
