import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfessorAlterarPerfilComponent } from './professor-alterar-perfil.component';

describe('ProfessorAlterarPerfilComponent', () => {
  let component: ProfessorAlterarPerfilComponent;
  let fixture: ComponentFixture<ProfessorAlterarPerfilComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfessorAlterarPerfilComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfessorAlterarPerfilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
