import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Aula } from '../../shared';
import { AulaService } from '../../shared/services/aula.service';

@Component({
  selector: 'app-mecanica',
  templateUrl: './mecanica.component.html',
  styleUrls: ['./mecanica.component.css']
})
export class MecanicaComponent implements OnInit {


  // 1)	Deve carregar informações gerais sobre área da física.                              OK     HARDCODE
  // 2)	Deve carregar uma lista das aulas padrões do site.
  // 3)	Deve carregar uma lista das aulas cadastradas pelos professores.
  // 4)	Deve carregar uma lista dos principais conceitos da área.
  // 5)	Deve carregar uma lista das principais formulas, equações e leis da área.
  // 6)	Deve ser possível filtrar as aulas pelo pesquisar.
  // 7)	Deve ser possível filtrar as aulas pelos conceitos ou formulas, equações e leis.
  // 8)	Deve ser possível acessar uma aula.
  // 9)	Deve ser possível retirar os filtros.

  aulas: Aula[];

  searchText: string = "";
  public contador: number = 1;

  divisaoSelecionada: number = 0;

  constructor(
    public dialog: MatDialog,
    public aulaService: AulaService
  ) {
    this.aulas = [];
  }

  public async ngOnInit(): Promise<void> {
    await this.buscarAulas();
  }

  public moverAulas(num: number):void {
    //TODO está hardcode a quantidade de itens
    if (this.contador + num >= 1 && this.contador + num <= 3)
      this.contador = this.contador + num;
  }

  public divisao(selecionado: number):void {
    this.divisaoSelecionada = selecionado;

  }

  public async buscarAulas(): Promise<void> {
    this.aulas = (await this.aulaService.selecionarAulasPorAreaFisica(1).toPromise())!
  }
}
