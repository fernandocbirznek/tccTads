import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromCidadeEstado from '../reducers/cidade-estado.reducers';

export const selectCidadeEstadoState = createFeatureSelector<fromCidadeEstado.CidadeEstadoState>(
    fromCidadeEstado.cidadeEstadoFeatureKey
);

export const getCidades = createSelector(selectCidadeEstadoState, (state) => {
    return state.cidades;
})
