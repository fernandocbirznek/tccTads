import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GridNoticiasComponent } from './grid-noticias.component';

describe('GridNoticiasComponent', () => {
  let component: GridNoticiasComponent;
  let fixture: ComponentFixture<GridNoticiasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GridNoticiasComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GridNoticiasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
