import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Usuario } from '../../models';
import { InstituicaoService } from '../../services/instituicao.service';
import { NotificacoesService } from '../../services/notificacoes.service';
import { UsuarioService } from '../../services/usuario.service';

@Component({
  selector: 'app-administrar-instituicao',
  templateUrl: './administrar-instituicao.component.html',
  styleUrls: ['./administrar-instituicao.component.css']
})

export class AdministrarInstituicaoComponent implements OnInit {

  professores: Usuario[];
  usuarios: Usuario[];
  instituicaoId: number;

  opcoes: any[] = [{ descricao: "Professores da Instituição", value: 1 }, { descricao: "Vincular Professor", value: 2 }];
  opcao: any;

  constructor(
    private activeModal: NgbActiveModal,
    private usuarioService: UsuarioService,
    private instituicaoService: InstituicaoService,
    private notificacoesService: NotificacoesService
  ) {
    this.professores = [];
    this.usuarios = [];
    this.instituicaoId = 0;
    this.opcao = this.opcoes.find(x => x.value == 1);
  }

  public async ngOnInit(): Promise<void> {
    await this.buscarUsuarios();
    await this.buscarProfessores();
  }

  public async buscarProfessores(): Promise<void> {
    this.professores = (await this.instituicaoService.getProfessores(this.instituicaoId).toPromise())!;
  }

  public async buscarUsuarios(): Promise<void> {
    this.usuarios = (await this.usuarioService.getComuns().toPromise())!;
  }

  public accept() {
    this.activeModal.close(true);
  }

  public async remover(professor: Usuario) {
    await this.removerProfessor(professor.id!);
    this.professores = [];
    await this.buscarProfessores();
  }

  private async removerProfessor(id: number): Promise<void> {
    await this.instituicaoService.removerProfessor(id).toPromise();
  }

  public async adicionar(usuario: Usuario) {
    await this.adicionarProfessor(usuario.id!);
    this.usuarios = [];
    await this.buscarUsuarios();
  }

  private async adicionarProfessor(id: number): Promise<void> {
    await this.instituicaoService.inserirProfessor(id, this.instituicaoId).toPromise();
  }

  public async change() {
    this.professores = [];
    await this.buscarProfessores();
    this.usuarios = [];
    await this.buscarUsuarios();
  }
}
