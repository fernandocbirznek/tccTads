import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VisualizarFavoritadoComponent } from './visualizar-favoritado.component';

describe('VisualizarFavoritadoComponent', () => {
  let component: VisualizarFavoritadoComponent;
  let fixture: ComponentFixture<VisualizarFavoritadoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VisualizarFavoritadoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VisualizarFavoritadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
