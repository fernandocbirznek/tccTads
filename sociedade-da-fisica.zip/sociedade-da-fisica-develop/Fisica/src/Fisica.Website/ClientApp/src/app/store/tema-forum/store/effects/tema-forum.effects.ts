import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions/tema-forum.actions';
import { TopicoForumService } from 'src/app/shared/services/topico-forum.service';

@Injectable()
export class TemaForumEffects {

  constructor(
    private actions$: Actions,
    private topicoForumService: TopicoForumService) 
  {}

  selecionarTemaForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarTemaForum),
      concatMap((action) =>
        this.topicoForumService.buscarTopicosForum(action.forumId).pipe(
          map(response => actions.selecionarTemaForumSuccess({ forumId: action.forumId, response: response })),
          catchError(error => of(actions.selecionarTemaForumFailure({ error }))))
      )
    );
  });

  inserirTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.inserirTopicoForum),
      concatMap((action) =>
        this.topicoForumService.inserirTopico(action.topicoForum).pipe(
          map(response => actions.inserirTopicoSuccess({ topicoForum: action.topicoForum, response: response })),
          catchError(error => of(actions.inserirTopicoFailure({ error }))))
      )
    );
  });

  excluirTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.excluirTopicoForum),
      concatMap((action) =>
        this.topicoForumService.excluirTopico(action.excluirTopicoForumId).pipe(
          map(response => actions.excluirTopicoSuccess({ excluirTopicoForumId: action.excluirTopicoForumId })),
          catchError(error => of(actions.excluirTopicoFailure({ error }))))
      )
    );
  });
}
