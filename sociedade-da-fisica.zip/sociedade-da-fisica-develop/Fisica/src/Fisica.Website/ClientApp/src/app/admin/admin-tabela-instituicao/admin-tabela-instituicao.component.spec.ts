import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTabelaInstituicaoComponent } from './admin-tabela-instituicao.component';

describe('AdminTabelaInstituicaoComponent', () => {
  let component: AdminTabelaInstituicaoComponent;
  let fixture: ComponentFixture<AdminTabelaInstituicaoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminTabelaInstituicaoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminTabelaInstituicaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
