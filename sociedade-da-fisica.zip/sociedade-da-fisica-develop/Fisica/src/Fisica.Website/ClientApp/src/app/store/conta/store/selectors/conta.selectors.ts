import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromConta from '../reducer/conta.reducer';

export const selectContaState = createFeatureSelector<fromConta.ContaState>(
  fromConta.contaFeatureKey
);

export const selecionarConta = createSelector(selectContaState, (state) => {
  return state;
});

export const selecionarUsuario = createSelector(selectContaState, (state) => {
  return state.nome;
})

export const selecionarLoginUsuario = createSelector(selectContaState, (state) => {
  return state.login;
})

export const selecionarTipoUsuario = createSelector(selectContaState, (state) => {
  return state.tipoUsuario;
})

export const selecionarInformacoesUsuario = createSelector(selectContaState, (state) => {
  return state.perfilInformacoes;
})

export const selecionarAulasWidget = createSelector(selectContaState, (state) => {
  return state.widgetAulas;
})

export const selecionarFavoritos = createSelector(selectContaState, (state) => {
  return state.aulasFavoritadas;
})

export const getManyProfessoresSegue = createSelector(selectContaState, (state) => {
  return state.segue;
})