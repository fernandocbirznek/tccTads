import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import * as fromCidadeEstado from '../store/reducers/cidade-estado.reducers';
import { EffectsModule } from '@ngrx/effects';
import { CidadeEstadoEffects } from '../store/effects/cidade-estado.effects';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoreModule.forFeature(fromCidadeEstado.cidadeEstadoFeatureKey, fromCidadeEstado.cidadeEstadoReducer),
    EffectsModule.forFeature([CidadeEstadoEffects])
  ]
})
export class CidadeEstadoStateModule { }
