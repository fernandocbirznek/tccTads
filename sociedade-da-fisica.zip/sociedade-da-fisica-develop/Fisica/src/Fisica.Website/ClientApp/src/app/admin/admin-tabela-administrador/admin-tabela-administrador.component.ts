import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ModalExcluirComponent } from 'src/app/components-genericos';
import { Usuario } from 'src/app/shared';
import { excluirUsuario, getUsuarioAdministrador } from 'src/app/store';
import { AutocadastroComponent, UsuarioEdicaoModalComponent } from 'src/app/usuario-comum';

@Component({
  selector: 'app-admin-tabela-administrador',
  templateUrl: './admin-tabela-administrador.component.html',
  styleUrls: ['./admin-tabela-administrador.component.css']
})
export class AdminTabelaAdministradorComponent implements OnInit, AfterViewInit  {


  displayedColumns: string[] = ['nome', 'acao'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  usuarios$: Observable<Usuario[]> = new Observable<Usuario[]>();

  constructor(
    public router: Router,
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.usuarios$ = this.store.select(getUsuarioAdministrador);
  }

  public ngOnInit() {
    this.usuarios$.subscribe(usuarios => {
      this.dataSource = new MatTableDataSource(usuarios)
      this.dataSource.paginator = this.paginator;
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  aplicarFiltro(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  criarUsuario() {
    this.dialog.open(AutocadastroComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: true
    });
  }

  acessarUsuario(usuario: Usuario) {

  }

  editarUsuario(usuario: Usuario) {
    this.dialog.open(UsuarioEdicaoModalComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: usuario
    });
  }

  excluirUsuario(usuario: Usuario) {
    this.dialog.open(ModalExcluirComponent, {
      data: `Excluir usuário: ${usuario.nome}`
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.store.dispatch(excluirUsuario( {usuarioId: usuario.id!} ));
      }
    });
  }
}
