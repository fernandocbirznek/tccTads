import { Action, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/tema-forum.actions';
import { TopicoForum } from 'src/app/shared/models/topico-forum.model';

export const temaForumFeatureKey = 'tema-forum';

export interface TemaForumState {
    topicosForum: TopicoForum[];
    tituloForum: string;
    isSuccess: boolean;
    isLoading: boolean;
    isFailure: boolean;
    mensagem: string;
}

export const  temaForumInitialState:  TemaForumState = {
    topicosForum: [],
    tituloForum: "",
    isSuccess: false,
    isLoading: false,
    isFailure: false,
    mensagem: "",
};

export const temaForumReducer = createReducer(
    temaForumInitialState,

  on(actions.selecionarTemaForum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarTemaForumSuccess, (state, action) => {
    let itens: TopicoForum[] = action.response;

    return { 
      ...state, 
      topicosForum: itens,
      tituloForum: setarTitulo(action.forumId),
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.selecionarTemaForumFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar os tópicos do fórum"};
  }),

  on(actions.inserirTopicoForum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.inserirTopicoSuccess, (state, action) => {
    let topico: TopicoForum = {
      ...action.topicoForum,
      quantidadeRespostas: action.response.quantidadeRespostas,
      dataCadastro: action.response.dataCadastro,
      id: action.response.id
    }
    let itens: TopicoForum[] = [...state.topicosForum, topico];
    return { 
      ...state, 
      topicosForum: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.inserirTopicoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao cadastrar um tópico"};
  }),

  on(actions.excluirTopicoForum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.excluirTopicoSuccess, (state, action) => {
    let itens: TopicoForum[] = state.topicosForum.filter(item => item.id != action.excluirTopicoForumId);

    return { 
      ...state, 
      topicosForum: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.excluirTopicoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao excluir resposta no tópico"};
  }),
);

function setarTitulo(forumId: number): string {
    switch (forumId) {
        case 1:
            return "Fórum Mecânica";
        case 2:
            return "Fórum Termodinâmica";
        case 3:
            return "Fórum Ondulatória";
        case 4:
            return "Fórum Eletromagnetismo";
        case 5:
            return "Fórum Física Moderna";
        case 6:
            return "Fórum Matemática";
        case 7:
            return "Fórum Exercícios Vestibular";
        case 8:
            return "Outros";
        default:
            return "Página não encontrada";
    }
}