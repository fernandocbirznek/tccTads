import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Cidade } from '../../../shared/models/cidade.model';
import { Endereco } from '../../../shared/models/endereco.model';
import { Instituicao } from '../../../shared/models/instituicao.model';
import { CidadeService } from '../../../shared/services/cidade.service';
import { MatDialogRef } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToastComponent } from 'src/app/components-genericos';
import { getCidades, inserirInstituicao, selecionarCidades } from 'src/app/store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-inserir-instituicao',
  templateUrl: './inserir-instituicao.component.html',
  styleUrls: ['./inserir-instituicao.component.css']
})
export class InserirInstituicaoComponent implements OnInit {

  formCadastrar: FormGroup = null as any;

  nome = new FormControl('', [Validators.required]);
  email = new FormControl('', [Validators.required, Validators.email]);
  site = new FormControl('', [Validators.required]);
  descricao = new FormControl('', [Validators.maxLength(500)]);
  logradouro = new FormControl('', [Validators.maxLength(100)]);
  numero = new FormControl('', [Validators.maxLength(10)]);
  estado = new FormControl({value: 'PR', disabled: true}, [Validators.required]);
  cidade = new FormControl('', [Validators.required]);
  bairro = new FormControl('');

  cidades$: Observable<Cidade[]> = new Observable<Cidade[]>();
  cidades: Cidade[] = [];

  constructor(
    public dialogRef: MatDialogRef<InserirInstituicaoComponent>,
    public store: Store,
    private snackBar: MatSnackBar,
    public cidadeService: CidadeService
  ) { 
    this.store.dispatch(selecionarCidades());
  }

  ngOnInit() {
    this.criarFormularioCadastrar(new Instituicao());
    this.cidades$ = this.store.select(getCidades);
    this.cidades$.subscribe(item => this.cidades = item);
  }

  criarFormularioCadastrar(instituicao: Instituicao) {
    this.formCadastrar = new FormGroup({
      cadastrar_nome: new FormControl(instituicao.nome),
      cadastrar_email: new FormControl(instituicao.email),
      cadastrar_site: new FormControl(instituicao.site),
      cadastrar_descricao: new FormControl(instituicao.descricao),
      cadastrar_logradouro: new FormControl(instituicao.endereco?.logradouro),
      cadastrar_numero: new FormControl(instituicao.endereco?.numero),
      cadastrar_estado: new FormControl({value: 'PR', disabled: true}, [Validators.required]),
      cadastrar_cidade: new FormControl(instituicao.endereco?.cidade),
      cadastrar_bairro: new FormControl(instituicao.endereco?.bairro)
    })
  }

  inserir() {
    if(this.validarCampos()) {
      let instituicao: Instituicao = new Instituicao();
      let endereco: Endereco = new Endereco();
      let cidade: Cidade = new Cidade();
      instituicao.nome = this.formCadastrar.get("cadastrar_nome")?.value;
      instituicao.email = this.formCadastrar.get("cadastrar_email")?.value;
      instituicao.site = this.formCadastrar.get("cadastrar_site")?.value;
      instituicao.descricao = this.formCadastrar.get("cadastrar_descricao")?.value;
      endereco.logradouro = this.formCadastrar.get("cadastrar_logradouro")?.value;
      endereco.numero = this.formCadastrar.get("cadastrar_numero")?.value;
      instituicao.estado = this.formCadastrar.get("cadastrar_estado")?.value;
      endereco.bairro = this.formCadastrar.get("cadastrar_bairro")?.value;

      let c: Cidade | undefined = this.cidades.find(item => item.id == this.formCadastrar.get("cadastrar_cidade")?.value);

      cidade.nome = c?.nome;
      cidade.uf = c?.uf;
      cidade.id = c?.id;
      endereco.cidade = cidade;
      endereco.cidadeId = cidade.id;
      instituicao.endereco = endereco;
      instituicao.usuarioId = parseInt(localStorage.getItem("uid")!);

      this.store.dispatch(inserirInstituicao({ instituicao: instituicao }));
      this.formCadastrar.reset();
      this.dialogRef.close();
    }
  }

  fecharModal() {
    this.dialogRef.close();
  }

  validarCampos() {
    let retorno: boolean = true;
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_estado")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Estado");
      this.formCadastrar.get("cadastrar_estado")?.markAsTouched();
      retorno = false;
    }
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_cidade")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Cidade");
      this.formCadastrar.get("cadastrar_cidade")?.markAsTouched();
      retorno = false;
    }
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_site")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Site");
      this.formCadastrar.get("cadastrar_site")?.markAsTouched();
      retorno = false;
    }
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_email")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Email");
      this.formCadastrar.get("cadastrar_email")?.markAsTouched();
      retorno = false;
    }
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_nome")?.value)) {
      this.notificacaoValidacao("Deve preencher campo nome");
      this.formCadastrar.get("cadastrar_nome")?.markAsTouched();
      retorno = false;
    }
    return retorno;
  }

  verificarCampo(campo: any) {
    if(campo == "" || campo == undefined || campo == null)
      return true;
    return false;
  }

  notificacaoValidacao(item: string) {
    this.snackBar.openFromComponent(ToastComponent, {
      data: item,
      duration: 5 * 1000,
      panelClass: 'css-toast',
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }
}
