import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { InformacaoSistema } from 'src/app/shared';
import { deslogarConta, getInformacaoSistema, selecionarConta, selecionarInformacaoSistema, selecionarInstituicao, selecionarUsuarioAdministrador, selecionarUsuarioComum, selecionarUsuarioProfessor } from 'src/app/store';

@Component({
  selector: 'app-admin-perfil',
  templateUrl: './admin-perfil.component.html',
  styleUrls: ['./admin-perfil.component.css']
})
export class AdminPerfilComponent implements OnInit {

  selecionado: string = '0';

  /**
   *	Deve carregar informações gerais sobre o sistema.                                                                               OK
   *  Deve carregar uma lista de professores cadastrados.       -> selecionarProfessores();                                           OK
   *  Deve carregar as instituições cadastradas.                -> selecionarInstituicoes();                                          OK
   *  Deve carregar uma lista de usuários comuns cadastrados.   -> selecionarUsuariosComuns();                                        OK
   *  Deve ser possível excluir professor.      //pela dash? pensei que poderia listar apenas e redirecionar pra tela de edição       OK    
   *                                          Pensei mais na questão de gerenciar apenas, o admin só exclui ou altera o tipo do usuário 
   *  Deve ser possível atualizar professor.                                                                                          OK            
   *  Deve ser possível excluir instituição.                                                                                          OK
   *  Deve ser possível alterar instituição.                                                                                          OK
   *  Deve ser possível excluir usuário comum.                                                                                        OK
   *  Deve ser possível atualizar usuário comum.                                                                                      OK
   *  Deve ser possível filtrar usuário professor.                                                                                    OK
   *  Deve ser possível filtrar usuário comum.                                                                                        OK
   *  Deve ser possível filtrar instituição.                                                                                          OK
   *  Deve ser possível cadastrar um usuário.                                                                                         OK
   *  Deve ser possível cadastrar uma instituição.                                                                                    OK
   *  
   * */

   informacaoSistema$: Observable<InformacaoSistema> = new Observable<InformacaoSistema>();
   stateUsuario$: Observable<any> = new Observable<any>();
   nomeUsuario: string = "";

   constructor(
    public store: Store,
    public router: Router,
  ) {
    this.store.dispatch(selecionarUsuarioComum());
    this.store.dispatch(selecionarUsuarioProfessor());
    this.store.dispatch(selecionarInstituicao({usuarioId: parseInt(localStorage.getItem("uid")!)}));
    this.store.dispatch(selecionarInformacaoSistema());
    this.store.dispatch(selecionarUsuarioAdministrador());
    
  }

 public ngOnInit() {
  this.informacaoSistema$ = this.store.select(getInformacaoSistema);
  this.stateUsuario$ = this.store.select(selecionarConta);
  this.stateUsuario$.subscribe(item => {
    this.nomeUsuario = item.nome;
  });
 }

 deslogar() {
  this.store.dispatch(deslogarConta());
  this.router.navigate(['']);
 }

 selecionou(item: string) {
   this.selecionado = item;
 }

 alterarPerfil() {
   
 }

}
