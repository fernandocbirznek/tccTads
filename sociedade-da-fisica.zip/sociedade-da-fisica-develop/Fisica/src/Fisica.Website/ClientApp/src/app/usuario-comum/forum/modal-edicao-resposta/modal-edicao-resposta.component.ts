import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RespostaTopico } from '../../../shared/models/resposta-topico.model';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastComponent } from 'src/app/components-genericos';
import { Store } from '@ngrx/store';
import { MatSnackBar } from '@angular/material/snack-bar';
import { atualizarRespostaTopico } from 'src/app/store';
import { NotificacoesService } from '../../../shared/services/notificacoes.service';

@Component({
  selector: 'app-modal-edicao-resposta',
  templateUrl: './modal-edicao-resposta.component.html',
  styleUrls: ['./modal-edicao-resposta.component.css']
})
export class ModalEdicaoRespostaComponent implements OnInit {

  @ViewChild("editor", { static: false }) editor: any;

  formRespostaTopico: FormGroup = null as any;
  descricao = new FormControl('', [Validators.required]);

  constructor(
    public dialogRef: MatDialogRef<ModalEdicaoRespostaComponent>,
    public store: Store,
    private notificacoesService: NotificacoesService,
    @Inject(MAT_DIALOG_DATA) public resposta: RespostaTopico
  ) { }

  public ngOnInit(): void {
    this.criarFormularioTopico(new RespostaTopico());
    this.setFormResposta();
  }

  setFormResposta() {
    this.formRespostaTopico.setValue({
      resposta: this.resposta.descricao
    })
  }

  criarFormularioTopico(respostaTopico: RespostaTopico) {
    this.formRespostaTopico = new FormGroup({
      resposta: new FormControl(respostaTopico.descricao)
    })
  }

  public fechar(): void {
    this.dialogRef.close();
  }

  public salvar() {
    if (this.verificarCampo(this.editor._data)) {
      this.notificacoesService.mostrarAviso('Deve preencher uma resposta.');
    }
    else {
      this.inserirTopico();
      this.notificacoesService.mostrarSucesso('Resposta atualizada com sucesso!');
      this.fechar();
    }
  }

  private inserirTopico() {
    let respostaTopico: RespostaTopico = new RespostaTopico();
    respostaTopico.descricao = this.editor._data;
    respostaTopico.id = this.resposta.id;
    this.store.dispatch(atualizarRespostaTopico({ atualizarRespostaTopico: respostaTopico }));
  }

  verificarCampo(campo: any) {
    if(campo == "" || campo == undefined || campo == null)
      return true;
    return false;
  }
}
