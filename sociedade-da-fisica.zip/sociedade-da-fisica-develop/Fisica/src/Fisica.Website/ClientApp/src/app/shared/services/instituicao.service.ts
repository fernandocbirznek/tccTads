import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Instituicao } from '../models/instituicao.model';
import { AbstractHttpService } from './abstract-http.service';
import { AtualizarInstituicaoCommand, InformacaoSistema, Usuario } from '../models';

@Injectable({
  providedIn: 'root'
})
export class InstituicaoService extends AbstractHttpService {

  constructor(@Inject('BASE_URL') baseUrl: string, httpClient: HttpClient) {
    super(baseUrl, httpClient, 'api/instituicao');
  }

  public inserir(instituicao: Instituicao): Observable<Instituicao> {
    return this.post<Instituicao>('inserir', instituicao);
  }

  public atualizarInstituicao(instituicaoAltualizar: AtualizarInstituicaoCommand): Observable<Instituicao> {
    return this.put<Instituicao>('atualizar', instituicaoAltualizar);
  }

  public getInstituicoes(usuarioId: number): Observable<Instituicao[]> {
    return this.get<Instituicao[]>('buscar-instituicoes', {id: usuarioId});
  }

  public getInstituicaoById(instituicaoId: number): Observable<Instituicao> {
    return this.get<Instituicao>(`buscar-instituicao/${instituicaoId}`);
  }

  public excluir(id: number): Observable<any> {
    return this.delete<any>(`excluir/${id}`);
  }

  public getInformacaoSistema(): Observable<InformacaoSistema> {
    return this.get<InformacaoSistema>('buscar-informacoes-sistema');
  }

  public getProfessores(instituicaoId: number): Observable<Usuario[]> {
    return this.get<Usuario[]>(`professores/${instituicaoId}`);
  }

  public inserirProfessor(usuarioId: number, instituicaoId: number): Observable<any> {
    return this.post<any>(`inserir-professor`, { UsuarioId: usuarioId, InstituicaoId: instituicaoId });
  }

  public removerProfessor(usuarioId: number): Observable<InformacaoSistema> {
    return this.delete<InformacaoSistema>(`remover-professor/${usuarioId}`);
  }
}
