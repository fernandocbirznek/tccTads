export class Login {
	email_usuario: string = "";
	senha_usuario: string = "";
}