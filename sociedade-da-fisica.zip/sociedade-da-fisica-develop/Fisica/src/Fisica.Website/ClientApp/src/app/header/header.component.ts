import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { LoginComponent } from '../usuario-comum/usuario/login/login.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToastComponent } from '../components-genericos';
import { Store } from '@ngrx/store';
import { loadUsuarioState, selecionarConta, selecionarTipoUsuario } from '../store';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit  {
  imagem: string= "";
  resumoTopico: string = "";
  resumoTitulo: string = "";
  telaInicial: boolean = true;

  stateUsuario$: Observable<any> = new Observable<any>();
  tipoUsuario: number = 0;
  nomeUsuario: string = "";
  loginUsuario: string = "";

  constructor (
    public dialog: MatDialog,
    public store: Store,
    private router: Router,

  ) {
    this.imagem = "../../assets/imagens/header/home.png";
    this.resumoTitulo = "Home";
    this.resumoTopico = "Página Inicial, resumo sobre a Física e ultimas postagens.";
    
    this.store.dispatch(loadUsuarioState());
  }

  ngOnInit(): void {
    this.stateUsuario$ = this.store.select(selecionarConta);
    this.stateUsuario$.subscribe(item => {
      this.tipoUsuario = item.tipoUsuario;
      this.nomeUsuario = item.nome;
      this.loginUsuario = item.login;
    });
  }

  modalCriarConta() {
    this.dialog.open(LoginComponent, {
      maxHeight: '800px',
      height: 'auto',
    });
  }

  acessarPerfil() {
    switch(this.tipoUsuario) {
      case 1:
        this.router.navigate([`perfil/${this.loginUsuario}`]);
      break;
    case 2:
    case 3:
      this.router.navigate([`professor-perfil/${this.nomeUsuario}`]);
      break;
    case 4:
      this.router.navigate([`admin-perfil/${this.nomeUsuario}`]);
    }
  }

  mudarCabecalho(cabecalho: boolean) {
    this.telaInicial= cabecalho;
  }

  mudaFoto (foto: string)
	{
		switch(foto) {
      case "0":
        this.imagem = "../../../assets/imagens/header/home.png";
        this.resumoTitulo = "Home";
        this.resumoTopico = "Página Inicial, resumo sobre a Física e ultimas postagens.";
        break;
      case "1":
        this.imagem = "../../../assets/imagens/header/mecanica.png";
        this.resumoTitulo = "Mecânica";
        this.resumoTopico = "O que é a velocidade? Podemos prever o movimento dos planetas? Isto é respondido aqui.";
        break;
      case "2":
        this.imagem = "../../../assets/imagens/header/termodinamica.png";
        this.resumoTitulo = "Termodinâmica";
        this.resumoTopico = "Aqui descobriremos o que é o calor, temperatura e muitos outros conceitos.";
        break;
      case "3":
        this.imagem = "../../../assets/imagens/header/ondulatoria.png";
        this.resumoTitulo = "Ondulatória";
        this.resumoTopico = "Vamos compreender juntos como o som se propaga e porquê não existe som no espaço.";
        break;
      case "4":
        this.imagem = "../../../assets/imagens/header/eletromagnetismo.png";
        this.resumoTitulo = "Eletormagnetismo";
        this.resumoTopico = "O que é corrente alternada? Vamos juntos compreender as leis do eletromagnetismo.";
        break;
      case "5":
        this.imagem = "../../../assets/imagens/header/fisicamoderna.png";
        this.resumoTitulo = "Física moderna";
        this.resumoTopico = "Nesse tópico vamos movimento relativístico e as pequenas partículas";
        break;
      case "6":
        this.imagem = "../../../assets/imagens/header/matematica.png";
        this.resumoTitulo = "Matemática";
        this.resumoTopico = "Aqui discutiremos os principais conceitos matemáticos que nos ajudaram a compreender os fenômenos físicos.";
        break;
      case "7":
        this.imagem = "../../../assets/imagens/header/especiais.png";
        this.resumoTitulo = "Especiais";
        this.resumoTopico = "Aqui vamos trabalhar alguns tópicos especiais como: história da física, cosmologia, experimentos, etc.";
        break;
      case "8":
        this.imagem = "../../../assets/imagens/header/vestibular.png";
        this.resumoTitulo = "Vestibular";
        this.resumoTopico = "Se você quer praticar exercícios de vestibular e se preparar para ingressar numa universidade, aqui é o lugar certo.";
        break;
      case "9":
        //this.imagem = "../../../assets/imagens/header/vestibular.png";
        this.resumoTitulo = "Fórum";
        this.resumoTopico = "Aqui você pode discutir Física com outros usuários. Faça e responda perguntas, ajude a desvendar os misterios da Física.";
        break;
      case "10":
        //this.imagem = "../../../assets/imagens/header/vestibular.png";
        this.resumoTitulo = "Criar conta";
        this.resumoTopico = "Crie sua conta fique por dentro de tudo.";
        break;
    }
	}

}
