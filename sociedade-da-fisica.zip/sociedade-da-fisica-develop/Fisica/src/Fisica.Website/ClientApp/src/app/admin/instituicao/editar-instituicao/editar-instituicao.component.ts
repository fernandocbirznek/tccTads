import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ToastComponent } from 'src/app/components-genericos';
import { AtualizarInstituicaoCommand, Cidade, Endereco, Instituicao } from 'src/app/shared';
import { CidadeService } from 'src/app/shared/services/cidade.service';
import { atualizarInstituicao, getCidades, selecionarCidades } from 'src/app/store';

@Component({
  selector: 'app-editar-instituicao',
  templateUrl: './editar-instituicao.component.html',
  styleUrls: ['./editar-instituicao.component.css']
})
export class EditarInstituicaoComponent implements OnInit {

  formCadastrar: FormGroup = null as any;

  nome = new FormControl('', [Validators.required]);
  email = new FormControl('', [Validators.required, Validators.email]);
  site = new FormControl('', [Validators.required]);
  descricao = new FormControl('', [Validators.maxLength(500)]);
  logradouro = new FormControl('', [Validators.maxLength(100)]);
  numero = new FormControl('', [Validators.maxLength(10)]);
  estado = new FormControl({value: 'PR', disabled: true}, [Validators.required]);
  cidade = new FormControl('', [Validators.required]);
  bairro = new FormControl('');

  cidades$: Observable<Cidade[]> = new Observable<Cidade[]>();
  cidades: Cidade[] = [];

  constructor(
    public dialogRef: MatDialogRef<EditarInstituicaoComponent>,
    public store: Store,
    private snackBar: MatSnackBar,
    public cidadeService: CidadeService,
    @Inject(MAT_DIALOG_DATA) public instituicao: Instituicao
  ) { 
    this.store.dispatch(selecionarCidades());
  }

  ngOnInit() {
    this.criarFormularioCadastrar(this.instituicao);
    this.cidades$ = this.store.select(getCidades);
    this.cidades$.subscribe(item => this.cidades = item);
  }

  criarFormularioCadastrar(instituicao: Instituicao) {
    console.log("chegando = ", instituicao);
    this.formCadastrar = new FormGroup({
      cadastrar_nome: new FormControl({value: instituicao.nome, disabled: false}, [Validators.required]),
      cadastrar_email: new FormControl({value: instituicao.email, disabled: false}, [Validators.required, Validators.email]),
      cadastrar_site: new FormControl({value: instituicao.site, disabled: false}, [Validators.required]),
      cadastrar_descricao: new FormControl({value: instituicao.descricao, disabled: false}, [Validators.maxLength(500)]),
      cadastrar_logradouro: new FormControl({value: instituicao.endereco?.logradouro, disabled: false}, [Validators.maxLength(100)]),
      cadastrar_numero: new FormControl({value: instituicao.endereco?.numero, disabled: false}, [Validators.maxLength(10)]),
      cadastrar_estado: new FormControl({value: 'PR', disabled: true}, [Validators.required]),
      cadastrar_cidade: new FormControl({value: instituicao.endereco?.cidadeId, disabled: false}, [Validators.required]),
      cadastrar_bairro: new FormControl({value: instituicao.endereco?.bairro, disabled: false})
    })
  }

  inserir() {
    if(this.validarCampos()) {
      let instituicao: AtualizarInstituicaoCommand = new AtualizarInstituicaoCommand();

      instituicao.nome = this.formCadastrar.get("cadastrar_nome")?.value;
      instituicao.email = this.formCadastrar.get("cadastrar_email")?.value;
      instituicao.site = this.formCadastrar.get("cadastrar_site")?.value;
      instituicao.descricao = this.formCadastrar.get("cadastrar_descricao")?.value;
      instituicao.logradouro = this.formCadastrar.get("cadastrar_logradouro")?.value;
      instituicao.numero = this.formCadastrar.get("cadastrar_numero")?.value;
      instituicao.bairro = this.formCadastrar.get("cadastrar_bairro")?.value;
      
      let cidade: Cidade | undefined = this.cidades.find(item => item.id == this.formCadastrar.get("cadastrar_cidade")?.value);

      instituicao.cidadeId = cidade!.id;
      instituicao.uF = cidade!.uf;
      instituicao.instituicaoId = this.instituicao.id;

      this.store.dispatch(atualizarInstituicao({ atualizarInstituicao: instituicao }));
      this.formCadastrar.reset();
      this.dialogRef.close();
    }
  }

  fecharModal() {
    this.dialogRef.close();
  }

  validarCampos() {
    let retorno: boolean = true;
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_estado")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Estado");
      this.formCadastrar.get("cadastrar_estado")?.markAsTouched();
      retorno = false;
    }
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_cidade")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Cidade");
      this.formCadastrar.get("cadastrar_cidade")?.markAsTouched();
      retorno = false;
    }
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_site")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Site");
      this.formCadastrar.get("cadastrar_site")?.markAsTouched();
      retorno = false;
    }
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_email")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Email");
      this.formCadastrar.get("cadastrar_email")?.markAsTouched();
      retorno = false;
    }
    if(this.verificarCampo(this.formCadastrar.get("cadastrar_nome")?.value)) {
      this.notificacaoValidacao("Deve preencher campo nome");
      this.formCadastrar.get("cadastrar_nome")?.markAsTouched();
      retorno = false;
    }
    return retorno;
  }

  verificarCampo(campo: any) {
    if(campo == "" || campo == undefined || campo == null)
      return true;
    return false;
  }

  notificacaoValidacao(item: string) {
    this.snackBar.openFromComponent(ToastComponent, {
      data: item,
      duration: 5 * 1000,
      panelClass: 'css-toast',
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }

}
