export class SessaoAula {
  constructor(
    public id?: number,
    public aulaId?: number,
    public titulo?: string,
    public conteudo?: string,
    public ordem?: number,
    public tipoSessao?: number,
    public favorita?: boolean
  ) { }
}
