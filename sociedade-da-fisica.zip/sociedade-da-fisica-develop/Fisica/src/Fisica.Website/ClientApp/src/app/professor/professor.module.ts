import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ProfessorRoutes } from './professor.routing';
import { NgSelectModule } from '@ng-select/ng-select';
import { ProfessorPerfilComponent } from './professor-perfil';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MaterialModule } from '../angular-material-modules';
import { ProfessorTabelaAulaComponent } from './professor-tabela-aula/professor-tabela-aula.component';
import { ProfessorTabelaNoticiaComponent } from './professor-tabela-noticia/professor-tabela-noticia.component';
import { ProfessorAlterarPerfilComponent } from './professor-alterar-perfil/professor-alterar-perfil.component';
import { NoticiaModule } from '../noticia';


@NgModule({
  declarations: [
    ProfessorPerfilComponent,
    ProfessorTabelaAulaComponent,
    ProfessorTabelaNoticiaComponent,
    ProfessorAlterarPerfilComponent
  ],
  imports: [
    CommonModule,
    NoticiaModule,
    FormsModule,
    RouterModule.forChild(ProfessorRoutes),
    NgSelectModule,
    FlexLayoutModule,
    MaterialModule,
  ]
})
export class ProfessorModule { }
