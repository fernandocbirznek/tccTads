export class ComentarioAula {
  constructor(
    public id?: number,
    public aulaId?: number,
    public dataCadastro?: string,
    public descricao?: string,
    public nomeUsuario?: string,
    public usuarioCadastroLogin?: string,
    public usuarioCadastroId?: number
  ) { }
}
