import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions/instituicao.actions';
import { InstituicaoService } from 'src/app/shared/services/instituicao.service';

@Injectable()
export class InstituicaoEffects {

  constructor(
    private actions$: Actions,
    private instituicaoService: InstituicaoService) 
  {}

  selecionarInstituicoes$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarInstituicao),
      concatMap((action) =>
        this.instituicaoService.getInstituicoes(action.usuarioId).pipe(
          map(response => actions.selecionarInstituicaoSuccess({ response: response })),
          catchError(error => of(actions.selecionarInstituicaoFailure({ error }))))
      )
    );
  });

  selecionarInstituicaoById$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarInstituicaoById),
      concatMap((action) =>
        this.instituicaoService.getInstituicaoById(action.InstituicaoId).pipe(
          map(response => actions.selecionarInstituicaoByIdSuccess({ response: response })),
          catchError(error => of(actions.selecionarInstituicaoByIdFailure({ error }))))
      )
    );
  });

  inserirInstituicao$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.inserirInstituicao),
      concatMap((action) =>
        this.instituicaoService.inserir(action.instituicao).pipe(
          map(response => actions.inserirInstituicaoSuccess({ instituicao: action.instituicao, response: response })),
          catchError(error => of(actions.inserirInstituicaoFailure({ error }))))
      )
    );
  });

  atualizarInstituicao$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.atualizarInstituicao),
      concatMap((action) =>
        this.instituicaoService.atualizarInstituicao(action.atualizarInstituicao).pipe(
          map(response => actions.atualizarInstituicaoSuccess({ atualizarInstituicao: action.atualizarInstituicao, response: response })),
          catchError(error => of(actions.atualizarInstituicaoFailure({ error })))
        )
      )
    );
  });

  excluirInstituicao$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.excluirInstituicao),
      concatMap((action) =>
        this.instituicaoService.excluir(action.instituicaoId).pipe(
          map(response => actions.excluirInstituicaoSuccess({ instituicaoId: action.instituicaoId, response: response })),
          catchError(error => of(actions.excluirInstituicaoFailure({ error })))
        )
      )
    );
  });

}
