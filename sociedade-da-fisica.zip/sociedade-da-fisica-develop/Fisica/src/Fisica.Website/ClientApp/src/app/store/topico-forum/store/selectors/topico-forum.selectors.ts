import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromTopicoForum from '../reducers/topico-forum.reducers';

export const selectTopicoForumState = createFeatureSelector<fromTopicoForum.TopicoForumState>(
    fromTopicoForum.topicoForumFeatureKey
);

export const getTopicoForum = createSelector(selectTopicoForumState, (state) => {
    return state.topicoForum;
})
