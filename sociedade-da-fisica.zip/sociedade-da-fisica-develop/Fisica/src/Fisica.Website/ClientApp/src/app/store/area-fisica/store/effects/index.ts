export * from './area-fisica.effects';
