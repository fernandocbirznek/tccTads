import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, concatMap, map } from 'rxjs/operators';

import { AreaFisicaService } from '../../../../shared/services/area-fisica.service';
import * as actions from '../actions/area-fisica.actions';

@Injectable()
export class AreaFisicaEffects {

  constructor(
    private actions$: Actions,
    private areaFisicaService: AreaFisicaService
  ) { }

  selecionarAreasFisica = createEffect(() => {
    return this.actions$.pipe(
      ofType(actions.selecionarAreasFisica),
      concatMap((action) =>
        this.areaFisicaService.selecionarAreasFisica().pipe(
          map(response => actions.selecionarAreasFisicaSuccess({ response: response })),
          catchError(error => of(actions.selecionarAreasFisicaFailure({ error }))))
      )
    );
  });
}
