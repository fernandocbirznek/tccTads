import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AdminRoutes } from './admin.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { ListarUsuariosComponent } from './usuario/listar-usuarios/listar-usuarios.component';
import { InserirUsuarioComponent } from './usuario/inserir-usuario/inserir-usuario.component';
import { ListarInstituicoesComponent } from './instituicao/listar-instituicoes/listar-instituicoes.component';
import { InserirInstituicaoComponent } from './instituicao/inserir-instituicao/inserir-instituicao.component';
import { EditarInstituicaoComponent } from './instituicao/editar-instituicao/editar-instituicao.component';
import { AdminPerfilComponent } from './admin-perfil/admin-perfil.component';
import { AdminTabelaUsuarioComponent } from './admin-tabela-usuario/admin-tabela-usuario.component';
import { AdminTabelaProfessorComponent } from './admin-tabela-professor/admin-tabela-professor.component';
import { AdminTabelaInstituicaoComponent } from './admin-tabela-instituicao/admin-tabela-instituicao.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MaterialModule } from '../angular-material-modules';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { AdminTabelaAdministradorComponent } from './admin-tabela-administrador/admin-tabela-administrador.component';

@NgModule({
  declarations: [
    ListarInstituicoesComponent,
    InserirInstituicaoComponent,
    EditarInstituicaoComponent,
    ListarUsuariosComponent,
    InserirUsuarioComponent,
    AdminPerfilComponent,
    AdminTabelaUsuarioComponent,
    AdminTabelaProfessorComponent,
    AdminTabelaInstituicaoComponent,
    AdminTabelaAdministradorComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(AdminRoutes),
    NgSelectModule,
    FlexLayoutModule,
    MaterialModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule, 
  ]
})
export class AdminModule { }
