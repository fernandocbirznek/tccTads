export * from './area-fisica.module';
