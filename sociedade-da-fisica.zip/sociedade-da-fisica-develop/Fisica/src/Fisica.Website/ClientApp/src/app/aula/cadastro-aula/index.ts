export * from './cadastro-aula.component';
