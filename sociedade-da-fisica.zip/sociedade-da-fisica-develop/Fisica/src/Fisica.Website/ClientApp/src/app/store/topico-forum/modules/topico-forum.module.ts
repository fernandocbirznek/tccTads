import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import * as fromTopicoForum from '../store/reducers/topico-forum.reducers';
import { EffectsModule } from '@ngrx/effects';
import { TopicoForumEffects } from '../store/effects/topico-forum.effects';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoreModule.forFeature(fromTopicoForum.topicoForumFeatureKey, fromTopicoForum.topicoForumReducer),
    EffectsModule.forFeature([TopicoForumEffects])
  ]
})
export class TopicoForumModule { }
