export * from './professor-alterar-perfil';
export * from './professor-perfil';
export * from './professor.module';
export * from './professor.routing';