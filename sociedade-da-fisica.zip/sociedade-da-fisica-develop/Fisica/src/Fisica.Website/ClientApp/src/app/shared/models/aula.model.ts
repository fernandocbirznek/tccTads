import { ComentarioAula } from "./comentario-aula.model";
import { SessaoAula } from "./sessao-aula.model";

export class Aula {
  constructor(
    public id?: number,
    public titulo?: string,
    public descricao?: string,
    public dataCadastroExtenso?: string,
    public areaFisica?: string,
    public areaFisicaId?: string,
    public professorNome?: string,
    public professorLogin?: string,
    public professorId?: number,
    public professorSeguido?: boolean,
    public sessoes?: SessaoAula[],
    public comentarios?: ComentarioAula[],
    public favorita?: boolean,
    public paraCursar?: boolean,
    public cursando?: boolean,
    public concluidas?: boolean,
    public visualizacoes?: number,
    public conteudoPesquisa?: string
  ) { }
}
