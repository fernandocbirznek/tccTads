import { createAction, props } from '@ngrx/store';
import { Noticia } from 'src/app/shared/models/noticia.model';

export const selecionarNoticias = createAction(
  '[Noticia] selecionarNoticias',
);
  
export const selecionarNoticiasSuccess = createAction(
  '[Noticia] selecionarNoticias Success',
  props<{ response: Noticia[] }>()
);
  
export const selecionarNoticiasFailure = createAction(
  '[Noticia] selecionarNoticias Failure',
  props<{ error: any }>()
);

export const selecionarNoticiaById = createAction(
  '[Noticia] selecionarNoticiaById',
  props<{ noticiaId: number }>()
);
  
export const selecionarNoticiaByIdSuccess = createAction(
  '[Noticia] selecionarNoticiaById Success',
  props<{ response: Noticia }>()
);
  
export const selecionarNoticiaByIdFailure = createAction(
  '[Noticia] selecionarNoticiaById Failure',
  props<{ error: any }>()
);

export const inserirNoticia = createAction(
  '[Noticia] inserirNoticia',
  props<{ noticia: Noticia }>()
);
  
export const inserirNoticiaSuccess = createAction(
  '[Noticia] inserirNoticia Success',
  props<{ noticia: Noticia, response: any }>()
);

export const inserirNoticiaFailure = createAction(
  '[Noticia] inserirNoticia Failure',
  props<{ error: any }>()
);

export const atualizarNoticia = createAction(
  '[Noticia] atualizarNoticia',
  props<{ noticiaAlterar: Noticia }>()
);

export const atualizarNoticiaSuccess = createAction(
  '[Noticia] atualizarNoticia Success',
  props<{ noticiaAlterar: Noticia, response: any }>()
);

export const atualizarNoticiaFailure = createAction(
  '[Noticia] atualizarNoticia Failure',
  props<{ error: any }>()
);

export const excluirNoticia = createAction(
  '[Noticia] excluirNoticia',
  props<{ noticiaId: number }>()
);

export const excluirNoticiaSuccess = createAction(
  '[Noticia] excluirNoticia Success',
  props<{ noticiaId: number, response: any }>()
);

export const excluirNoticiaFailure = createAction(
  '[Noticia] excluirNoticia Failure',
  props<{ error: any }>()
);