import { ActionReducerMap, MetaReducer } from "@ngrx/store";
import { contaReducer, ContaState } from "../conta";
import { TemaForumState, temaForumReducer } from "../tema-forum";
import { TopicoForumState, topicoForumReducer } from "../topico-forum";
import { UsuarioState, usuarioReducer } from "../usuario";
import { InstituicaoState, instituicaoReducer } from "../instituicao";
import { InformacaoSistemaState, informacaoSistemaReducer } from "../informacao-sistema";

export interface AppState {
    Conta: ContaState,
    TemaForum: TemaForumState,
    TopicoForum: TopicoForumState,
    Usuario: UsuarioState,
    Instituicao: InstituicaoState,
    InformacaoSistema: InformacaoSistemaState
};

export const reducers: ActionReducerMap<AppState> = {
    Conta: contaReducer,
    TemaForum: temaForumReducer,
    TopicoForum: topicoForumReducer,
    Usuario: usuarioReducer,
    Instituicao: instituicaoReducer,
    InformacaoSistema: informacaoSistemaReducer
}

export const metaReducers: MetaReducer<AppState>[] = [];