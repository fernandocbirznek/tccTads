import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromAula from '../reducers/aula.reducers';

export const selectAulaState = createFeatureSelector<fromAula.AulaState>(
  fromAula.aulaFeatureKey
);

export const getAulas = createSelector(selectAulaState, (state) => {
  return state.aula;
})

export const getAulasProfessor = createSelector(selectAulaState, (state) => {
  return state.professorAulas;
})