import { Action, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/informacao-sistema.actions';
import { InformacaoSistema } from 'src/app/shared';

export const informacaoSistemaFeatureKey = 'informacao-sistema';

export interface InformacaoSistemaState {
    itens: InformacaoSistema;
    isSuccess: boolean;
    isLoading: boolean;
    isFailure: boolean;
    mensagem: string;
}

export const informacaoSistemaInitialState: InformacaoSistemaState = {
    itens: null as any,
    isSuccess: false,
    isLoading: false,
    isFailure: false,
    mensagem: "",
};

export const informacaoSistemaReducer = createReducer(
    informacaoSistemaInitialState,

  on(actions.selecionarInformacaoSistema, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarInformacaoSistemaSuccess, (state, action) => {
    let itens: InformacaoSistema = action.response;

    return { 
      ...state, 
      itens: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.selecionarInformacaoSistemaFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar as informações do sistema"};
  }),
);
