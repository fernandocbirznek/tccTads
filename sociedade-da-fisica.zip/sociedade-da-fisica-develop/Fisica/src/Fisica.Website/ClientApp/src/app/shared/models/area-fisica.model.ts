export class AreaFisica {
  constructor(
    public id?: number,
    public descricao?: string
  ) { }
}
