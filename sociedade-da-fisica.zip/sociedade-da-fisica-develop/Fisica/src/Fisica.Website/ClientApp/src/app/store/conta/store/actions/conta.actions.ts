import { createAction, props } from '@ngrx/store';
import { Aula, Favorito, InformacoesPerfil, Segue, WidgetAula } from 'src/app/shared';
import { AutocadastroModel } from 'src/app/shared/models/autocadastro.model';
import { Login } from 'src/app/shared/models/login';
import { UsuarioLoginModel } from 'src/app/shared/models/usuario-login.model';

export const autoCadastroConta = createAction(
  '[AutoCadastro] AutoCadastroConta',
  props<{ autocadastro: AutocadastroModel }>()
);

export const autoCadastroContaSuccess = createAction(
    '[AutoCadastro] AutoCadastroConta Success',
    props<{ autocadastro: AutocadastroModel, response: any }>()
);

export const autoCadastroContaFailure = createAction(
    '[AutoCadastro] AutoCadastroConta Failure',
    props<{ error: any }>()
);

export const loginConta = createAction(
  '[Login] LoginConta',
  props<{ login: Login }>()
);

export const loginContaSuccess = createAction(
  '[Login] LoginConta Success',
  props<{ login: Login, response: UsuarioLoginModel }>()
);

export const loginContaFailure = createAction(
  '[Login] LoginConta Failure',
  props<{ response: any }>()
);

export const deslogarConta = createAction(
  '[DeslogarConta] DeslogarConta',
);

export const deslogarContaSuccess = createAction(
  '[DeslogarConta] DeslogarContaSuccess',
  props<{ response: any }>()
);

export const deslogarContaFailure = createAction(
  '[DeslogarConta] DeslogarContaFailure',
  props<{ response: any }>()
);

export const loadUsuarioState = createAction(
  '[Load] Load Usuario State'
);

export const selecionarInformacoesPerfil = createAction(
  '[selecionarInformacoesPerfil] selecionarInformacoesPerfil',
  props<{ loginUsuario: string }>()
);

export const selecionarInformacoesPerfilSuccess = createAction(
  '[selecionarInformacoesPerfil] selecionarInformacoesPerfil Success',
  props<{ loginUsuario: string, response: InformacoesPerfil }>()
);

export const selecionarInformacoesPerfilFailure = createAction(
  '[selecionarInformacoesPerfil] selecionarInformacoesPerfil Failure',
  props<{ error: any }>()
);

export const selecionarWidgetAulas = createAction(
  '[selecionarWidgetAulas] selecionarWidgetAulas'
);

export const selecionarWidgetAulasSuccess = createAction(
  '[selecionarWidgetAulas] selecionarWidgetAulas Success',
  props<{ response: WidgetAula[] }>()
);

export const selecionarWidgetAulasFailure = createAction(
  '[selecionarWidgetAulas] selecionarWidgetAulas Failure',
  props<{ error: any }>()
);

export const inserirAulaWidget = createAction(
  '[inserirAulaWidget] inserirAulaWidget',
  props<{ aula: Aula, widget: string }>()
);

export const inserirAulaWidgetSuccess = createAction(
  '[inserirAulaWidget] inserirAulaWidget Success',
  props<{ aula: Aula, widget: string }>()
);

export const inserirAulaWidgetFailure = createAction(
  '[inserirAulaWidget] inserirAulaWidget Failure',
  props<{ error: any }>()
);

export const excluirAulaWidget = createAction(
  '[excluirAulaWidget] excluirAulaWidget',
  props<{ aulaId: number, widget: string }>()
);

export const excluirAulaWidgetSuccess = createAction(
  '[excluirAulaWidget] excluirAulaWidget Success',
  props<{ aulaId: number, widget: string }>()
);

export const excluirAulaWidgetFailure = createAction(
  '[excluirAulaWidget] excluirAulaWidget Failure',
  props<{ error: any }>()
);

export const atualizarAulaWidget = createAction(
  '[atualizarAulaWidget] atualizarAulaWidget',
  props<{ aula: Aula, widgetAntigo: string, widgetNovo: string }>()
);

export const atualizarAulaWidgetSuccess = createAction(
  '[atualizarAulaWidget] atualizarAulaWidget Success',
  props<{ aula: Aula, widgetAntigo: string, widgetNovo: string }>()
);

export const atualizarAulaWidgetFailure = createAction(
  '[atualizarAulaWidget] atualizarAulaWidget Failure',
  props<{ error: any }>()
);

export const selecionarAulasFavoritadas = createAction(
  '[selecionarAulasFavoritadas] selecionarAulasFavoritadas'
);

export const selecionarAulasFavoritadasSuccess = createAction(
  '[selecionarAulasFavoritadas] selecionarAulasFavoritadas Success',
  props<{ response: Favorito[] }>()
);

export const selecionarAulasFavoritadasFailure = createAction(
  '[selecionarAulasFavoritadas] selecionarAulasFavoritadas Failure',
  props<{ error: any }>()
);

export const excluirFavoritado = createAction(
  '[excluirFavoritado] excluirFavoritado',
  props<{ favoritoId: number, aulaId: number, sessaoAulaId: number }>()
);

export const excluirFavoritadoSuccess = createAction(
  '[excluirFavoritado] excluirFavoritado Success',
  props<{ favoritoId: number, aulaId: number, sessaoAulaId: number }>()
);

export const excluirFavoritadoFailure = createAction(
  '[excluirFavoritado] excluirFavoritado Failure',
  props<{ error: any }>()
);

export const selecionarProfessorSegue = createAction(
  '[selecionarProfessorSegue] selecionarProfessorSegue'
);

export const selecionarProfessorSegueSuccess = createAction(
  '[selecionarProfessorSegue] selecionarProfessorSegue Success',
  props<{ response: Segue[] }>()
);

export const selecionarProfessorSegueFailure = createAction(
  '[selecionarProfessorSegue] selecionarProfessorSegue Failure',
  props<{ error: any }>()
);