import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromAreaFisica from '../reducer';

export const selectAreasFisicaState = createFeatureSelector<fromAreaFisica.AreaFisicaState>(
  fromAreaFisica.areaFisicaFeatureKey
);

export const getAreasFisica = createSelector(selectAreasFisicaState, (state) => {
    return state.items;
})
