import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Aula } from '../models/aula.model';
import { AbstractHttpService } from './abstract-http.service';

@Injectable({
  providedIn: 'root'
})
export class AulaService extends AbstractHttpService {

  constructor(@Inject('BASE_URL') baseUrl: string, httpClient: HttpClient) {
    super(baseUrl, httpClient, 'api/aula');
  }

  public buscarAula(id: number): Observable<Aula> {
    return this.get(`selecionar-aula/${id}`)
  }

  public inserir(aula: Aula): Observable<Aula> {
    return this.post<Aula>('inserir', aula);
  }

  public atualizar(aula: Aula): Observable<Aula> {
    return this.put<Aula>('atualizar', aula);
  }

  public selecionarAulasPorAreaFisica(areaFisicaId: number): Observable<Aula[]> {
    return this.get<Aula[]>(`selecionar-aulas/${areaFisicaId}`);
  }

  public buscarAulasPorTitulo(titulo: string) {

    return this.get<Aula>(`buscar-aulas/${titulo}`)
  }

  public buscarAulasPorProfessorId(): Observable<Aula[]> {
    return this.get<Aula[]>(`buscar-professor-aulas`)
  }

  public excluirAula(aulaId: number): Observable<void> {
    return this.delete(`excluir/${aulaId}`);
  }
}
