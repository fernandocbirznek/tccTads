import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Noticia } from 'src/app/shared/models/noticia.model';
import { Tag } from 'src/app/shared/models/tag.model';
import { inserirNoticia } from 'src/app/store';

@Component({
  selector: 'app-cadastro-noticia',
  templateUrl: './cadastro-noticia.component.html',
  styleUrls: ['./cadastro-noticia.component.css']
})
export class CadastroNoticiaComponent implements OnInit {
  formNoticia: FormGroup = null as any;
  titulo = new FormControl('', [Validators.required]);
  //resumo = new FormControl('', [Validators.required]);
  noticia = new FormControl('', [Validators.required]);

  tags: Tag[] = [];
  tagsSelecionadas: Tag[] = [];

  @ViewChild("editor", { static: false }) editor: any;

  constructor(
    public store: Store,
    public router: Router
  ) {
    this.tags = [
      {id: 1, nome: "Mecânica", checked: false},
      {id: 2, nome: "Termodinâmica", checked: false},
      {id: 3, nome: "Ondulatória", checked: false},
      {id: 4, nome: "Física moderna", checked: false},
      {id: 5, nome: "Eletromagnetismo", checked: false},
      {id: 6, nome: "Matemática", checked: false},
      {id: 7, nome: "Outros", checked: false},
    ]
  }

  ngOnInit(): void {
    this.criarFormularioNoticia(new Noticia());
  }

  criarFormularioNoticia(noticia: Noticia) {
    this.formNoticia = new FormGroup({
      cadastrar_noticia: new FormControl(noticia.conteudo),
      titulo: new FormControl(noticia.titulo),
      //resumo: new FormControl(noticia.resumo),
    })
  }

  tagSelecionada(tag: Tag) {
    if(!this.tagsSelecionadas.find(item => item.id == tag.id))
      this.tagsSelecionadas.push({...tag, checked: true})
    else 
      this.tagsSelecionadas = this.tagsSelecionadas.filter(item => item.id != tag.id)
  }

  cadastrar() {
    let noticia: Noticia = new Noticia();
    noticia.conteudo = this.editor._data;
    noticia.titulo = this.formNoticia.get("titulo")?.value;
    //noticia.resumo = this.formNoticia.get("resumo")?.value;
    noticia.tags = JSON.stringify(this.tagsSelecionadas);
    // noticia.autorId = this.formNoticia.get("autor_id")?.value;
    // noticia.autorNome = this.formNoticia.get("autor_nome")?.value;
    this.store.dispatch(inserirNoticia({ noticia: noticia }));
    this.router.navigate(['professor-perfil/teste']);
  }

  voltar() {
    this.router.navigate(['professor-perfil/teste']);
  }

}
