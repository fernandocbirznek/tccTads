import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import * as fromInstituicao from '../store/reducers/instituicao.reducers';
import { EffectsModule } from '@ngrx/effects';
import { InstituicaoEffects } from '../store/effects/instituicao.effects';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoreModule.forFeature(fromInstituicao.instituicaoFeatureKey, fromInstituicao.instituicaoReducer),
    EffectsModule.forFeature([InstituicaoEffects])
  ]
})
export class InstituicaoModule { }
