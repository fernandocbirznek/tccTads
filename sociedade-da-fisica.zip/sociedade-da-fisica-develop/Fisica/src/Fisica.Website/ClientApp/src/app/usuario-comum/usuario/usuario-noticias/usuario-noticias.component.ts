import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { VisualizarNoticiaComponent } from 'src/app/noticia/visualizar-noticia';
import { Noticia, Segue } from 'src/app/shared';
import { getManyProfessoresSegue, getNoticias } from 'src/app/store';

@Component({
  selector: 'app-usuario-noticias',
  templateUrl: './usuario-noticias.component.html',
  styleUrls: ['./usuario-noticias.component.css']
})
export class UsuarioNoticiasComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = ['titulo', 'autor', 'data-postagem', 'data-atualizacao', 'visualizacoes'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  noticias$: Observable<Noticia[]> = new Observable<Noticia[]>();
  professoresSegue$: Observable<Segue[]> = new Observable<Segue[]>();

  professorSelecionado: string = "";
  radioGroup: FormGroup = new FormGroup({radio: new FormControl()});

  constructor(
    public router: Router,
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.noticias$ = this.store.select(getNoticias);
    this.professoresSegue$ = this.store.select(getManyProfessoresSegue);
  }

  public ngOnInit() {
    this.noticias$.subscribe(noticias => {
      this.dataSource = new MatTableDataSource(noticias)
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  aplicarFiltro(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  criarNoticia() {
    this.router.navigate(['noticia/cadastro']);
  }

  acessarNoticia(noticiaId: number) {
    this.dialog.open(VisualizarNoticiaComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: noticiaId
    });
  }

  filtrarNoticiaProfessor(professor: string | undefined) {
    if(this.professorSelecionado == professor) {
      this.radioGroup.get('radio')!.reset();
      professor = "";
    }
    this.professorSelecionado = professor!;
    const filterValue = professor;
    this.dataSource.filter = filterValue!.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
