import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AreaFisica, Aula, SessaoAula } from '../../shared';
import { AulaService } from '../../shared/services/aula.service';
import { NotificacoesService } from '../../shared/services/notificacoes.service';
import { getAreasFisica, selecionarAreasFisica } from '../../store';
import { atualizarAula, getAulas, inserirAula } from '../../store/aula';
import { CadastroSessaoComponent } from '../cadastro-sessao/cadastro-sessao.component';
import { EditarSessaoComponent } from '../editar-sessao/editar-sessao.component';

@Component({
  selector: 'app-editar-aula',
  templateUrl: './editar-aula.component.html',
  styleUrls: ['./editar-aula.component.css']
})
export class EditarAulaComponent implements OnInit {

  aulaId?: number;
  aula: Aula;
  formAula: FormGroup = null as any;

  exibirLoading: boolean;
  titulo = new FormControl('', [Validators.required, Validators.maxLength(200)]);
  descricao = new FormControl('', [Validators.required, Validators.maxLength(400)]);

  constructor(
    public store: Store,
    private route: ActivatedRoute,
    private router: Router,
    public dialog: MatDialog,
    private notificacoesService: NotificacoesService,
    private aulaService: AulaService
  ) {
    this.aula = new Aula();
    this.aula.sessoes = [];
    this.aulaId = 0;
    this.exibirLoading = true;
  }

  areas$: Observable<AreaFisica[]> = new Observable<AreaFisica[]>();
  aula$: Observable<Aula> = new Observable<Aula>();
  areas: AreaFisica[] = [];

  public async ngOnInit(): Promise<void> {
    this.criarFormularioAula(this.aula);
    this.store.dispatch(selecionarAreasFisica());
    this.areas$ = this.store.select(getAreasFisica);
    this.aula$ = this.store.select(getAulas);
    this.areas$.subscribe(item => this.areas = item);
    this.aulaId = parseInt(this.route.snapshot.paramMap.get('id')!);

    if (!this.aulaId) {
      //TO-DO: Redirecionar
    }

    await this.buscarAula();
  }

  private async buscarAula(): Promise<void> {
    this.aula = (await this.aulaService.buscarAula(this.aulaId!).toPromise())!;

    if (this.aula.professorId != localStorage["uid"]) {
      this.notificacoesService.mostrarErro("Você nao pode editar esta aula.");
      //TO-DO: Redirecionar
    }

    this.formAula.get("titulo_aula")!.setValue(this.aula.titulo);
    this.formAula.get("descricao_aula")!.setValue(this.aula.descricao);
    this.formAula.get("areafisica_aula")!.setValue(this.aula.areaFisicaId);
    this.titulo.setValue(this.aula.titulo!);
    this.descricao.setValue(this.aula.descricao!);
    this.exibirLoading = false;
  }

  private criarFormularioAula(aula: Aula) {
    this.formAula = new FormGroup({
      titulo_aula: new FormControl(aula.titulo),
      descricao_aula: new FormControl(aula.descricao),
      areafisica_aula: new FormControl(aula.areaFisicaId)
    });
  }

  public abrirModalNovaSessao(): void {
    this.dialog.open(CadastroSessaoComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '920px',
      data: this.aula
    });
  }

  public drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.aula.sessoes!, event.previousIndex, event.currentIndex);
    this.reordenarSessoes();
  }

  public reordenarSessoes(): void {
    let ordem = 1;
    this.aula.sessoes!.forEach((sessao) => {
      sessao.ordem = ordem;
      ordem++;
    });
  }

  public async salvar(): Promise<void> {
    if (this.formAula.valid) {
      this.aula.titulo = this.formAula.get("titulo_aula")?.value;
      this.aula.descricao = this.formAula.get("descricao_aula")?.value;
      this.aula.areaFisicaId = this.formAula.get("areafisica_aula")?.value;
      this.store.dispatch(atualizarAula({ aula: this.aula }));
      this.formAula.reset();
      this.notificacoesService.mostrarSucesso('Aula atualizada com sucesso!');
    }

    //TO-DO: Redirecionar pra algum lugar
  }

  public removerSessao(sessao: SessaoAula): void {
    let indice = this.aula.sessoes?.indexOf(sessao)!;
    this.aula.sessoes?.splice(indice, 1);
    this.reordenarSessoes();
  }

  public editarSessao(sessao: SessaoAula): void {
    this.dialog.open(EditarSessaoComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '920px',
      data: sessao
    });
  }

  public voltar(): void {
    var login = localStorage.getItem('loginUsuario');
    this.router.navigate(['/professor-perfil/' + login]);
  }
}
