import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalEditarAulaWidgetComponent } from './modal-editar-aula-widget.component';

describe('ModalEditarAulaWidgetComponent', () => {
  let component: ModalEditarAulaWidgetComponent;
  let fixture: ComponentFixture<ModalEditarAulaWidgetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModalEditarAulaWidgetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ModalEditarAulaWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
