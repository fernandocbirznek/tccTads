import { Instituicao } from "./instituicao.model";
import { Perfil } from "./perfil.model";

export class Usuario {
  constructor(
    public id?: number,
    public nome?: string,
    public email?: string,
    public cpf?: string,
    public login?: string,
    public senha?: string,
    public tipoUsuario?: number,
    public perfil?: Perfil,
    public instituicao?: Instituicao,
    public instituicaoId?: number,
    public sobreMim?: string,
    public dataCadastro?: Date,
    public comentario?: number,
    public topico?: number,
    public aulasFavoritadas?: number,
    public dataUltimoComentario?: Date,
    public dataUltimaPostagem?: Date
  ) { }
}
