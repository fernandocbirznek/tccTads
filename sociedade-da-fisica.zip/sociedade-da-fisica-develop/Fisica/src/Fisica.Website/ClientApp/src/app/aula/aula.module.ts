import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VisualizarAulaComponent } from './visualizar-aula';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgSelectModule } from '@ng-select/ng-select';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MaterialModule } from '../angular-material-modules';
import { AulaRoutes } from './aula.routing';
import { CadastroAulaComponent } from './cadastro-aula';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { StoreModule } from '@ngrx/store';
import { CadastroSessaoComponent } from './cadastro-sessao/cadastro-sessao.component';
import { BrowserModule } from '@angular/platform-browser';
import { SharedModule } from '../shared/shared.module';
import { EditarSessaoComponent } from './editar-sessao/editar-sessao.component';
import { EditarAulaComponent } from './editar-aula/editar-aula.component';

import { KatexModule } from 'ng-katex';
import { CKEditorModule } from 'ckeditor4-angular';

@NgModule({
  declarations: [
    CadastroAulaComponent,
    VisualizarAulaComponent,
    CadastroSessaoComponent,
    EditarSessaoComponent,
    EditarAulaComponent
  ],
  imports: [
    CommonModule,
    KatexModule,
    CKEditorModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule, 
    RouterModule.forChild(AulaRoutes),
    NgSelectModule,
    FlexLayoutModule,
    MaterialModule,
    StoreModule,
    NgSelectModule,
    BrowserModule,
    SharedModule
  ]
})
export class AulaModule { }
