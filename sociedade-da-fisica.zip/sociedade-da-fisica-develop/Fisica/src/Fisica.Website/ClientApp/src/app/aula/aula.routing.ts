import { Routes } from "@angular/router";
import { CadastroAulaComponent } from "./cadastro-aula";
import { EditarAulaComponent } from "./editar-aula/editar-aula.component";
import { VisualizarAulaComponent } from "./visualizar-aula";


export const AulaRoutes: Routes = [
  { path: 'aula/cadastro', component: CadastroAulaComponent },
  { path: 'aula/editar/:id', component: EditarAulaComponent },
  { path: 'aula/:id', component: VisualizarAulaComponent }
];
