import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromInstituicao from '../reducers/instituicao.reducers';
import { Instituicao  } from 'src/app/shared';

export const selectInstituicaoState = createFeatureSelector<fromInstituicao.InstituicaoState>(
    fromInstituicao.instituicaoFeatureKey
);

export const getInstituicoes = createSelector(selectInstituicaoState, (state) => {
    return state.instituicoes;
})

export const getInstituicaoById = (instituicaoId: number) => createSelector(getInstituicoes, (instituicoes) => {
    let instituicao = instituicoes.find(item => item.id == instituicaoId);
    if(instituicao == undefined)
        return new Instituicao();
    return instituicao;
})
