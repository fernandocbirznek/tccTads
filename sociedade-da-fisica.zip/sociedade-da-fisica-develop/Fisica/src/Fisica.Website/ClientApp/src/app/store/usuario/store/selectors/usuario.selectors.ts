import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromUsuario from '../reducers/usuario.reducers';

export const selectUsuarioState = createFeatureSelector<fromUsuario.UsuarioState>(
    fromUsuario.usuarioFeatureKey
);

export const getUsuarioComum = createSelector(selectUsuarioState, (state) => {
    return state.usuarioComum;
})

export const getUsuarioProfessor = createSelector(selectUsuarioState, (state) => {
    return state.usuarioProfessor;
})

export const getUsuarioAdministrador = createSelector(selectUsuarioState, (state) => {
    return state.usuarioAdministrador;
})