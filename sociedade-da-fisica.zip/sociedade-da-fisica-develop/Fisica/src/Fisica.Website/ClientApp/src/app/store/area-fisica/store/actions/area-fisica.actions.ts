import { createAction, props } from '@ngrx/store';
import { AreaFisica } from '../../../../shared/models/area-fisica.model';

export const selecionarAreasFisica = createAction(
  '[AreaFisica] selecionarAreasFisica'
);

export const selecionarAreasFisicaSuccess = createAction(
  '[AreaFisica] selecionarAreasFisica Success',
  props<{ response: AreaFisica[] }>()
);

export const selecionarAreasFisicaFailure = createAction(
  '[AreaFisica] selecionarAreasFisica Failure',
  props<{ error: any }>()
);
