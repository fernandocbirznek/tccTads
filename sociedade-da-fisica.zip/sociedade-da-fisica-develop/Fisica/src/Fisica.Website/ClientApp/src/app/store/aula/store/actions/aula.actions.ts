import { createAction, props } from '@ngrx/store';
import { Aula } from 'src/app/shared/models/aula.model';

export const selecionarAula = createAction(
  '[Aula] selecionarAula',
  props<{ aulaId: number }>()
);

export const selecionarAulaSuccess = createAction(
  '[Aula] selecionarAula Success',
  props<{ AulaId: number, response: Aula }>()
);

export const selecionarAulaFailure = createAction(
  '[Aula] selecionarAula Failure',
  props<{ error: any }>()
);

export const selecionarAulaByProfessorId = createAction(
  '[Aula] selecionarAulaByProfessorId'
);

export const selecionarAulaByProfessorIdSuccess = createAction(
  '[Aula] selecionarAulaByProfessorId Success',
  props<{ response: Aula[] }>()
);

export const selecionarAulaByProfessorIdFailure = createAction(
  '[Aula] selecionarAulaByProfessorId Failure',
  props<{ error: any }>()
);

export const inserirAula = createAction(
  '[Aula] inserirAula',
  props<{ aula: Aula }>()
);

export const inserirAulaSuccess = createAction(
  '[Aula] inserirAula Success',
  props<{ aula: Aula, response: Aula }>()
);

export const inserirAulaFailure = createAction(
  '[Aula] inserirAula Failure',
  props<{ error: any }>()
);

export const atualizarAula = createAction(
  '[Aula] atualizarAula',
  props<{ aula: Aula }>()
);

export const atualizarAulaSuccess = createAction(
  '[Aula] atualizarAula Success',
  props<{ aula: Aula, response: Aula }>()
);

export const atualizarAulaFailure = createAction(
  '[Aula] atualizarAula Failure',
  props<{ error: any }>()
);

export const excluirAula = createAction(
  '[Aula] excluirAula',
  props<{ aulaId: number }>()
);

export const excluirAulaSuccess = createAction(
  '[Aula] excluirAula Success',
  props<{ aulaId: number }>()
);

export const excluirAulaFailure = createAction(
  '[Aula] excluirAula Failure',
  props<{ error: any }>()
);
