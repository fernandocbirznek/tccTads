import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions/topico-forum.actions';
import { TopicoForumService } from 'src/app/shared/services/topico-forum.service';
import { RespostaTopicoService } from 'src/app/shared/services/resposta-topico.service';
import { ReplicaService } from 'src/app/shared/services/replica.service';

@Injectable()
export class TopicoForumEffects {

  constructor (
        private actions$: Actions,
        private topicoForumService: TopicoForumService,
        private respostaTopicoService: RespostaTopicoService,
        private replicaService: ReplicaService,
    ) {}

  selecionarTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarTopicoForum),
      concatMap((action) =>
        this.topicoForumService.selecionarTopicoForum(action.topicoForumId).pipe(
          map(response => actions.selecionarTopicoForumSuccess({ topicoForumId: action.topicoForumId, response: response })),
          catchError(error => of(actions.selecionarTopicoForumFailure({ error }))))
      )
    );
  });

  atualizarTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.atualizarTopicoForum),
      concatMap((action) =>
        this.topicoForumService.atualizarTopicoForum(action.topicoForum).pipe(
          map(response => actions.atualizarTopicoForumSuccess({ topicoForum: action.topicoForum, response: response })),
          catchError(error => of(actions.atualizarTopicoForumFailure({ error }))))
      )
    );
  });

  inserirRespostaTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.inserirRespostaTopicoForum),
      concatMap((action) =>
        this.respostaTopicoService.inserirResposta(action.respostaTopico).pipe(
          map(response => actions.inserirRespostaTopicoSuccess({ respostaTopico: action.respostaTopico, response: response })),
          catchError(error => of(actions.inserirRespostaTopicoFailure({ error }))))
      )
    );
  });

  atualizarRespostaTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.atualizarRespostaTopico),
      concatMap((action) =>
        this.respostaTopicoService.atualizarRespostaTopico(action.atualizarRespostaTopico).pipe(
          map(response => actions.atualizarRespostaTopicoSuccess({ atualizarRespostaTopico: action.atualizarRespostaTopico, response: response })),
          catchError(error => of(actions.atualizarRespostaTopicoFailure({ error }))))
      )
    );
  });

  excluirRespostaTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.excluirRespostaTopicoForum),
      concatMap((action) =>
        this.respostaTopicoService.excluirResposta(action.excluirRespostaTopicoId).pipe(
          map(response => actions.excluirRespostaTopicoSuccess({ excluirRespostaTopicoId: action.excluirRespostaTopicoId })),
          catchError(error => of(actions.excluirRespostaTopicoFailure({ error }))))
      )
    );
  });

  inserirReplicaTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.inserirReplicaTopicoForum),
      concatMap((action) =>
        this.replicaService.inserirReplica(action.replicaTopico).pipe(
          map(response => actions.inserirReplicaTopicoSuccess({ replicaTopico: action.replicaTopico, response: response })),
          catchError(error => of(actions.inserirReplicaTopicoFailure({ error }))))
      )
    );
  });

  atualizarReplicaTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.atualizarReplicaTopico),
      concatMap((action) =>
        this.replicaService.atualizarReplica(action.atualizarReplicaTopico).pipe(
          map(response => actions.atualizarReplicaTopicoSuccess({ atualizarReplicaTopico: action.atualizarReplicaTopico, response: response })),
          catchError(error => of(actions.atualizarReplicaTopicoFailure({ error }))))
      )
    );
  });

  excluirReplicaTopicoForum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.excluirReplicaTopicoForum),
      concatMap((action) =>
        this.replicaService.excluirReplica(action.excluirReplicaTopicoId).pipe(
          map(response => actions.excluirReplicaTopicoSuccess({ excluirReplicaTopicoId: action.excluirReplicaTopicoId, topicoForumId: action.topicoForumId })),
          catchError(error => of(actions.excluirReplicaTopicoFailure({ error }))))
      )
    );
  });
}
