import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Aula, WidgetAula } from 'src/app/shared';
import { atualizarAulaWidget, excluirAulaWidget, selecionarAulasWidget } from 'src/app/store';
import { ModalEditarAulaWidgetComponent } from '../modal-editar-aula-widget';
import { ModalExcluirComponent } from 'src/app/components-genericos';

@Component({
  selector: 'app-widget-aula-concluida',
  templateUrl: './widget-aula-concluida.component.html',
  styleUrls: ['./widget-aula-concluida.component.css']
})
export class WidgetAulaConcluidaComponent implements OnInit, AfterViewInit {

  aulasWidget$: Observable<WidgetAula[]> = new Observable<WidgetAula[]>();

  displayedColumns: string[] = ['titulo', 'descricao', 'acao'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(
    public store: Store,
    public dialog: MatDialog,
  ) {
  }

  public ngOnInit() {
    this.setupAulasWidget();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  setupAulasWidget() {
    this.aulasWidget$ = this.store.select(selecionarAulasWidget);
    this.aulasWidget$.subscribe(itens => {
      itens.forEach(item => {
        if(item.descricao == "Concluídas")
          this.dataSource = new MatTableDataSource(item.aulas);
      })
    });
  }

  aplicarFiltro(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  editarAula(item: Aula) {
    this.dialog.open(ModalEditarAulaWidgetComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: { aula: item, widget: "Concluída" }
    });
  }

  excluirAula(item: Aula) {
    this.dialog.open(ModalExcluirComponent, {
      data: `${item.titulo}`
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.store.dispatch(excluirAulaWidget({ aulaId: item.id!, widget: "Concluídas" }));
      }
    });
  }
}
