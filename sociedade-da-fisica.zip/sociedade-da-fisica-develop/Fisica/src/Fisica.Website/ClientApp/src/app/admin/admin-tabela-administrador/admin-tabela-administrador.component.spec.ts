import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTabelaAdministradorComponent } from './admin-tabela-administrador.component';

describe('AdminTabelaAdministradorComponent', () => {
  let component: AdminTabelaAdministradorComponent;
  let fixture: ComponentFixture<AdminTabelaAdministradorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminTabelaAdministradorComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminTabelaAdministradorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
