import { createAction, props } from '@ngrx/store';
import { InformacaoSistema } from 'src/app/shared';

export const selecionarInformacaoSistema = createAction(
  '[InformacaoSistema] selecionarInstituicao',
);
  
export const selecionarInformacaoSistemaSuccess = createAction(
  '[InformacaoSistema] selecionarInstituicao Success',
  props<{ response: InformacaoSistema }>()
);
  
export const selecionarInformacaoSistemaFailure = createAction(
  '[InformacaoSistema] selecionarInstituicao Failure',
  props<{ error: any }>()
);
