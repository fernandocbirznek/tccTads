import { createAction, props } from '@ngrx/store';
import { AtualizarInstituicaoCommand, Instituicao } from 'src/app/shared';

export const selecionarInstituicao = createAction(
  '[Instituicao] selecionarInstituicao',
  props<{ usuarioId: number }>()
);
  
export const selecionarInstituicaoSuccess = createAction(
  '[Instituicao] selecionarInstituicao Success',
  props<{ response: Instituicao[] }>()
);
  
export const selecionarInstituicaoFailure = createAction(
  '[Instituicao] selecionarInstituicao Failure',
  props<{ error: any }>()
);

export const selecionarInstituicaoById = createAction(
  '[Instituicao] selecionarInstituicaoById',
  props<{ InstituicaoId: number }>()
);
  
export const selecionarInstituicaoByIdSuccess = createAction(
  '[Instituicao] selecionarInstituicaoById Success',
  props<{ response: Instituicao }>()
);
  
export const selecionarInstituicaoByIdFailure = createAction(
  '[Instituicao] selecionarInstituicaoById Failure',
  props<{ error: any }>()
);

export const inserirInstituicao = createAction(
  '[Instituicao] inserirInstituicao',
  props<{ instituicao: Instituicao }>()
);
  
export const inserirInstituicaoSuccess = createAction(
  '[Instituicao] inserirInstituicao Success',
  props<{ instituicao: Instituicao, response: any }>()
);

export const inserirInstituicaoFailure = createAction(
  '[Instituicao] inserirInstituicao Failure',
  props<{ error: any }>()
);

export const atualizarInstituicao = createAction(
  '[Instituicao] atualizarInstituicao',
  props<{ atualizarInstituicao: AtualizarInstituicaoCommand }>()
);

export const atualizarInstituicaoSuccess = createAction(
  '[Instituicao] atualizarInstituicao Success',
  props<{ atualizarInstituicao: AtualizarInstituicaoCommand, response: any }>()
);

export const atualizarInstituicaoFailure = createAction(
  '[Instituicao] atualizarInstituicao Failure',
  props<{ error: any }>()
);

export const excluirInstituicao = createAction(
  '[Instituicao] excluirInstituicao',
  props<{ instituicaoId: number }>()
);

export const excluirInstituicaoSuccess = createAction(
  '[Instituicao] excluirInstituicao Success',
  props<{ instituicaoId: number, response: any }>()
);

export const excluirInstituicaoFailure = createAction(
  '[Instituicao] excluirInstituicao Failure',
  props<{ error: any }>()
);