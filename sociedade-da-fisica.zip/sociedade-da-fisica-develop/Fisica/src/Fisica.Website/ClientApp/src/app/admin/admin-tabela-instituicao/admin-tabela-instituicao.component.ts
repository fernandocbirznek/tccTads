import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ModalExcluirComponent } from 'src/app/components-genericos';
import { Instituicao } from 'src/app/shared';
import { excluirInstituicao, getInstituicoes } from 'src/app/store';
import { InserirInstituicaoComponent } from '../instituicao/inserir-instituicao/inserir-instituicao.component';
import { EditarInstituicaoComponent } from '../instituicao';

@Component({
  selector: 'app-admin-tabela-instituicao',
  templateUrl: './admin-tabela-instituicao.component.html',
  styleUrls: ['./admin-tabela-instituicao.component.css']
})
export class AdminTabelaInstituicaoComponent implements OnInit, AfterViewInit  {


  displayedColumns: string[] = ['nome', 'descricao', 'quantidade-professores', 'acao'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  instituicoes$: Observable<Instituicao[]> = new Observable<Instituicao[]>();

  constructor(
    public router: Router,
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.instituicoes$ = this.store.select(getInstituicoes);
  }

  public ngOnInit() {
    this.instituicoes$.subscribe(instituicoes => {
      this.dataSource = new MatTableDataSource(instituicoes)
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  aplicarFiltro(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  criarInstituicao() {
    this.dialog.open(InserirInstituicaoComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%'
    });
  }

  acessarInstituicao(instituicao: Instituicao) {

  }

  editarInstituicao(instituicao: Instituicao) {
    this.dialog.open(EditarInstituicaoComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: instituicao
    });
  }

  excluirInstituicao(instituicao: Instituicao) {
    this.dialog.open(ModalExcluirComponent, {
      data: `Excluir instituição: ${instituicao.nome}`
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.store.dispatch(excluirInstituicao( {instituicaoId: instituicao.id! } ));
      }
    });
  }
}
