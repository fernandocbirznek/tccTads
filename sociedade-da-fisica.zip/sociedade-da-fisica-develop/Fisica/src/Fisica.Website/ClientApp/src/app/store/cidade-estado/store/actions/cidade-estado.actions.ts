import { createAction, props } from "@ngrx/store";
import { Cidade } from "src/app/shared";

export const selecionarCidades = createAction(
    '[Cidade] selecionarCidades',
  );
    
  export const selecionarCidadesSuccess = createAction(
    '[Cidade] selecionarCidades Success',
    props<{ response: Cidade[] }>()
  );
    
  export const selecionarCidadesFailure = createAction(
    '[Cidade] selecionarCidades Failure',
    props<{ error: any }>()
  );