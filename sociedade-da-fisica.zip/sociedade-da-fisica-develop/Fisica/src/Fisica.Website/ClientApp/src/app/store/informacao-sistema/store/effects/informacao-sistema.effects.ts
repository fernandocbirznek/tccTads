import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions/informacao-sistema.actions';
import { InformacaoSistemaService } from 'src/app/shared/services/informacao-sistema.service';
import { InstituicaoService } from 'src/app/shared/services/instituicao.service';

@Injectable()
export class InformacaoSistemaEffects {

  constructor(
        private actions$: Actions,
        private informacaoSistema: InformacaoSistemaService,
        private instituicaoService: InstituicaoService
    ) {}

  selecionarInformacaoSistema$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarInformacaoSistema),
      concatMap(() =>
        this.instituicaoService.getInformacaoSistema().pipe(
          map(response => actions.selecionarInformacaoSistemaSuccess({ response: response })),
          catchError(error => of(actions.selecionarInformacaoSistemaFailure({ error }))))
      )
    );
  });
}
