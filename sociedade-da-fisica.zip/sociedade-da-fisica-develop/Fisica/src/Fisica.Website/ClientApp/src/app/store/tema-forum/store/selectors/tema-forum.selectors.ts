import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromTemaForum from '../reducers/tema-forum.reducers';

export const selectTemaForumState = createFeatureSelector<fromTemaForum.TemaForumState>(
    fromTemaForum.temaForumFeatureKey
);

export const getTopicosTemaForum = createSelector(selectTemaForumState, (state) => {
    return state.topicosForum;
})