import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-visualizar-favoritado',
  templateUrl: './visualizar-favoritado.component.html',
  styleUrls: ['./visualizar-favoritado.component.css']
})
export class VisualizarFavoritadoComponent implements OnInit {
    
  constructor(
    public dialogRef: MatDialogRef<VisualizarFavoritadoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
   }

  public ngOnInit(): void {
  }

  public fechar(): void {
    this.dialogRef.close();
  }
}
