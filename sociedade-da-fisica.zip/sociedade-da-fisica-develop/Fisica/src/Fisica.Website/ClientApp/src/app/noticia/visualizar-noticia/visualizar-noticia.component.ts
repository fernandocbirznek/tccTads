import { AfterViewInit, Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Noticia } from 'src/app/shared';
import { getNoticiaById, selecionarNoticiaById } from 'src/app/store';

@Component({
  selector: 'app-visualizar-noticia',
  templateUrl: './visualizar-noticia.component.html',
  styleUrls: ['./visualizar-noticia.component.scss']
})
export class VisualizarNoticiaComponent implements OnInit, AfterViewInit {

  @ViewChild("editor", { static: false }) editor: any;
    
  noticia$: Observable<Noticia> = new Observable<Noticia>();
  noticia: Noticia = new Noticia();

  constructor(
    public dialogRef: MatDialogRef<VisualizarNoticiaComponent>,
    public store: Store,
    @Inject(MAT_DIALOG_DATA) public data: number
  ) {
    this.store.dispatch(selecionarNoticiaById({ noticiaId: this.data }));
    this.noticia$ = this.store.select(getNoticiaById(this.data));
   }

  public ngOnInit(): void {
    this.noticia$.subscribe(item => {
      let noticia = {...item, tagsTela: JSON.parse(item.tags)};
      this.noticia = noticia;
    })
  }

  public ngAfterViewInit(): void {
    this.editor.readOnly = true;
  }

  public fechar(): void {
    this.dialogRef.close();
  }
}
