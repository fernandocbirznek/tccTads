import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ModalExcluirComponent } from 'src/app/components-genericos';
import { VisualizarNoticiaComponent } from 'src/app/noticia/visualizar-noticia';
import { Noticia } from 'src/app/shared';
import { excluirNoticia, getNoticiasByIdProfessor } from 'src/app/store';

@Component({
  selector: 'app-professor-tabela-noticia',
  templateUrl: './professor-tabela-noticia.component.html',
  styleUrls: ['./professor-tabela-noticia.component.css']
})
export class ProfessorTabelaNoticiaComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = ['titulo', 'data-postagem', 'acao'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  noticias$: Observable<Noticia[]> = new Observable<Noticia[]>();

  constructor(
    public router: Router,
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.noticias$ = this.store.select(getNoticiasByIdProfessor(parseInt(localStorage.getItem("uid")!)));
  }

  public ngOnInit() {
    this.noticias$.subscribe(noticias => {
      this.dataSource = new MatTableDataSource(noticias)
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  aplicarFiltro(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  criarNoticia() {
    this.router.navigate(['noticia/cadastro']);
  }

  acessarNoticia(noticiaId: number) {
    this.dialog.open(VisualizarNoticiaComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: noticiaId
    });
  }

  editarNoticia(item: number) {
    this.router.navigate([`noticia/alterar/${item}`]);
  }

  excluirNoticia(item: number) {
    this.dialog.open(ModalExcluirComponent, {
      data: 'Notícia'
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.store.dispatch(excluirNoticia( {noticiaId: item} ));
      }
    });
  }
}
