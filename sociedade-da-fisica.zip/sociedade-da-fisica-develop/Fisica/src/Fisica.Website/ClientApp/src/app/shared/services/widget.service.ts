import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { WidgetAula } from '../models/widget.model';
import { AbstractHttpService } from './abstract-http.service';

@Injectable({
  providedIn: 'root'
})
export class WidgetService extends AbstractHttpService {

  constructor(@Inject('BASE_URL') baseUrl: string, httpClient: HttpClient) {
    super(baseUrl, httpClient, 'api/widget');
  }

  public inserirAula(aulaId: number, widget: string): Observable<void> {
    return this.post('inserir-aula', { AulaId: aulaId, Widget: widget });
  }

  public excluirAula(aulaId: number, widget: string): Observable<void> {
    return this.delete(`excluir-aula`, { AulaId: aulaId, Widget: widget });
  }

  public selecionarWigetsAulas(): Observable<WidgetAula[]> {
    return this.get<WidgetAula[]>('selecionar-widgets-aulas');
  }
}
