import { createReducer, on } from '@ngrx/store';
import { AreaFisica } from '../../../../shared/models/area-fisica.model';
import * as actions from '../actions/area-fisica.actions';

export const areaFisicaFeatureKey = 'area-fisica';

export interface AreaFisicaState {
    items: AreaFisica[];
    isSuccess: boolean;
    isLoading: boolean;
    isFailure: boolean;
    mensagem: string;
}

export const areaFisicaInitialState: AreaFisicaState = {
    items: null as any,
    isSuccess: false,
    isLoading: false,
    isFailure: false,
    mensagem: "",
};

export const AreaFisicaReducer = createReducer(
  areaFisicaInitialState,

  on(actions.selecionarAreasFisica, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarAreasFisicaSuccess, (state, action) => {

    let items: AreaFisica[] = action.response;
    return { 
      ...state, 
      items: items,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.selecionarAreasFisicaFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar áreas da física."};
  }),
);
