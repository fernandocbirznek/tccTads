import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsuarioEdicaoModalComponent } from './usuario-edicao-modal.component';

describe('UsuarioEdicaoModalComponent', () => {
  let component: UsuarioEdicaoModalComponent;
  let fixture: ComponentFixture<UsuarioEdicaoModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsuarioEdicaoModalComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UsuarioEdicaoModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
