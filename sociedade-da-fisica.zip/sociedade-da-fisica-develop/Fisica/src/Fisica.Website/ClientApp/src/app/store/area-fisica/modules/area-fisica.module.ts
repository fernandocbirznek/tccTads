import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import * as fromAreaFisica from '../store';
import { EffectsModule } from '@ngrx/effects';
import { AreaFisicaEffects } from '../store';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoreModule.forFeature(fromAreaFisica.areaFisicaFeatureKey, fromAreaFisica.AreaFisicaReducer),
    EffectsModule.forFeature([AreaFisicaEffects])
  ]
})
export class AreaFisicaModule { }
