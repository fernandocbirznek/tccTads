import { Component } from '@angular/core';

@Component({
  selector: 'app-professor-alterar-perfil',
  templateUrl: './professor-alterar-perfil.component.html',
  styleUrls: ['./professor-alterar-perfil.component.css']
})
export class ProfessorAlterarPerfilComponent {

}
