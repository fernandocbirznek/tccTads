export class Tag {
	id: number = 0;
	nome: string = "";
	checked: boolean = false;
}