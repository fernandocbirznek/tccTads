import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ModalExcluirComponent } from 'src/app/components-genericos';
import { Aula, Favorito } from 'src/app/shared';
import { excluirFavoritado, selecionarFavoritos } from 'src/app/store';
import { VisualizarFavoritadoComponent } from '../visualizar-favoritado';

@Component({
  selector: 'app-aulas-favoritadas',
  templateUrl: './aulas-favoritadas.component.html',
  styleUrls: ['./aulas-favoritadas.component.css']
})
export class AulasFavoritadasComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = ['titulo', 'descricao', 'acao'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  favoritos$: Observable<Favorito[]> = new Observable<Favorito[]>();

  constructor(
    public router: Router,
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.favoritos$ = this.store.select(selecionarFavoritos);
    this.favoritos$.subscribe(item => {
      this.dataSource = new MatTableDataSource(item);
    })
  }

  public ngOnInit() {

  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  aplicarFiltro(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  criarAula() {
    this.router.navigate(['aula/cadastro']);
  }

  visualizarFavoritado(aulaNome: string, conteudo: string) {
    this.dialog.open(VisualizarFavoritadoComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: {aulaNome: aulaNome, conteudo: conteudo}
    });
  }

  excluirFavoritado(item: Favorito) {
    this.dialog.open(ModalExcluirComponent, {
      data: `Retirar do favorito: ${item.aulaNome}`
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.store.dispatch(excluirFavoritado({ favoritoId: item.id!, aulaId: item.id!, sessaoAulaId: item.sessaoAulaId! }));
      }
    });
  }
}
