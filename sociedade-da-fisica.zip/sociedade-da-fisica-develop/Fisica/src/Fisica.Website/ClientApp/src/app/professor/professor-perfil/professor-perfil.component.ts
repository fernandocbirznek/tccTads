import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { deslogarConta, selecionarConta, selecionarNoticias } from 'src/app/store';
import { selecionarAulaByProfessorId } from 'src/app/store/aula';
import { AdministrarInstituicaoComponent } from '../../shared/components/administrar-instituicao/administrar-instituicao.component';
import { InfoUsuario } from '../../shared/models/info-usuario.model';
import { UsuarioService } from '../../shared/services/usuario.service';

@Component({
  selector: 'app-professor-perfil',
  templateUrl: './professor-perfil.component.html',
  styleUrls: ['./professor-perfil.component.css']
})
export class ProfessorPerfilComponent implements OnInit {

  selecionado: string = '0';

  /**
   *  
    1)	Deve carregar as aulas e notícias cadastradas pelo professor.                                             OK
    2)	Deve ser possível filtrar as aulas e notícias postadas pelo professor.                                    OK
    3)	Deve carregar uma lista de últimas notícias postada no sistema ao acessar aba “notícias”.                 OK 
    4)	Deve ser possível filtrar notícias.                                                                       OK                                                                   
    5)	Deve ser possível cadastrar aula.                                                                         OK
    6)	Deve ser possível publicar notícia.                                                                       OK
    7)	Deve ser possível excluir aula/notícia.                                                                   OK
    8)	Deve ser possível alterar aula/notícia.                                                                   OK
    9)	Deve ser possível alterar perfil.
   *
   * */

  stateUsuario$: Observable<any> = new Observable<any>();
  nomeUsuario: string = "";

  infoUsuario: InfoUsuario;


  constructor(
    public store: Store,
    public router: Router,
    private usuarioService: UsuarioService,
    private modalService: NgbModal
  ) {
    this.store.dispatch(selecionarNoticias());
    this.store.dispatch(selecionarAulaByProfessorId());
    this.infoUsuario = new InfoUsuario();
  }

  public async ngOnInit(): Promise<void> {
    this.stateUsuario$ = this.store.select(selecionarConta);
    this.stateUsuario$.subscribe(item => {
      this.nomeUsuario = item.nome;
    });

    await this.buscarInfos();
  }

  public async buscarInfos(): Promise<void> {
    this.infoUsuario = (await this.usuarioService.getInfosUsuario(parseInt(this.usuarioService.getUsuarioId())).toPromise())!;
  }

  deslogar() {
    this.store.dispatch(deslogarConta());
    this.router.navigate(['']);
  }

  selecionou(item: string) {
    this.selecionado = item;
  }

  alterarPerfil() {

  }

  public abrirModalAdminsitracao(): void {
    //fazer uma modal que da pra ver os usuarios da instituicao, adicionar e remover

    let dialogSize = 'lg';
    const modalRef = this.modalService.open(AdministrarInstituicaoComponent, { size: dialogSize });

    modalRef.componentInstance.instituicaoId = this.infoUsuario.instituicaoId;

  }
}
