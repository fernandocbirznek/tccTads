import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgSelectModule } from '@ng-select/ng-select';
import { SharedModule } from '../shared/shared.module';
import { AutocadastroComponent, LoginComponent, WidgetAulasComponent } from './usuario';
import { DashboardUsuarioComponent } from './dashboard';
import { TelaInicialComponent } from './inicio/tela-inicial/tela-inicial.component';
import { AreasFisicaComponent } from './inicio/areas-fisica/areas-fisica.component';
import { ForumInicialComponent } from './forum/forum-inicial';
import { TemaForumComponent } from './forum/tema-forum';
import { TopicoForumComponent } from './forum/topico-forum';
import { ModalCadastroTopicoComponent } from './forum/modal-cadastro-topico';
import { UsuarioComumRoutes } from './usuario-comum.routing';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MaterialModule } from '../angular-material-modules';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NgxMaskDirective, NgxMaskPipe } from 'ngx-mask';
import { PerfilComponent } from './usuario/perfil/perfil.component';
import { ModalEdicaoTopicoComponent } from './forum/modal-edicao-topico/modal-edicao-topico.component';
import { ModalEdicaoRespostaComponent } from './forum/modal-edicao-resposta/modal-edicao-resposta.component';
import { ModalEdicaoReplicaComponent } from './forum/modal-edicao-replica/modal-edicao-replica.component';
import { UsuarioEdicaoModalComponent } from './usuario/usuario-edicao-modal/usuario-edicao-modal.component';
import { WidgetAulaCursandoComponent } from './usuario/widget-aula-cursando/widget-aula-cursando.component';
import { WidgetAulaConcluidaComponent } from './usuario/widget-aula-concluida/widget-aula-concluida.component';
import { ModalEditarAulaWidgetComponent } from './usuario/modal-editar-aula-widget/modal-editar-aula-widget.component';
import { UsuarioNoticiasComponent } from './usuario/usuario-noticias/usuario-noticias.component';
import { AulasFavoritadasComponent } from './usuario/aulas-favoritadas/aulas-favoritadas.component';
import { VisualizarFavoritadoComponent } from './usuario/visualizar-favoritado/visualizar-favoritado.component';
import { KatexModule } from 'ng-katex';
import { CKEditorModule } from 'ckeditor4-angular';

@NgModule({
  declarations: [
    LoginComponent,
    AutocadastroComponent,
    DashboardUsuarioComponent,
    TelaInicialComponent,
    AreasFisicaComponent,
    ForumInicialComponent,
    TemaForumComponent,
    TopicoForumComponent,
    ModalCadastroTopicoComponent,
    PerfilComponent,
    ModalEdicaoTopicoComponent,
    ModalEdicaoRespostaComponent,
    ModalEdicaoReplicaComponent,
    UsuarioEdicaoModalComponent,
    WidgetAulasComponent,
    WidgetAulaCursandoComponent,
    WidgetAulaConcluidaComponent,
    ModalEditarAulaWidgetComponent,
    UsuarioNoticiasComponent,
    AulasFavoritadasComponent,
    VisualizarFavoritadoComponent,
  ],
  imports: [
    CommonModule,
    KatexModule,
    CKEditorModule,
    FormsModule,
    RouterModule.forChild(UsuarioComumRoutes),
    NgSelectModule,
    SharedModule,
    MatFormFieldModule,
    ReactiveFormsModule, 
    MatInputModule,
    MaterialModule, 
    FlexLayoutModule,
    NgxMaskDirective, NgxMaskPipe,
  ]
})
export class UsuarioComumModule { }
