import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions/usuario.actions';
import { UsuarioService } from 'src/app/shared/services/usuario.service';

@Injectable()
export class UsuarioEffects {

  constructor (
        private actions$: Actions,
        private usuarioService: UsuarioService
    ) {}

  selecionarUsuarioComum$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarUsuarioComum),
      concatMap(() =>
        this.usuarioService.selecionarUsuariosComuns().pipe(
          map(response => actions.selecionarUsuarioComumSuccess({ response: response })),
          catchError(error => of(actions.selecionarUsuarioComumFailure({ error }))))
      )
    );
  });

  selecionarUsuarioProfessor$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarUsuarioProfessor),
      concatMap(() =>
        this.usuarioService.selecionarProfessores().pipe(
          map(response => actions.selecionarUsuarioProfessorSuccess({ response: response })),
          catchError(error => of(actions.selecionarUsuarioProfessorFailure({ error }))))
      )
    );
  });

  selecionarUsuarioAdministrador$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarUsuarioAdministrador),
      concatMap(() =>
        this.usuarioService.selecionarAdministradores().pipe(
          map(response => actions.selecionarUsuarioAdministradorSuccess({ response: response })),
          catchError(error => of(actions.selecionarUsuarioAdministradorFailure({ error }))))
      )
    );
  });

  atualizarUsuario$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.atualizarUsuario),
      concatMap((action) =>
        this.usuarioService.atualizarUsuario(action.usuario).pipe(
          map(response => actions.atualizarUsuarioSuccess({ usuario: action.usuario, response: response })),
          catchError(error => of(actions.atualizarUsuarioFailure({ error }))))
      )
    );
  });

  inserirUsuario$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.inserirUsuario),
      concatMap((action) =>
        this.usuarioService.autoCadastro(action.usuario).pipe(
          map(response => actions.inserirUsuarioSuccess({ usuario: action.usuario, response: response })),
          catchError(error => of(actions.inserirUsuarioFailure({ error }))))
      )
    );
  });

  excluirUsuario$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.excluirUsuario),
      concatMap((action) =>
        this.usuarioService.excluir(action.usuarioId).pipe(
          map(response => actions.excluirUsuarioSuccess({ usuarioId: action.usuarioId })),
          catchError(error => of(actions.excluirUsuarioFailure({ error }))))
      )
    );
  });

  atualizarTipoUsuario$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.atualizarTipoUsuario),
      concatMap((action) =>
        this.usuarioService.atualizarTipoUsuario(action.atualizarTipoUsuario).pipe(
          map(response => actions.atualizarTipoUsuarioSuccess({ atualizarTipoUsuario: action.atualizarTipoUsuario, response: response })),
          catchError(error => of(actions.atualizarTipoUsuarioFailure({ error }))))
      )
    );
  });
}
