import { Routes } from "@angular/router";
import { CadastroNoticiaComponent } from "./cadastro-noticia";
import { AlterarNoticiaComponent } from "./alterar-noticia";

export const NoticiaRoutes: Routes = [
  { path: 'noticia/cadastro', component: CadastroNoticiaComponent },
  { path: 'noticia/alterar/:noticiaAtualizar', component: AlterarNoticiaComponent }
];
