import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import * as $ from 'jquery';
import { ModalExcluirComponent } from '../../components-genericos';
import { SessaoAula } from '../../shared';
import { Aula } from '../../shared/models/aula.model';
import { ComentarioAula } from '../../shared/models/comentario-aula.model';
import { AulaService } from '../../shared/services/aula.service';
import { ComentarioAulaService } from '../../shared/services/comentario-aula.service';
import { FavoritoService } from '../../shared/services/favorito.service';
import { NotificacoesService } from '../../shared/services/notificacoes.service';
import { SegueService } from '../../shared/services/segue.service';
import { UsuarioService } from '../../shared/services/usuario.service';
import { WidgetService } from '../../shared/services/widget.service';


@Component({
  selector: 'app-visualizar-aula',
  templateUrl: './visualizar-aula.component.html',
  styleUrls: ['./visualizar-aula.component.css']
})
export class VisualizarAulaComponent implements OnInit {

  /**
   *  HU – Acessar aula postada
   * 
   *  Deve carregar a aula.                                           -> buscarAula();                                      OK
   *  Deve ser possível seguir o professor que publicou a aula.       -> seguirProfessor(); -> deixarDeSeguirProfessor();   OK
   *  Deve ser possível clicar em “adicionar aulas em favoritos”.     -> adicionarFavorito();                               OK
   *  Deve ser possível clicar em “retirar aula favoritada”.          -> removerFavorito();                                 OK
   *  Deve carregar comentários da aula.                              -> Já vem no buscarAula.                              OK
   *  Deve ser possível cadastrar um comentário aula.                 -> inserirComentario(); -> removerComentario();       OK
   *  Deve ser possível adicionar a aula em sua dashboard de estudos. -> adicionarWidget();
   *  Deve ser possível acessar o menu.                                                                                     OK
   *  Deve ser possível voltar para a tela anterior.                  //TO-DO
   *  Favoritar as sessoes                                                                                                  OK
   *
   * */

  @ViewChild("editor", { static: false }) editor: any;

  aulaId: number;
  aula: Aula;
  usuarioId: number;
  usuarioLogado: boolean;
  exibirLoading: boolean;
  //textoComentario: string;

  widgetParaCursar: boolean;
  widgetCursando: boolean;
  widgetConcluidas: boolean;

  constructor(
    private route: ActivatedRoute,
    private aulaService: AulaService,
    private segueService: SegueService,
    private favoritoService: FavoritoService,
    private comentarioService: ComentarioAulaService,
    private widgetService: WidgetService,
    private notificacoesService: NotificacoesService,
    private snackBar: MatSnackBar,
    private router: Router,
    private usuarioService: UsuarioService,
    private dialog: MatDialog
  ) {
    this.aulaId = 0;
    this.aula = new Aula();
    //this.textoComentario = "";
    this.usuarioId = 0;
    this.widgetParaCursar = false;
    this.widgetCursando = false;
    this.widgetConcluidas = false;
    this.usuarioLogado = false;
    this.exibirLoading = true;
  }

  initialData: string = "<p>Escreva seu comentário : )</p>"

  public async ngOnInit(): Promise<void> {
    if (!this.route.snapshot.paramMap.get('id')) {
      //redirecionar pois nao veio aula
    }
    this.aulaId = parseInt(this.route.snapshot.paramMap.get('id')!);
    await this.buscarAula();
    this.usuarioId = parseInt(this.usuarioService.getUsuarioId());
    this.usuarioLogado = !Number.isNaN(this.usuarioId);
    $('#favoritar-label').hide();

    this.changeFavoritoAula();
    this.aula.sessoes!.forEach(item => this.changeFavoritoSessao(item));

    this.changeSeguirProfessor();

    this.widgetParaCursar = this.aula.paraCursar!;
    this.widgetCursando = this.aula.cursando!;
    this.widgetConcluidas = this.aula.concluidas!;
  }

  private async buscarAula(): Promise<void> {
    this.aula = (await this.aulaService.buscarAula(this.aulaId).toPromise())!;
    this.exibirLoading = false;
  }

  public async seguirProfessor(): Promise<void> {
    if (!this.aula.professorSeguido) {
      await this.segueService.seguirProfessor(this.aula.professorId!).toPromise();
      this.notificacoesService.mostrarSucesso('Seguindo professor!');
      this.aula.professorSeguido = true;
    } else {
      await this.segueService.deixarDeSeguirProfessor(this.aula.professorId!).toPromise();
      this.notificacoesService.mostrarInformacao('Deixando de seguir professor...');
      this.aula.professorSeguido = false;
    }

    this.changeSeguirProfessor();
  }

  public async favoritar() {
    if (!this.aula.favorita) {
      await this.favoritoService.adicionarFavorito(this.aula.id, undefined).toPromise();
      this.notificacoesService.mostrarSucesso('Aula adicionada aos Favoritos!');
      this.aula.favorita = true;
    } else {
      await this.favoritoService.removerFavorito(this.aula.id, undefined).toPromise();
      this.notificacoesService.mostrarInformacao('Aula removida dos Favoritos...');
      this.aula.favorita = false;
    }
    this.changeFavoritoAula();
  }

  public async favoritarSessao(sessao: SessaoAula) {
    if (!sessao.favorita) {
      await this.favoritoService.adicionarFavorito(undefined, sessao.id).toPromise();
      this.notificacoesService.mostrarSucesso('Sessão adicionada aos Favoritos!');
      sessao.favorita = true;
    } else {
      await this.favoritoService.removerFavorito(undefined, sessao.id).toPromise();
      this.notificacoesService.mostrarInformacao('Sessão removida dos Favoritos...');
      sessao.favorita = false;
    }
    this.changeFavoritoSessao(sessao);
  }

  private async inserirComentario(): Promise<void> {
    let comentario = (await this.comentarioService.adicionarComentario(this.aulaId, this.editor._data).toPromise())!;
    this.aula.comentarios?.push(comentario);
    this.initialData = "<p>Escreva seu comentário : )</p>";
  }
  public async removerComentario(comentario: ComentarioAula): Promise<void> {
    this.dialog.open(ModalExcluirComponent, {
      data: 'este comentário'
    }).afterClosed().subscribe(async (evento) => {
      if (evento) {
        await this.comentarioService.excluirComentario(comentario.id!).toPromise();
        this.aula.comentarios!.splice(this.aula.comentarios!.indexOf(comentario), 1);
        this.notificacoesService.mostrarInformacao('Comentário removido...');
      }
    });
  }

  public comentar(): void {
    if (this.editor._data != "") {
      this.inserirComentario();
      this.notificacoesService.mostrarSucesso('Comentario inserido!');
    }
  }

  public abrirPerfilUsuario(login?: string): void {
    this.router.navigate([]).then(result => { window.open('/#/perfil' + '/' + login, '_blank'); });
  }

  private changeFavoritoAula(): void {
    var icon = $('#icon-favorito');
    if (this.aula.favorita) {
      $('#favoritar-label').text('Remover favorito');
      $('#favoritar-label').css('color', 'red');
      icon.css('color', 'green');

      icon.on('mouseover', function () {
        $('#icon-favorito').css('color', 'red');
        $('#favoritar-label').show();
      });
      $('#icon-favorito').on('mouseout', function () {
        icon.css('color', 'green');
        $('#favoritar-label').hide();
      });
    } else {
      $('#favoritar-label').text('Favoritar');
      $('#favoritar-label').css('color', 'gray');
      icon.css('color', 'black');

      $('#icon-favorito').on('mouseover', function () {
        icon.css('color', 'green');
        $('#favoritar-label').show();
      });
      $('#icon-favorito').on('mouseout', function () {
        icon.css('color', 'black');
        $('#favoritar-label').hide();
      });
    }
  }

  private changeFavoritoSessao(sessao: SessaoAula): void {
    var icon = $('#icon-favorito-' + sessao.id);
    if (sessao.favorita) {
      icon.css('color', 'green');

      icon.on('mouseover', function () {
        icon.css('color', 'red');
      });
      icon.on('mouseout', function () {
        icon.css('color', 'green');
      });
    } else {
      icon.css('color', 'black');

      icon.on('mouseover', function () {
        icon.css('color', 'green');
      });
      icon.on('mouseout', function () {
        icon.css('color', 'black');
      });
    }
  }

  private changeSeguirProfessor(): void {
    var button = $('#seguir-professor');
    if (this.aula.professorSeguido) {
      button.css('color', 'green');

      button.on('mouseover', function () {
        button.css('color', 'red');
      });
      button.on('mouseout', function () {
        button.css('color', 'green');
      });
    } else {
      button.css('color', 'gray');
      button.on('mouseover', function () {
        button.css('color', 'green');
      });
      button.on('mouseout', function () {
        button.css('color', 'gray');
      });
    }
  }

  public async widgetParaCursarClick(): Promise<void> {
    this.widgetParaCursar = !this.widgetParaCursar;

    if (this.widgetParaCursar) {
      await this.adicionarWidget('Para Cursar');
      this.notificacoesService.mostrarSucesso("Aula adicionada ao Widget 'Para Cursar'");
    } else {
      await this.removerWidget('Para Cursar');
      this.notificacoesService.mostrarInformacao("Aula removida do Widget...");
    }
  }

  public async widgetCursandoClick(): Promise<void> {
    this.widgetCursando = !this.widgetCursando;

    if (this.widgetCursando) {
      await this.adicionarWidget('Cursando');
      this.notificacoesService.mostrarSucesso("Aula adicionada ao Widget 'Cursando'");
    } else {
      await this.removerWidget('Cursando');
      this.notificacoesService.mostrarInformacao("Aula removida do Widget...");
    }
  }

  public async widgetConcluidaClick(): Promise<void> {
    this.widgetConcluidas = !this.widgetConcluidas;

    if (this.widgetConcluidas) {
      await this.adicionarWidget('Concluídas');
      this.notificacoesService.mostrarSucesso("Aula adicionada ao Widget 'Concluídas'");
    } else {
      await this.removerWidget('Concluídas');
      this.notificacoesService.mostrarInformacao("Aula removida do Widget...");
    }
  }

  private async adicionarWidget(widget: string): Promise<void> {
    await this.widgetService.inserirAula(this.aulaId, widget).toPromise();
  }

  private async removerWidget(widget: string): Promise<void> {
    await this.widgetService.excluirAula(this.aulaId, widget).toPromise();
  }

  public voltar(): void {
    let area = this.removeAcento(this.aula.areaFisica!);
    this.router.navigate([area]);
  }

  private removeAcento(text: string): string {
    text = text.toLowerCase();
    text = text.replace(new RegExp('[ÁÀÂÃ]', 'gi'), 'a');
    text = text.replace(new RegExp('[ÉÈÊ]', 'gi'), 'e');
    text = text.replace(new RegExp('[ÍÌÎ]', 'gi'), 'i');
    text = text.replace(new RegExp('[ÓÒÔÕ]', 'gi'), 'o');
    text = text.replace(new RegExp('[ÚÙÛ]', 'gi'), 'u');
    text = text.replace(new RegExp('[Ç]', 'gi'), 'c');
    return text;
  }
}
