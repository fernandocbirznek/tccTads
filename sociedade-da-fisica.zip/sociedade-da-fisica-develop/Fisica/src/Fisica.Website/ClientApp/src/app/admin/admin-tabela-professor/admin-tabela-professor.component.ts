import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ModalExcluirComponent } from 'src/app/components-genericos';
import { Usuario } from 'src/app/shared';
import { excluirUsuario, getUsuarioProfessor } from 'src/app/store';
import { AutocadastroComponent, UsuarioEdicaoModalComponent } from 'src/app/usuario-comum';

@Component({
  selector: 'app-admin-tabela-professor',
  templateUrl: './admin-tabela-professor.component.html',
  styleUrls: ['./admin-tabela-professor.component.css']
})
export class AdminTabelaProfessorComponent implements OnInit, AfterViewInit  {


  displayedColumns: string[] = ['nome', 'comentarios', 'topicos', 'aulas', 'acao'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  usuarios$: Observable<Usuario[]> = new Observable<Usuario[]>();

  constructor(
    public router: Router,
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.usuarios$ = this.store.select(getUsuarioProfessor);
  }

  public ngOnInit() {
    this.usuarios$.subscribe(professores => {
      this.dataSource = new MatTableDataSource(professores)
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  aplicarFiltro(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  criarUsuario() {
    this.dialog.open(AutocadastroComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: true
    });
  }

  acessarProfessor(item: any) {

  }

  editarProfessor(usuario: Usuario) {
    this.dialog.open(UsuarioEdicaoModalComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: usuario
    });
  }

  excluirProfessor(usuario: Usuario) {
    this.dialog.open(ModalExcluirComponent, {
      data: `Excluir professor: ${usuario.nome}`
    }).afterClosed().subscribe((evento) => {
      if(evento) {
        this.store.dispatch(excluirUsuario( {usuarioId: usuario.id!} ));
      }
    });
  }
}
