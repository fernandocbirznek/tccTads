import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AulasFavoritadasComponent } from './aulas-favoritadas.component';

describe('AulasFavoritadasComponent', () => {
  let component: AulasFavoritadasComponent;
  let fixture: ComponentFixture<AulasFavoritadasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AulasFavoritadasComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AulasFavoritadasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
