export class InformacaoSistema {
    constructor(
        public usuariosProfessor?: number,
        public instituicoes?: number,
        public topicos?: number,
        public usuariosComum?: number,
        public comentarios?: number,
        public aulas?: number,
        public noticias?: number,
    ) { }
}