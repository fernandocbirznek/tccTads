export class AutocadastroModel {
  constructor(
    public id?: number,
    public nome?: string,
    public email?: string,
    public cpf?: string,
    public login?: string,
    public senha?: string,
    public sobreMim?: string,
    public tipoUsuario?: number,
    public instituicaoId?: number,
    public nascimento?: Date,
    public token?: string
  ) { }
}
