import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { AutocadastroModel } from '../models/autocadastro.model';
import { InfoUsuario } from '../models/info-usuario.model';
import { InformacoesPerfil } from '../models/informacoes-perfil.model';
import { UsuarioLoginModel } from '../models/usuario-login.model';
import { Usuario } from '../models/usuario.model';
import { AbstractHttpService } from './abstract-http.service';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService extends AbstractHttpService {

  constructor(@Inject('BASE_URL') baseUrl: string, httpClient: HttpClient) {
    super(baseUrl, httpClient, 'api/usuario');
  }

  public inserir(usuario: Usuario): Observable<Usuario> {
    return this.post<Usuario>('inserir', usuario);
  }

  public getUsuarios(): Observable<Usuario[]> {
    return this.get<Usuario[]>('buscar-usuarios');
  }

  public excluir(id: number): Observable<any> {
    return this.delete<any>(`excluir/${id}`);
  }

  public autoCadastro(usuario: AutocadastroModel) {
    return this.post<Usuario>('autocadastro', usuario);
  }

  public selecionarAdministradores(): Observable<Usuario[]> {
    return this.get<Usuario[]>('selecionar-administradores');
  }

  public selecionarProfessores(): Observable<Usuario[]> {
    return this.get<Usuario[]>('selecionar-professores');
  }

  public selecionarUsuariosComuns(): Observable<Usuario[]> {
    return this.get<Usuario[]>('selecionar-usuarios-comuns');
  }

  public selecionarInformacoesPerfil(loginUsuario: string): Observable<InformacoesPerfil> {
    return this.get<InformacoesPerfil>(`selecionar-informacoes-perfil/${loginUsuario}`);
  }

  public atualizarUsuario(usuario: Usuario): Observable<Usuario> {
    return this.put<Usuario>('atualizar', {usuario: usuario})
  }

  public atualizarTipoUsuario(usuario: AutocadastroModel): Observable<Usuario> {
    return this.put<Usuario>('atualizarUsuario', { id: usuario.id, tipoUsuario: usuario.tipoUsuario, instituicaoId: usuario.instituicaoId })
  }

  public getInfosUsuario(usuarioId: number): Observable<InfoUsuario> {
    return this.get<InfoUsuario>(`info/${usuarioId}`);
  }

  public getComuns(): Observable<Usuario[]> {
    return this.get<Usuario[]>('comuns')
  }


  //Autenticacao
  TOKEN: string = 'TOKEN';

  public login(login: string, senha: string): Observable<UsuarioLoginModel> {
    return this.post<UsuarioLoginModel>('login', { Login: login, Senha: senha });
  }

  async autenticar(token: string, usuarioId: number): Promise<void> {
    localStorage.setItem(this.TOKEN, token.replaceAll("\"", ""));
    localStorage.setItem("uid", usuarioId.toString());
  }

  public logout(): null {
    this.limparDados();
    return null;
  }

  public isAutenticado(): boolean {
    const token = localStorage.getItem(this.TOKEN);
    return (token != null && token != undefined && token != '');
  }

  public validarUsuario() {
    if (!this.isAutenticado())
      window.location.replace('http://localhost:49828/#/website/');
  }

  public limparDados() {
    localStorage.removeItem(this.TOKEN);
    localStorage.removeItem("uid");
    localStorage.removeItem("nomeUsuario");
    localStorage.removeItem("tipoUsuario");
    localStorage.removeItem("loginUsuario");
  }

  public getUsuarioId(): string {
    return localStorage["uid"];
  }
}
