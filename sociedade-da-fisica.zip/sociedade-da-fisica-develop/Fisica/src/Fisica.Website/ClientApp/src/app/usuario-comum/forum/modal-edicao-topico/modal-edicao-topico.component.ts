import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TopicoForum } from '../../../shared/models/topico-forum.model';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToastComponent } from 'src/app/components-genericos';
import { atualizarTopicoForum } from 'src/app/store';
import { NotificacoesService } from '../../../shared/services/notificacoes.service';

@Component({
  selector: 'app-modal-edicao-topico',
  templateUrl: './modal-edicao-topico.component.html',
  styleUrls: ['./modal-edicao-topico.component.css']
})
export class ModalEdicaoTopicoComponent implements OnInit {

  @ViewChild("editor", { static: false }) editor: any;

  formTopicoAlterar: FormGroup = null as any;
  titulo = new FormControl('', [Validators.required]);
  descricao = new FormControl('', [Validators.required]);

  constructor(
    public dialogRef: MatDialogRef<ModalEdicaoTopicoComponent>,
    private notificacoesService: NotificacoesService,
    public store: Store,
    @Inject(MAT_DIALOG_DATA) public topicoForum: TopicoForum
  ) { }

  public ngOnInit(): void {
    this.criarFormularioTopico(new TopicoForum());
    this.setFormAlterar();
  }

  criarFormularioTopico(topicoForum: TopicoForum) {
    this.formTopicoAlterar = new FormGroup({
      topico_titulo: new FormControl(topicoForum.titulo),
      topico_descricao: new FormControl(topicoForum.descricao)
    })
  }
  
  setFormAlterar() {
    this.formTopicoAlterar.setValue({
      topico_titulo: this.topicoForum.titulo, 
      topico_descricao: this.topicoForum.descricao
    })
  }

  public salvar() {
    if (this.verificarCampo(this.formTopicoAlterar.get("topico_titulo")?.value) || this.verificarCampo(this.editor._data)) {
      this.notificacoesService.mostrarAviso('Os dois campos precisam ser preechidos.');
    }
    else {
      this.atualizarTopico();
      this.notificacoesService.mostrarSucesso('Tópico inserido com sucesso!');
      this.fechar();
    }
  }

  private atualizarTopico() {
    let topicoAtualizado: TopicoForum = new TopicoForum();
    topicoAtualizado = {
      ...this.topicoForum,
      titulo: this.formTopicoAlterar.get("topico_titulo")?.value,
      descricao: this.editor._data
    }
    this.store.dispatch(atualizarTopicoForum({ topicoForum: topicoAtualizado }));
  }

  verificarCampo(campo: any) {
    if(campo == "" || campo == undefined || campo == null)
      return true;
    return false;
  }

  public fechar(): void {
    this.dialogRef.close();
  }
}
