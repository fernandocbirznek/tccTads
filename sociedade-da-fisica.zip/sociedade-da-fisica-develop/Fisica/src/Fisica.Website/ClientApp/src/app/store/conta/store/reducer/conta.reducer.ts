import { Action, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/conta.actions';
import { Aula, Favorito, InformacoesPerfil, Segue, UsuarioStateHelper, WidgetAula } from 'src/app/shared';

export const contaFeatureKey = 'conta';

export interface ContaState {
  login: string;
  usuarioId: number;
  nome: string;
  tipoUsuario: number;
  token: string;
  perfilInformacoes: InformacoesPerfil,
  widgetAulas: WidgetAula[],
  aulasFavoritadas: Favorito[],
  segue: Segue[],
  isSuccess: boolean;
  isLoading: boolean;
  isFailure: boolean;
  mensagem: string;
}

export const contaInitialState: ContaState = {
  login: "",
  usuarioId: 0,
  nome: "",
  tipoUsuario: 0,
  token: "",
  perfilInformacoes: null as any,
  widgetAulas: [],
  aulasFavoritadas: [],
  segue: [],
  isSuccess: false,
  isLoading: false,
  isFailure: false,
  mensagem: "",
};

export const contaReducer = createReducer(
  contaInitialState,

  on(actions.autoCadastroConta, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.autoCadastroContaSuccess, (state, action) => {
    localStorage.setItem("nomeUsuario", action.response.nome);
    localStorage.setItem("tipoUsuario", action.response.tipoUsuario.toString());
    localStorage.setItem("loginUsuario", action.response.login);
    return { ...state, isLoading: false, isSuccess: true, isFailure: false, mensagem: "Conta criada com sucesso    lol", token: action.response.token!, usuarioId: action.response.usuarioId };
  }),
  on(actions.autoCadastroContaFailure, (state, action) => {
    let mensagem;
    if (action.error.error.lenth > 50)
      mensagem = "Falha em criar conta";
    else
      mensagem = action.error.error;

    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: mensagem };
  }),

  on(actions.loginConta, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.loginContaSuccess, (state, action) => {
    localStorage.setItem("nomeUsuario", action.response.nome);
    localStorage.setItem("tipoUsuario", action.response.tipoUsuario.toString());
    localStorage.setItem("loginUsuario", action.login.email_usuario);
    return { 
      ...state, 
      login: action.login.email_usuario,
      usuarioId: action.response.usuarioId, 
      nome: action.response.nome, 
      tipoUsuario: action.response.tipoUsuario,
      token: action.response.token,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.loginContaFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: action.response.mensagem };
  }),

//   on(actions.deletarConta, state => {
//     return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
//   }),
//   on(actions.deletarContaSuccess, (state, action) => {
//     return { 
//       ...state, 
//       login_usuario: "", 
//       nome_usuario: "", 
//       isLoading: false, 
//       isSuccess: true, 
//       isFailure: false, 
//       mensagem: action.response.mensagem,
//       token: ""
//     };
//   }),
//   on(actions.deletarContaFailure, (state, action) => {
//     return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: action.response.mensagem };
//   }),
  on(actions.deslogarConta, state => {
    return { 
      ...state,
      isLoading: true, 
      isSuccess: false, 
      isFailure: false, 
    };
  }),
  on(actions.deslogarContaSuccess, state => {
    return { 
      login: "",
      usuarioId: 0,
      tipoUsuario: 0,
      nome: "", 
      perfilInformacoes: null as any,
      widgetAulas: [],
      aulasFavoritadas: [],
      segue: [],
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
      mensagem: "Conta deslogada com sucesso",
      token: ""
    };
  }),
  on(actions.deslogarContaFailure, state => {
    return { 
      ...state, 
      isLoading: false, 
      isSuccess: false, 
      isFailure: true, 
      mensagem: "Falha ao deslogar conta",
    };
  }),

  on(actions.loadUsuarioState, state => {
    let usuario: any = UsuarioStateHelper.usuario();
    return { 
      ...state, 
      login: usuario.loginUsuario,
      usuarioId: usuario.usuarioId, 
      nome: usuario.nomeUsuario,
      tipoUsuario: usuario.tipoUsuario,
      token: usuario.token,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),

  on(actions.selecionarInformacoesPerfil, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "Buscando informa��es" };
  }),
  on(actions.selecionarInformacoesPerfilSuccess, (state, action) => {
    return { 
      ...state, 
      perfilInformacoes: action.response,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
      mensagem: "Busca bem sucedida    lol"
    };
  }),
  on(actions.selecionarInformacoesPerfilFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Falha ao buscar informa��es usu�rio" };
  }),

  on(actions.selecionarWidgetAulas, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarWidgetAulasSuccess, (state, action) => {
    return { 
      ...state,
      widgetAulas: action.response,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
      mensagem: ""
    };
  }),
  on(actions.selecionarWidgetAulasFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Falha ao buscar aulas do widgets" };
  }),

  on(actions.inserirAulaWidget, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.inserirAulaWidgetSuccess, (state, action) => {
    let itens: WidgetAula[] = [...state.widgetAulas].map((item, index) => {
      if(item.descricao == action.widget) {
        let aulas: Aula[] = [...state.widgetAulas[index].aulas!, action.aula]
        let widgetNovo: WidgetAula = {
          ...state.widgetAulas[index],
          aulas: aulas
        }
        return widgetNovo;
      }
      return item;
    })

    return { 
      ...state, 
      widgetAulas: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
      mensagem: "Aula cadastrado no widget com sucesso"
    };
  }),
  on(actions.inserirAulaWidgetFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Falha ao inserir aula no widget" };
  }),

  on(actions.excluirAulaWidget, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.excluirAulaWidgetSuccess, (state, action) => {
    let itens: WidgetAula[] = [...state.widgetAulas].map((item, index) => {
      if(item.descricao == action.widget) {
        let aulas: Aula[] = [...state.widgetAulas[index].aulas!].filter(item => item.id != action.aulaId)
        let widgetNovo: WidgetAula = {
          ...state.widgetAulas[index],
          aulas: aulas
        }
        return widgetNovo;
      }
      return item;
    })

    return { 
      ...state, 
      widgetAulas: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
      mensagem: "Aula excluida do widget com sucesso"
    };
  }),
  on(actions.excluirAulaWidgetFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Falha ao excluir aula do widget" };
  }),

  on(actions.selecionarAulasFavoritadas, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarAulasFavoritadasSuccess, (state, action) => {
    return { 
      ...state,
      aulasFavoritadas: action.response,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
      mensagem: ""
    };
  }),
  on(actions.selecionarAulasFavoritadasFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Falha ao buscar aulas do widgets" };
  }),

  on(actions.excluirFavoritado, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.excluirFavoritadoSuccess, (state, action) => {
    let itens: Favorito[] = [...state.aulasFavoritadas].filter(item => item.id != action.favoritoId);
    return { 
      ...state, 
      aulasFavoritadas: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.excluirFavoritadoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao excluir favorito"};
  }),

  on(actions.selecionarProfessorSegue, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarProfessorSegueSuccess, (state, action) => {
    return { 
      ...state,
      segue: action.response,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
      mensagem: ""
    };
  }),
  on(actions.selecionarProfessorSegueFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Falha ao buscar os professores que segue" };
  }),
);
