import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { TopicoForum } from '../../../shared/models/topico-forum.model';
import { TopicoForumService } from '../../../shared/services/topico-forum.service';
import { ModalCadastroTopicoComponent } from '../modal-cadastro-topico/modal-cadastro-topico.component';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { TemaForumState, getTopicosTemaForum, selecionarTemaForum, selecionarTopicoForum, selectTemaForumState } from 'src/app/store';

@Component({
  selector: 'app-tema-forum',
  templateUrl: './tema-forum.component.html',
  styleUrls: ['./tema-forum.component.css']
})
export class TemaForumComponent implements OnInit {

  /**
   *	Deve carregar os tópicos criados nesse tema de fórum.         -> buscarTopicosForum();       OK
   *  Deve ser possível acessar um tópico.                          -> acessarTopico();            OK
   *  Deve ser possível criar um tópico.                            -> inserirTopico();            OK
   *  Não deve cadastrar tópico com dados inconsistentes.                                          OK
   *  Deve ser possível excluir um tópico cadastrado pelo usuário.  -> excluirTipico();            OK
   *  Deve ser possível acessar o menu.                                                            OK
   *  Deve ser possível filtrar a lista por palavras.//fazer o filtro pelo proprio angular         OK   
   * */

   //TODO, ver se altera para nao pegar classe do state "TemaForumState", mas sim TopicoForum[], usando o outro seletor
   topicoForum$: Observable<TemaForumState> = new Observable<TemaForumState>();
   topicoForum: TopicoForum[] = [];

  forumId: number = 0;
  forumTitulo: string = "";
  searchText: string = "";

  novoTopico: TopicoForum = new TopicoForum();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private dialog: MatDialog,
    public store: Store,
  ) {
    this.store.dispatch(selecionarTemaForum({forumId: parseInt(this.route.snapshot.paramMap.get('forumId')!)}));
    this.topicoForum$ = this.store.select(selectTemaForumState);
  }

  ngOnInit() {
    if (!this.route.snapshot.paramMap.get('forumId')) {
      //redirecionar pois nao veio forum
    }
    this.forumId = parseInt(this.route.snapshot.paramMap.get('forumId')!);

    this.topicoForum$.subscribe(item => {
      this.topicoForum = item.topicosForum;
      this.forumTitulo = item.tituloForum;
    })

  }

  public acessarTopico(topicoForumId: number) {
    this.router.navigate(['/forum/topico', topicoForumId]);
  }

  public abrirModalCadastro(): void {
    this.dialog.open(ModalCadastroTopicoComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: {forumTitulo: this.forumTitulo, forumId: this.forumId}
    });
  }
}
