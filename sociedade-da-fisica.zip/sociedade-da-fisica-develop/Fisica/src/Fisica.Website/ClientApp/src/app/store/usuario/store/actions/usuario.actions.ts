import { createAction, props } from '@ngrx/store';
import { AutocadastroModel, Usuario } from 'src/app/shared';

export const selecionarUsuarioComum = createAction(
  '[Usuario] selecionarUsuarioComum'
);

export const selecionarUsuarioComumSuccess = createAction(
  '[Usuario] selecionarUsuarioComum Success',
  props<{ response: Usuario[] }>()
);

export const selecionarUsuarioComumFailure = createAction(
  '[Usuario] selecionarUsuarioComum Failure',
  props<{ error: any }>()
);

export const selecionarUsuarioProfessor = createAction(
'[Usuario] selecionarUsuarioProfessor'
);

export const selecionarUsuarioProfessorSuccess = createAction(
'[Usuario] selecionarUsuarioProfessor Success',
props<{ response: Usuario[] }>()
);

export const selecionarUsuarioProfessorFailure = createAction(
'[Usuario] selecionarUsuarioProfessor Failure',
props<{ error: any }>()
);

export const selecionarUsuarioAdministrador = createAction(
  '[Usuario] selecionarUsuarioAdministrador'
  );
  
  export const selecionarUsuarioAdministradorSuccess = createAction(
  '[Usuario] selecionarUsuarioAdministrador Success',
  props<{ response: Usuario[] }>()
  );
  
  export const selecionarUsuarioAdministradorFailure = createAction(
  '[Usuario] selecionarUsuarioAdministrador Failure',
  props<{ error: any }>()
  );

export const atualizarUsuario = createAction(
  '[Usuario] atualizarUsuario',
  props<{ usuario: AutocadastroModel }>()
);

export const atualizarUsuarioSuccess = createAction(
  '[Usuario] atualizarUsuario Success',
  props<{ usuario: AutocadastroModel, response: Usuario }>()
);

export const atualizarUsuarioFailure = createAction(
  '[Usuario] atualizarUsuario Failure',
  props<{ error: any }>()
);

export const inserirUsuario = createAction(
  '[Usuario] inserirUsuario',
  props<{ usuario: Usuario }>()
);

export const inserirUsuarioSuccess = createAction(
  '[Usuario] inserirUsuario Success',
  props<{ usuario: Usuario, response: Usuario }>()
);

export const inserirUsuarioFailure = createAction(
  '[Usuario] inserirUsuario Failure',
  props<{ error: any }>()
);

export const excluirUsuario = createAction(
  '[Usuario] excluirUsuario',
  props<{ usuarioId: number }>()
);

export const excluirUsuarioSuccess = createAction(
  '[Usuario] excluirUsuario Success',
  props<{ usuarioId: number }>()
);

export const excluirUsuarioFailure = createAction(
  '[Usuario] excluirUsuario Failure',
  props<{ error: any }>()
);

export const atualizarTipoUsuario = createAction(
  '[Usuario] atualizarTipoUsuario',
  props<{ atualizarTipoUsuario: AutocadastroModel }>()
);

export const atualizarTipoUsuarioSuccess = createAction(
  '[Usuario] atualizarTipoUsuario Success',
  props<{ atualizarTipoUsuario: AutocadastroModel, response: Usuario }>()
);

export const atualizarTipoUsuarioFailure = createAction(
  '[Usuario] atualizarTipoUsuario Failure',
  props<{ error: any }>()
);