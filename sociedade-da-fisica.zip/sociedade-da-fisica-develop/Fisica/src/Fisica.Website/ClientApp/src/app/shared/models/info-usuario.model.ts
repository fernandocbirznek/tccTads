export class InfoUsuario {
  constructor(
    public tipoUsuario?: number,
    public instituicaoId?: number
  ) { }
}
