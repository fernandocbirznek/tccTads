import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlterarNoticiaComponent } from './alterar-noticia.component';

describe('AlterarNoticiaComponent', () => {
  let component: AlterarNoticiaComponent;
  let fixture: ComponentFixture<AlterarNoticiaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlterarNoticiaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AlterarNoticiaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
