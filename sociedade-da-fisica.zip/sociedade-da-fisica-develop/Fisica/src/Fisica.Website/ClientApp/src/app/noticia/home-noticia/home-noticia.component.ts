import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Noticia } from 'src/app/shared';
import { getNoticias, selecionarNoticias } from 'src/app/store';
import { VisualizarNoticiaComponent } from '../visualizar-noticia';

@Component({
  selector: 'app-home-noticia',
  templateUrl: './home-noticia.component.html',
  styleUrls: ['./home-noticia.component.css']
})
export class HomeNoticiaComponent implements OnInit {

   noticias$: Observable<Noticia[]> = new Observable<Noticia[]>();
   noticias: Noticia[] = [];


  constructor(
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.store.dispatch(selecionarNoticias());
    this.noticias$ = this.store.select(getNoticias);
  }

  ngOnInit(): void {
    this.noticias$.subscribe(noticias => {
      this.noticias = [...noticias].map(item => {
        if(item.tags != "") {
          let noticia = {...item, tagsTela: JSON.parse(item.tags)}
          return noticia;
        }
        return item;
      })
    });
  }

  visualizarNoticia(noticiaId: number | undefined) {
    this.dialog.open(VisualizarNoticiaComponent, {
      minHeight: '550px',
      height: 'auto',
      width: '70%',
      data: noticiaId
    });
  }

}
