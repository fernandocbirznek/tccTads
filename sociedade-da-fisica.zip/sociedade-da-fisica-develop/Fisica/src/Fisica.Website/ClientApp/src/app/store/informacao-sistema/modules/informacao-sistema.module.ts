import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import * as fromInformacaoSistema from '../store/reducers/informacao-sistema.reducers';
import { EffectsModule } from '@ngrx/effects';
import { InformacaoSistemaEffects } from '../store/effects/informacao-sistema.effects';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoreModule.forFeature(fromInformacaoSistema.informacaoSistemaFeatureKey, fromInformacaoSistema.informacaoSistemaReducer),
    EffectsModule.forFeature([InformacaoSistemaEffects])
  ]
})
export class InformacaoSistemaModule { }
