import { Perfil } from "./perfil.model";

export class InformacoesPerfil {
  constructor(
    public nome?: string,
    public email?: string,
    public tipoUsuario?: string,
    public instituicao?: string,
    public perfil?: Perfil,
    public quantidadeParaCursar?: number,
    public quantidadeCursando?: number,
    public quantidadeConcluidas?: number,
    public quantidadeFavoritos?: number,
    public quantidadeSeguindo?: number,
    public quantidadeSeguidores?: number,
    public aulasPostadas?: number,
    public aulasAcessadas?: number,
    public quantidadeNoticias?: number,
    public quantidadeTopicos?: number,
    public quantidadeRespostas?: number,
    public quantidadeInteracoes?: number
  ) { }
}
