export * from './noticia.module';
export * from './noticia.routing';