import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ToastComponent } from '../../components-genericos';
import { AreaFisica } from '../../shared/models/area-fisica.model';
import { Aula } from '../../shared/models/aula.model';
import { SessaoAula } from '../../shared/models/sessao-aula.model';
import { NotificacoesService } from '../../shared/services/notificacoes.service';
import { getAreasFisica, selecionarAreasFisica, selecionarConta } from '../../store';
import { inserirAula } from '../../store/aula/store/actions/aula.actions';
import { getAulas } from '../../store/aula/store/selectors/aula.selectors';
import { CadastroSessaoComponent } from '../cadastro-sessao';
import { EditarSessaoComponent } from '../editar-sessao/editar-sessao.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cadastro-aula',
  templateUrl: './cadastro-aula.component.html',
  styleUrls: ['./cadastro-aula.component.scss']
})
export class CadastroAulaComponent implements OnInit, AfterViewInit {

  @ViewChild("editor", { static: false }) editor: any;

  aula: Aula;
  formAula: FormGroup = null as any;

  titulo = new FormControl('', [Validators.required, Validators.minLength(200)]);
  descricao = new FormControl('', [Validators.required, Validators.minLength(200)]);

  stateUsuario$: Observable<any> = new Observable<any>();
  nomeUsuario: string = "";

  areas$: Observable<AreaFisica[]> = new Observable<AreaFisica[]>();
  aula$: Observable<Aula> = new Observable<Aula>();
  areas: AreaFisica[] = [];

  constructor(
    public store: Store,
    public dialog: MatDialog,
    private notificacoesService: NotificacoesService,
    private router: Router,
  ) {
    this.aula = new Aula();
    this.aula.sessoes = [];
  }

  public async ngOnInit(): Promise<void> {
    this.criarFormularioAula(this.aula);
    this.store.dispatch(selecionarAreasFisica());
    this.areas$ = this.store.select(getAreasFisica);
    this.aula$ = this.store.select(getAulas);
    this.areas$.subscribe(item => this.areas = item);

    this.stateUsuario$ = this.store.select(selecionarConta);
    this.stateUsuario$.subscribe(item => {
      this.nomeUsuario = item.nome;
    });
  }

  public ngAfterViewInit(): void {
    if(this.editor)
      this.editor.readOnly = true;
  }

  private criarFormularioAula(aula: Aula) {
    this.formAula = new FormGroup({
      titulo_aula: new FormControl(aula.titulo),
      descricao_aula: new FormControl(aula.descricao),
      areafisica_aula: new FormControl(aula.areaFisicaId)
    });
  }

  public abrirModalNovaSessao(): void {
    this.dialog.open(CadastroSessaoComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '920px',
      data: this.aula
    });
  }

  public drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.aula.sessoes!, event.previousIndex, event.currentIndex);
    this.reordenarSessoes();
  }

  public reordenarSessoes(): void {
    let ordem = 1;
    this.aula.sessoes!.forEach((sessao) => {
      sessao.ordem = ordem;
      ordem++;
    });
  }

  public salvar(): void {
    if (this.formAula.valid) {
      this.aula.titulo = this.formAula.get("titulo_aula")?.value;
      this.aula.descricao = this.formAula.get("descricao_aula")?.value;
      this.aula.areaFisicaId = this.formAula.get("areafisica_aula")?.value;
      this.aula.professorId = localStorage["uid"];
      this.store.dispatch(inserirAula({ aula: this.aula }));
      this.formAula.reset();
      this.notificacoesService.mostrarSucesso('Aula salva com sucesso!');
    }
    this.router.navigate([`professor-perfil/${this.nomeUsuario}`]);
  }

  public removerSessao(sessao: SessaoAula): void {
    let indice = this.aula.sessoes?.indexOf(sessao)!; 
    this.aula.sessoes?.splice(indice, 1);
    this.reordenarSessoes();
  }

  public editarSessao(sessao: SessaoAula): void {
    this.dialog.open(EditarSessaoComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '920px',
      data: sessao
    });
  }

  voltar() {
    this.router.navigate([`professor-perfil/${this.nomeUsuario}`]);  
  }
}
