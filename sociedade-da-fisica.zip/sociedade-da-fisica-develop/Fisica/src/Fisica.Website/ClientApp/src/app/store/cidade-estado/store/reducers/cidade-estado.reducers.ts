import { Action, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/cidade-estado.actions';
import { Cidade, Estado } from 'src/app/shared';

export const cidadeEstadoFeatureKey = 'cidade-estado';

export interface CidadeEstadoState {
    cidades: Cidade[];
    estados: Estado[];
    isSuccess: boolean;
    isLoading: boolean;
    isFailure: boolean;
    mensagem: string;
}

export const cidadeEstadoInitialState: CidadeEstadoState = {
    cidades: [],
    estados: [],
    isSuccess: false,
    isLoading: false,
    isFailure: false,
    mensagem: "",
};

export const cidadeEstadoReducer = createReducer(
    cidadeEstadoInitialState,

  on(actions.selecionarCidades, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarCidadesSuccess, (state, action) => {
    let itens: Cidade[] = action.response;

    return { 
      ...state, 
      cidades: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.selecionarCidadesFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar as cidades"};
  }),
);
