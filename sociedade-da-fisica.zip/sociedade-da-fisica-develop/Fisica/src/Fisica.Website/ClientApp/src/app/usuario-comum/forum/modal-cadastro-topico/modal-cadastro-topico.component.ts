import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { TopicoForum } from '../../../shared/models/topico-forum.model';
import { NotificacoesService } from '../../../shared/services/notificacoes.service';
import { TopicoForumService } from '../../../shared/services/topico-forum.service';
import { Store } from '@ngrx/store';
import { inserirTopicoForum, selecionarUsuario } from 'src/app/store';
import { Observable } from 'rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToastComponent } from 'src/app/components-genericos';

@Component({
  selector: 'app-modal-cadastro-topico',
  templateUrl: './modal-cadastro-topico.component.html',
  styleUrls: ['./modal-cadastro-topico.component.css']
})
export class ModalCadastroTopicoComponent implements OnInit {
  
  @ViewChild("editor", { static: false }) editor: any;

  formTopico: FormGroup = null as any;
  titulo = new FormControl('', [Validators.required]);
  descricao = new FormControl('', [Validators.required]);

  tituloForum: string = "";

  usuarioLogado$: Observable<string> = new Observable<string>();
  usuarioLogado: string = "";

  constructor(
    public dialogRef: MatDialogRef<ModalCadastroTopicoComponent>,
    public store: Store,
    private notificacoesService: NotificacoesService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.usuarioLogado$ = this.store.select(selecionarUsuario);
   }

  public ngOnInit(): void {
    this.tituloForum = this.data.forumTitulo;
    this.usuarioLogado$.subscribe(item => this.usuarioLogado = item);
    this.criarFormularioTopico(new TopicoForum());
  }

  criarFormularioTopico(topicoForum: TopicoForum) {
    this.formTopico = new FormGroup({
      topico_titulo: new FormControl(topicoForum.titulo),
      topico_descricao: new FormControl(topicoForum.descricao)
    })
  }

  public fechar(): void {
    this.dialogRef.close();
  }

  public salvar() {
    if (this.verificarCampo(this.formTopico.get("topico_titulo")?.value) || this.verificarCampo(this.editor._data)) {
      this.notificacoesService.mostrarAviso('Os dois campos precisam ser preechidos.');
    }
    else {
      this.inserirTopico();
      this.notificacoesService.mostrarSucesso('Tópico inserido com sucesso!');
      this.fechar();
    }
  }

  private inserirTopico() {
    let topico: TopicoForum = new TopicoForum();
    topico.titulo = this.formTopico.get("topico_titulo")?.value;
    topico.descricao = this.editor._data;
    topico.forumId = this.data.forumId;
    topico.usuarioCadastro = this.usuarioLogado;
    this.store.dispatch(inserirTopicoForum({ topicoForum: topico }));
  }

  verificarCampo(campo: any) {
    if(campo == "" || campo == undefined || campo == null)
      return true;
    return false;
  }
}
