import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { autoCadastroConta, ContaState, inserirUsuario, selecionarConta } from 'src/app/store';
import { AutocadastroModel } from '../../../shared/models/autocadastro.model';
import { NotificacoesService } from '../../../shared/services/notificacoes.service';
import { UsuarioService } from '../../../shared/services/usuario.service';

@Component({
  selector: 'app-autocadastro',
  templateUrl: './autocadastro.component.html',
  styleUrls: ['./autocadastro.component.css']
})
export class AutocadastroComponent implements OnInit {

  //HU – Criar/logar conta
  // 1)	Não deve logar com campos inconsistentes.                                   OUTRA TELA
  // 2)	Deve ser possível clicar em cadastrar após ter campos consistentes.         OUTRA TELA
  // 3)	Deve ser possível criar conta.                                                 OK                                        
  // 4)	Não deve criar conta com campos inconsistentes.                                OK         
  // 5)	Deve ser possível cancelar.                                                    OK
  // 6)	Deve ser possível fechar a modal.                                              OK

  formCadastrar: FormGroup = null as any;

  nome = new FormControl('', [Validators.required]);
  email = new FormControl('', [Validators.required, Validators.email]);
  cpf = new FormControl('',
    [
      Validators.required, Validators.pattern(/^(\d{3}\.){2}\d{3}\-\d{2}$/),
      Validators.minLength(14), Validators.maxLength(14)
    ]
  );
  login = new FormControl('', [Validators.required]);
  senha = new FormControl('', [Validators.required, Validators.minLength(8)]);
  confirmarSenha = new FormControl('', [Validators.required, Validators.minLength(8)]);
  sobreMim = new FormControl('');
  TipoUsuario = new FormControl('', [Validators.required]);
  nascimento = new FormControl('', [Validators.required])
  hide = true;

  loginValue = "";
  senhaValue = "";

  conta$: Observable<ContaState>;

  constructor(
    public dialogRef: MatDialogRef<AutocadastroComponent>,
    public store: Store,
    private snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public adminCadastro: Boolean,
    private notificacoesService: NotificacoesService,
    private usuarioService: UsuarioService,
    private router: Router
  ) {
    this.conta$ = this.store.select(selecionarConta);
  }

  public ngOnInit(): void {
    this.criarFormularioCadastrar(new AutocadastroModel());
  }

  criarFormularioCadastrar(autocadastro: AutocadastroModel) {
    this.formCadastrar = new FormGroup({
      cadastrar_nome: new FormControl(autocadastro.nome),
      cadastrar_email: new FormControl(autocadastro.email),
      cadastrar_cpf: new FormControl(autocadastro.cpf),
      cadastrar_login: new FormControl(autocadastro.login),
      cadastrar_senha: new FormControl(autocadastro.senha),
      cadastrar_confirmarSenha: new FormControl(),
      cadastrar_sobreMim: new FormControl(autocadastro.sobreMim),
      cadastrar_tipoUsuario: new FormControl(autocadastro.tipoUsuario),
      cadastrar_nascimento: new FormControl(autocadastro.nascimento)
    })
  }

  inserir() {
    if (this.validarCampos()) {
      let autoCadastro: AutocadastroModel = new AutocadastroModel();
      autoCadastro.nome = this.formCadastrar.get("cadastrar_nome")?.value;
      autoCadastro.email = this.formCadastrar.get("cadastrar_email")?.value;
      autoCadastro.cpf = this.formCadastrar.get("cadastrar_cpf")?.value;
      autoCadastro.login = this.formCadastrar.get("cadastrar_login")?.value;
      this.loginValue = autoCadastro.login!;
      autoCadastro.senha = this.formCadastrar.get("cadastrar_senha")?.value;
      this.senhaValue = autoCadastro.senha!;
      autoCadastro.sobreMim = this.formCadastrar.get("cadastrar_sobreMim")?.value;
      autoCadastro.tipoUsuario = this.formCadastrar.get("cadastrar_tipoUsuario")?.value;
      autoCadastro.nascimento = this.formCadastrar.get("cadastrar_nascimento")?.value;
      if (this.adminCadastro)
        this.store.dispatch(inserirUsuario({ usuario: autoCadastro }));
      else
        this.store.dispatch(autoCadastroConta({ autocadastro: autoCadastro }));

      this.conta$.subscribe(item => {
        if (!item.isLoading) {

          if (item.isFailure) {
            this.notificacaoValidacao(item.mensagem);
          }

          if (item.isSuccess && !this.adminCadastro && item.token != "") {
            this.usuarioService.autenticar(item!.token, item.usuarioId);
            this.notificacoesService.mostrarSucesso('Logado com sucesso!');
            this.formCadastrar.reset();
            this.fecharModal();
            location.reload();
          }
        }
      })
    }
  }

  fecharModal() {
    this.dialogRef.close();
  }

  validarCampos() {
    let retorno: boolean = true;
    if (this.formCadastrar.get("cadastrar_confirmarSenha")?.value != this.formCadastrar.get("cadastrar_senha")?.value) {
      this.notificacaoValidacao("As senhas nao coincidem");
      this.formCadastrar.get("cadastrar_senha")?.markAsTouched();
      this.formCadastrar.get("cadastrar_confirmarSenha")?.markAsTouched();
      retorno = false;
    }
    if (this.verificarCampo(this.formCadastrar.get("cadastrar_confirmarSenha")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Confirmar senha");
      this.formCadastrar.get("cadastrar_confirmarSenha")?.markAsTouched();
      retorno = false;
    }
    if (this.verificarCampo(this.formCadastrar.get("cadastrar_senha")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Senha");
      this.formCadastrar.get("cadastrar_senha")?.markAsTouched();
      retorno = false;
    }
    if (this.verificarCampo(this.formCadastrar.get("cadastrar_login")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Login");
      this.formCadastrar.get("cadastrar_login")?.markAsTouched();
      retorno = false;
    }
    if (this.verificarCampo(this.formCadastrar.get("cadastrar_cpf")?.value)) {
      this.notificacaoValidacao("Deve preencher corretamente campo cpf");
      this.formCadastrar.get("cadastrar_cpf")?.markAsTouched();
      retorno = false;
    }
    if (this.verificarCampo(this.formCadastrar.get("cadastrar_email")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Email");
      this.formCadastrar.get("cadastrar_email")?.markAsTouched();
      retorno = false;
    }
    if (this.verificarCampo(this.formCadastrar.get("cadastrar_nome")?.value)) {
      this.notificacaoValidacao("Deve preencher campo Nome");
      this.formCadastrar.get("cadastrar_nome")?.markAsTouched();
      retorno = false;
    }
    if (this.verificarCampo(this.formCadastrar.get("cadastrar_tipoUsuario")?.value) && this.adminCadastro) {
      this.notificacaoValidacao("Deve preencher campo Tipo Usuário");
      this.formCadastrar.get("cadastrar_tipoUsuario")?.markAsTouched();
      retorno = false;
    }
    return retorno;
  }

  verificarCampo(campo: any) {
    if (campo == "" || campo == undefined || campo == null)
      return true;
    return false;
  }

  notificacaoValidacao(item: string) {
    this.notificacoesService.mostrarAviso(item);
  }

}
