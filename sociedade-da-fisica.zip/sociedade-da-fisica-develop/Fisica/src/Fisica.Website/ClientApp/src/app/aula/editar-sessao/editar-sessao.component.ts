import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SessaoAula } from '../../shared';

@Component({
  selector: 'app-editar-sessao',
  templateUrl: './editar-sessao.component.html',
  styleUrls: ['./editar-sessao.component.css']
})
export class EditarSessaoComponent implements OnInit {

  @ViewChild("editor", { static: false }) editor: any;
    
  rows = 10;
  exemploEquacao: string = "y = 5 + \\sqrt{100} - \\sum (x+1) + \\int z \\Delta z";

  tipoSessao = new FormControl('', [Validators.required]);
  conteudo = new FormControl('', [Validators.required, Validators.maxLength(8000)]);
  titulo = new FormControl('', [Validators.required, Validators.maxLength(200)]);

  formSessao: FormGroup = null as any;


  constructor(
    public dialogRef: MatDialogRef<EditarSessaoComponent>,
    @Inject(MAT_DIALOG_DATA) public sessao: SessaoAula
  ) { }

  public ngOnInit(): void {
    this.criarFormularioSessao(new SessaoAula());
    this.formSessao.get("titulo_sessao")?.setValue(this.sessao.titulo);
    this.formSessao.get("conteudo_sessao")?.setValue(this.sessao.conteudo);
    this.formSessao.get("tipo_sessao")?.setValue(this.sessao.tipoSessao);
    this.formSessao.get("tipo_sessao")?.disable();
  }

  private criarFormularioSessao(sessao: SessaoAula) {
    this.formSessao = new FormGroup({
      titulo_sessao: new FormControl(sessao.titulo),
      conteudo_sessao: new FormControl(sessao.conteudo),
      tipo_sessao: new FormControl(sessao.tipoSessao)
    })
  }

  public salvar(): void {

    switch(this.formSessao.get("tipo_sessao")?.value) { 
      case "1":
      case "5":
        this.sessao.conteudo = this.editor._data;
        break; 
      case "2":
        this.sessao.conteudo = this.formSessao.get("conteudo_sessao")?.value;
        break;
    } 

    this.sessao.titulo = this.formSessao.get("titulo_sessao")?.value;
    this.sessao.tipoSessao = this.formSessao.get("tipo_sessao")?.value;
    this.fecharModal();
  }

  public fecharModal() {
    this.dialogRef.close();
  }

  public calcularRows() {
    switch (parseInt(this.formSessao.get("tipo_sessao")?.value)) {
      case 1:
        this.rows = 3;
        break;
      case 2:
        this.rows = 3;
        break;
      case 5:
        this.rows = 10;
        break;
      default:
        break;
    }
  }
}
