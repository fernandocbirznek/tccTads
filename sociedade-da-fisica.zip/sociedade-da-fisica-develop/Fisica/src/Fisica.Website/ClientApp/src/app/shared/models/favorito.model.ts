export class Favorito {
  constructor(
    public id?: number,
    public aulaId?: number,
    public aulaNome?: string,
    public sessaoAulaId?: number,
    public descricao?: string,
    public tipoSessao?: number
  ) { }
}
