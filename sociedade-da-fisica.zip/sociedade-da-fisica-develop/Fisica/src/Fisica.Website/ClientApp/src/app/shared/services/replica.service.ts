import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Replica } from '../models/replica.model';
import { AbstractHttpService } from './abstract-http.service';

@Injectable({
  providedIn: 'root'
})
export class ReplicaService extends AbstractHttpService {

  constructor(@Inject('BASE_URL') baseUrl: string, httpClient: HttpClient) {
    super(baseUrl, httpClient, 'api/replica');
  }

  public inserirReplica(replica: Replica): Observable<Replica> {
    return this.post<Replica>('inserir', replica);
  }

  public excluirReplica(replicaId: number): Observable<void> {
    return this.delete(`excluir/${replicaId}`);
  }

  public atualizarReplica(replica: Replica): Observable<Replica> {
    return this.put<Replica>('atualizar', { replicaId: replica.id, descricao: replica.descricao });
  }
}
