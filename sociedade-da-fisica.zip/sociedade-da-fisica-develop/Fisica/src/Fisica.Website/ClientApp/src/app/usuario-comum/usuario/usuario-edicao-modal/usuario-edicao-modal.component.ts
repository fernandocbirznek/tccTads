import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Store } from '@ngrx/store';
import { ToastComponent } from 'src/app/components-genericos';
import { AutocadastroModel, Instituicao, Usuario } from 'src/app/shared';
import { atualizarTipoUsuario } from 'src/app/store';
import { InfoUsuario } from '../../../shared/models/info-usuario.model';
import { InstituicaoService } from '../../../shared/services/instituicao.service';
import { UsuarioService } from '../../../shared/services/usuario.service';

@Component({
  selector: 'app-usuario-edicao-modal',
  templateUrl: './usuario-edicao-modal.component.html',
  styleUrls: ['./usuario-edicao-modal.component.css']
})
export class UsuarioEdicaoModalComponent implements OnInit {

  esconder: boolean;

  formUsuarioEdicao: FormGroup = null as any;

  TipoUsuario = new FormControl('', [Validators.required]);
  Instituicao = new FormControl('');

  instituicoes: Instituicao[] = [];

  infoUsuario: InfoUsuario;

  constructor(
    public dialogRef: MatDialogRef<UsuarioEdicaoModalComponent>,
    public store: Store,
    private snackBar: MatSnackBar,
    private instituicaoService: InstituicaoService,
    private usuarioService: UsuarioService,
    @Inject(MAT_DIALOG_DATA) public usuario: Usuario
  ) {
    this.criarFormularioEdicaoUsuario(new AutocadastroModel());
    this.infoUsuario = new InfoUsuario();
    this.esconder = true;
  }

  public async ngOnInit(): Promise<void> {
    await this.buscarInfosUsuario();
    await this.buscarInstituicoes();
    let usuario = new AutocadastroModel();
    usuario.tipoUsuario = this.infoUsuario.tipoUsuario;
    usuario.instituicaoId = this.infoUsuario.instituicaoId;
  }

  public async buscarInfosUsuario(): Promise<void> {
    this.infoUsuario = (await this.usuarioService.getInfosUsuario(this.usuario.id!).toPromise())!;
    this.formUsuarioEdicao.get("cadastrar_tipoUsuario")?.setValue(this.infoUsuario.tipoUsuario!.toString());
    this.formUsuarioEdicao.get("cadastrar_instituicao")?.setValue(this.infoUsuario.instituicaoId);
    this.changeTipoUsuario();
  }

  public criarFormularioEdicaoUsuario(usuario: AutocadastroModel) {
    this.formUsuarioEdicao = new FormGroup({
      cadastrar_tipoUsuario: new FormControl(usuario.tipoUsuario),
      cadastrar_instituicao: new FormControl(usuario.instituicaoId)
    })
  }

  public async buscarInstituicoes(): Promise<void> {
    this.instituicoes = (await this.instituicaoService.getInstituicoes(1).toPromise())!;
  }

  public fecharModal(): void {
    this.dialogRef.close();
  }

  public AtualizarUsuario() {
    if (!this.Valido()) {
      this.snackBar.openFromComponent(ToastComponent, {
        data: "Deve preencher todos os campos.",
        duration: 5 * 1000,
        panelClass: 'css-toast',
        horizontalPosition: 'right',
        verticalPosition: 'top',
      });
    }
    else {
      this.atualizarUsuario();
      this.snackBar.openFromComponent(ToastComponent, {
        data: "Usuário atualizado com sucesso!!!",
        duration: 5 * 1000,
        panelClass: 'css-toast',
        horizontalPosition: 'right',
        verticalPosition: 'top',
      });
      this.fecharModal();
    }
  }

  private Valido(): boolean {
    let tipo = this.formUsuarioEdicao.get("cadastrar_tipoUsuario")?.value;
    if (this.verificarCampo(tipo)) {
      if (tipo == 2 || tipo == 3) {
        return this.formUsuarioEdicao.get("cadastrar_instituicao")?.value != null;
      }
      return true;
    } else
      return false;
  }

  private atualizarUsuario() {
    let tipoUsuario: AutocadastroModel = new AutocadastroModel();
    tipoUsuario.tipoUsuario = this.formUsuarioEdicao.get("cadastrar_tipoUsuario")?.value;
    tipoUsuario.id = this.usuario.id;
    tipoUsuario.instituicaoId = this.formUsuarioEdicao.get("cadastrar_instituicao")?.value;
    this.store.dispatch(atualizarTipoUsuario({ atualizarTipoUsuario: tipoUsuario }));
  }

  verificarCampo(campo: any) {
    if (campo == "" || campo == undefined || campo == null)
      return false;
    return true;
  }

  public changeTipoUsuario() {
    let tipo = this.formUsuarioEdicao.get("cadastrar_tipoUsuario")?.value!;

    this.esconder = tipo == 1 || tipo == 4;
  }
}
