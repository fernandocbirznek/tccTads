import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import * as fromConta from '../store/reducer/conta.reducer';
import { EffectsModule } from '@ngrx/effects';
import { ContaEffects } from '../store/effects/conta.effects';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoreModule.forFeature(fromConta.contaFeatureKey, fromConta.contaReducer),
    EffectsModule.forFeature([ContaEffects])
  ]
})
export class ContaModule { }
