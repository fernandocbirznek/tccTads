import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Noticia } from '../shared/models/noticia.model';
import { getNoticias, selecionarNoticias } from '../store';
import { Tag } from '../shared';
import { MatDialog } from '@angular/material/dialog';
import { VisualizarNoticiaComponent } from '../noticia/visualizar-noticia';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  /**
    1)	Deve carregar as últimas notícias/aulas postadas no site.     OK
    2)	Deve ser possível acessar as aulas.                           OK
    3)	Deve ser possível acessar o fórum.                            OK
    4)	Deve ser possível criar conta.                                OK
    5)	Deve ser possível conhecer a equipe do sistema. 
    6)	Deve ser possível deslogar no sistema                VAI FICAR NO PERFIL
    Adicionado novo item
    7)  Deve ser possivel visualizar a notícia                        OK
   * */

    //PRECISA CRIAR AINDA OS COMPONENTES DAS HISTORIAS DE USUARIO:
    //Comentario em aula
    //Aula

   noticias$: Observable<Noticia[]> = new Observable<Noticia[]>();
   noticias: Noticia[] = [];


  constructor(
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.store.dispatch(selecionarNoticias());
    this.noticias$ = this.store.select(getNoticias);
  }

  ngOnInit(): void {
    this.noticias$.subscribe(noticias => {
      this.noticias = [...noticias].map(item => {
        if(item.tags != "") {
          let noticia = {...item, tagsTela: JSON.parse(item.tags)}
          return noticia;
        }
        return item;
      })
    });
  }

  visualizarNoticia(noticiaId: number | undefined) {
    this.dialog.open(VisualizarNoticiaComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
      data: noticiaId
    });
  }
}
