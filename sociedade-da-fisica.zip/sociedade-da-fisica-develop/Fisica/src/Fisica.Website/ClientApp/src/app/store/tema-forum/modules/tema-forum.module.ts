import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreModule } from '@ngrx/store';
import * as fromTemaForum from '../store/reducers/tema-forum.reducers';
import { EffectsModule } from '@ngrx/effects';
import { TemaForumEffects } from '../store/effects/tema-forum.effects';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    StoreModule.forFeature(fromTemaForum.temaForumFeatureKey, fromTemaForum.temaForumReducer),
    EffectsModule.forFeature([TemaForumEffects])
  ]
})
export class TemaForumModule { }
