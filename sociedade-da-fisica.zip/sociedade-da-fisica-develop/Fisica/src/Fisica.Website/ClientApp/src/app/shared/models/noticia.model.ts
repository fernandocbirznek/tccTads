import { Tag } from "./tag.model";
import { Usuario } from "./usuario.model";

export class Noticia {
  constructor(
    public id?: number,
    public autor?: Usuario,
    public titulo?: string,
    public resumo?: string,
    public conteudo?: string,
    public dataCadastro?: Date,
    public autorId?: number,
    public autorNome?: string,
    //public tags: Tag[] = []
    public tags: string = "",
    public vizualizacao: number = 0,

    public tagsTela: Tag[] = []
  ) { }
}
