import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Aula } from '../../shared';
import { AulaService } from '../../shared/services/aula.service';

@Component({
  selector: 'app-ondulatoria',
  templateUrl: './ondulatoria.component.html',
  styleUrls: ['./ondulatoria.component.css']
})
export class OndulatoriaComponent implements OnInit {
  aulas: Aula[];

  searchText: string = "";
  public contador: number = 1;

  divisaoSelecionada: number = 0;

  constructor(
    public dialog: MatDialog,
    public aulaService: AulaService
  ) {
    this.aulas = [];
  }

  public async ngOnInit(): Promise<void> {
    await this.buscarAulas();
  }

  public moverAulas(num: number): void {
    //TODO está hardcode a quantidade de itens
    if (this.contador + num >= 1 && this.contador + num <= 3)
      this.contador = this.contador + num;
  }

  public divisao(selecionado: number): void {
    this.divisaoSelecionada = selecionado;

  }

  public async buscarAulas(): Promise<void> {
    this.aulas = (await this.aulaService.selecionarAulasPorAreaFisica(3).toPromise())!
  }
}
