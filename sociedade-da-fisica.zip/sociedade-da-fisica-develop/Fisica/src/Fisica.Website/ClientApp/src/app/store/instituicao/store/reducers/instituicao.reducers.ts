import { Action, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/instituicao.actions';
import { Endereco, Instituicao } from 'src/app/shared';

export const instituicaoFeatureKey = 'instituicao';

export interface InstituicaoState {
    instituicoes: Instituicao[];
    instituicao: Instituicao;
    isSuccess: boolean;
    isLoading: boolean;
    isFailure: boolean;
    mensagem: string;
}

export const instituicaoInitialState: InstituicaoState = {
    instituicoes: [],
    instituicao: null as any,
    isSuccess: false,
    isLoading: false,
    isFailure: false,
    mensagem: "",
};

export const instituicaoReducer = createReducer(
    instituicaoInitialState,

  on(actions.selecionarInstituicao, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarInstituicaoSuccess, (state, action) => {
    let itens: Instituicao[] = action.response;

    return { 
      ...state, 
      instituicoes: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.selecionarInstituicaoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar as instituições"};
  }),

  on(actions.selecionarInstituicaoById, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarInstituicaoByIdSuccess, (state, action) => {
    let item: Instituicao = action.response;

    return { 
      ...state, 
      instituicao: item,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.selecionarInstituicaoByIdFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar a instituição"};
  }),

  on(actions.inserirInstituicao, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.inserirInstituicaoSuccess, (state, action) => {
    let instituicao: Instituicao = {
      ...action.instituicao,
      id: action.response.id,
      //dataCadastro: action.response.dataCadastro,
    }
    let itens: Instituicao[] = [...state.instituicoes, instituicao];
    return { 
      ...state, 
      instituicoes: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.inserirInstituicaoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao cadastrar instituição"};
  }),

  on(actions.atualizarInstituicao, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.atualizarInstituicaoSuccess, (state, action) => {
    let itens: Instituicao[] = [...state.instituicoes].map(item => {
      if(item.id == action.atualizarInstituicao.instituicaoId) {
        let endereco: Endereco = new Endereco();
        endereco.bairro = action.atualizarInstituicao.bairro;
        endereco.cidadeId = action.atualizarInstituicao.cidadeId
        endereco.cidade = item.endereco?.cidade;
        endereco.id = item.endereco?.id;
        endereco.institucao = item.endereco?.institucao;
        endereco.logradouro = action.atualizarInstituicao.logradouro;
        endereco.numero = action.atualizarInstituicao.numero;
        
        let instituicao = {...item, 
            descricao: action.atualizarInstituicao.descricao,
            email: action.atualizarInstituicao.email,
            endereco: endereco,
            nome: action.atualizarInstituicao.nome,
            site: action.atualizarInstituicao.site
        }
        return instituicao;
      }
      return item;
    });
    return { 
      ...state, 
      instituicoes: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.atualizarInstituicaoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao atualizar instituição"};
  }),

  on(actions.excluirInstituicao, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.excluirInstituicaoSuccess, (state, action) => {
    let itens: Instituicao[] = [...state.instituicoes].filter(item => item.id != action.instituicaoId);
    return { 
      ...state, 
      instituicoes: itens,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.excluirInstituicaoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao excluir instituição"};
  }),
);
