import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Login } from 'src/app/shared/models/login';
import { ContaState, loginConta, selecionarConta } from 'src/app/store';
import { NotificacoesService } from '../../../shared/services/notificacoes.service';
import { UsuarioService } from '../../../shared/services/usuario.service';
import { AutocadastroComponent } from '../autocadastro';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //HU – Criar/logar conta
  // 1)	Não deve logar com campos inconsistentes.                                      OK
  // 2)	Deve ser possível clicar em cadastrar após ter campos consistentes.            OK
  // 3)	Deve ser possível criar conta.                                              OUTRA TELA
  // 4)	Não deve criar conta com campos inconsistentes.                             OUTRA TELA  
  // 5)	Deve ser possível cancelar.                                                    OK
  // 6)	Deve ser possível fechar a modal.                                              OK


  formLogin: FormGroup = null as any;

  conta$: Observable<ContaState>;

  login = new FormControl('', [Validators.required]);
  senha = new FormControl('', [Validators.required, Validators.minLength(8)]);
  hide = true;

  constructor(
    private usuarioService: UsuarioService,
    public dialogRef: MatDialogRef<LoginComponent>,
    private router: Router,
    public dialog: MatDialog,
    public store: Store,
    private notificacoesService: NotificacoesService
  ) {
    this.conta$ = this.store.select(selecionarConta);
  }

  public ngOnInit(): void {
    this.criarFormularioLogin(new Login());
  }

  criarFormularioLogin(login: Login) {
    this.formLogin = new FormGroup({
      login_usuario: new FormControl(login.email_usuario),
      senha_usuario: new FormControl(login.senha_usuario)
    })
  }

  logarPerfil() {
    if (this.verificarCampo(this.formLogin.get("login_usuario")?.value) || this.verificarCampo(this.formLogin.get("senha_usuario")?.value)) {
      this.notificacoesService.mostrarAviso('Deve preencher os dois campos para logar.');
    } else {
      let login: Login = new Login();
      login.email_usuario = this.formLogin.get("login_usuario")?.value;
      login.senha_usuario = this.formLogin.get("senha_usuario")?.value;
      this.store.dispatch(loginConta({ login: login }));
      this.formLogin.reset();
      this.conta$.subscribe(item => {
        if (item.token != "" && item.token != null) {
          this.usuarioService.autenticar(item!.token, item.usuarioId);
          this.notificacoesService.mostrarSucesso('Logado com sucesso!');
          this.fecharModal();
        }
        else {
          this.router.navigate(['']);
        }
      })
    }
  }

  telaCriarConta() {
    this.dialog.open(AutocadastroComponent, {
      maxHeight: '800px',
      height: 'auto',
      width: '70%',
    });
    this.dialogRef.close();
  }

  fecharModal() {
    this.dialogRef.close();
  }

  verificarCampo(campo: any) {
    if (campo == "" || campo == undefined || campo == null)
      return true;
    return false;
  }
}
