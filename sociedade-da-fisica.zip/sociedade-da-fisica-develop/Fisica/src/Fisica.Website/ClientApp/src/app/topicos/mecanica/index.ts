export * from './mecanica.component';
