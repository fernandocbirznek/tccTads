export class Segue {
  constructor(
    public id?: number,
    public usuarioId?: number,
    public professorId?: number,
    public professorNome?: string
  ) { }
}
