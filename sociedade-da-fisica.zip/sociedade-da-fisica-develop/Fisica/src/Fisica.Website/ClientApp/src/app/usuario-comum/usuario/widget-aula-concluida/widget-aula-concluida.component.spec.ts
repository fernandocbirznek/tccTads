import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WidgetAulaConcluidaComponent } from './widget-aula-concluida.component';

describe('WidgetAulaConcluidaComponent', () => {
  let component: WidgetAulaConcluidaComponent;
  let fixture: ComponentFixture<WidgetAulaConcluidaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WidgetAulaConcluidaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WidgetAulaConcluidaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
