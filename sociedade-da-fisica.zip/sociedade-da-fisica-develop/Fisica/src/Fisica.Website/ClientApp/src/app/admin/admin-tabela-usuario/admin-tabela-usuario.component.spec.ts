import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTabelaUsuarioComponent } from './admin-tabela-usuario.component';

describe('AdminTabelaUsuarioComponent', () => {
  let component: AdminTabelaUsuarioComponent;
  let fixture: ComponentFixture<AdminTabelaUsuarioComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminTabelaUsuarioComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminTabelaUsuarioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
