import { Action, createReducer, on } from '@ngrx/store';
import * as actions from '../actions/topico-forum.actions';
import { TopicoForum } from 'src/app/shared/models/topico-forum.model';
import { RespostaTopico } from 'src/app/shared/models/resposta-topico.model';
import { Replica } from 'src/app/shared';

export const topicoForumFeatureKey = 'topico-forum';

export interface TopicoForumState {
    topicoForum: TopicoForum;
    isSuccess: boolean;
    isLoading: boolean;
    isFailure: boolean;
    mensagem: string;
}

export const  topicoForumInitialState:  TopicoForumState = {
    topicoForum: null as any,
    isSuccess: false,
    isLoading: false,
    isFailure: false,
    mensagem: "",
};

export const topicoForumReducer = createReducer(
    topicoForumInitialState,

  on(actions.selecionarTopicoForum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarTopicoForumSuccess, (state, action) => {

    let item: TopicoForum = action.response;
    return { 
      ...state, 
      topicoForum: item,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.selecionarTopicoForumFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar tópico do fórum"};
  }),

  on(actions.atualizarTopicoForum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.atualizarTopicoForumSuccess, (state, action) => {

    let item: TopicoForum = {
      ...state.topicoForum,
      titulo: action.response.titulo,
      descricao: action.response.descricao
    };

    return { 
      ...state, 
      topicoForum: item,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.atualizarTopicoForumFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao atualizar tópico do fórum"};
  }),

  on(actions.inserirRespostaTopicoForum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.inserirRespostaTopicoSuccess, (state, action) => {
    let resposta: RespostaTopico = { 
      ...action.respostaTopico, 
      nomeUsuario: action.response.nomeUsuario,
      dataCadastro: action.response.dataCadastro,
      usuarioCadastroId: action.response.usuarioCadastroId
    }

    let topico: TopicoForum = { ...state.topicoForum,
      respostas: [ ...state.topicoForum.respostas!, resposta]
    }
    return { 
      ...state, 
      topicoForum: topico,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.inserirRespostaTopicoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao cadastrar resposta no tópico"};
  }),

  on(actions.atualizarRespostaTopico, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.atualizarRespostaTopicoSuccess, (state, action) => {
    let respostas = [...state.topicoForum.respostas!].map(item => {
      if(item.id == action.response.id) {
        let resposta = {
          ...item,
          descricao: action.response.descricao
        }
        return resposta;
      }
      return item;
    })

    let topicos: TopicoForum = {
      ...state.topicoForum,
      respostas: respostas
    }

    return { 
      ...state, 
      topicoForum: topicos,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.atualizarRespostaTopicoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao cadastrar resposta no tópico"};
  }),

  on(actions.excluirRespostaTopicoForum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.excluirRespostaTopicoSuccess, (state, action) => {
    let topico: TopicoForum = { ...state.topicoForum,
      respostas: state.topicoForum.respostas?.filter(item => item.id != action.excluirRespostaTopicoId)
    }
    return { 
      ...state, 
      topicoForum: topico,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.excluirRespostaTopicoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao excluir resposta no tópico"};
  }),

  on(actions.inserirReplicaTopicoForum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.inserirReplicaTopicoSuccess, (state, action) => {
    let respostas: RespostaTopico[] = [];

    state.topicoForum.respostas?.forEach(item => {
      if(item.id == action.replicaTopico.respostaTopicoId) {
        let resposta: RespostaTopico = { 
          ...item, 
          replicas: [...item.replicas!, action.response] ,
          dataCadastro: action.response.dataCadastro
        };
        respostas.push(resposta);
      } else {
        respostas.push(item);
      }
    })

    let topico: TopicoForum = { ...state.topicoForum,
      respostas: respostas
    }
    return { 
      ...state, 
      topicoForum: topico,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.inserirReplicaTopicoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao cadastrar replica no tópico"};
  }),

  on(actions.atualizarReplicaTopico, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.atualizarReplicaTopicoSuccess, (state, action) => {
    let respostas: RespostaTopico[] = [];

    state.topicoForum.respostas?.forEach(item => {
      if(item.id == action.response.respostaTopicoId) {
        let replicas: Replica[] = [];
        item.replicas?.forEach(itemReplica => {
          if(itemReplica.id == action.response.id) {
            let replica: Replica = {
              ...itemReplica,
              descricao: action.response.descricao
            }
            replicas.push(replica);
          } else {
            replicas.push(itemReplica);
          }
        })
        let resposta: RespostaTopico = { 
          ...item, 
          replicas: replicas,
        };
        respostas.push(resposta);
      } else {
        respostas.push(item);
      }
    })

    let topico: TopicoForum = { ...state.topicoForum,
      respostas: respostas
    }

    return { 
      ...state, 
      topicoForum: topico,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.atualizarReplicaTopicoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao cadastrar resposta no tópico"};
  }),

  on(actions.excluirReplicaTopicoForum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.excluirReplicaTopicoSuccess, (state, action) => {
    let respostas: RespostaTopico[] = [];
    state.topicoForum.respostas?.forEach(item => {
        let resposta: RespostaTopico = { 
          ...item, 
          replicas: item.replicas!.filter(item => item.id != action.excluirReplicaTopicoId)
        };
        respostas.push(resposta);
      }
    )

    let topico: TopicoForum = { ...state.topicoForum,
      respostas: respostas
    }

    return { 
      ...state, 
      topicoForum: topico,
      isLoading: false, 
      isSuccess: true, 
      isFailure: false, 
    };
  }),
  on(actions.excluirReplicaTopicoFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao excluir resposta no tópico"};
  }),
);
