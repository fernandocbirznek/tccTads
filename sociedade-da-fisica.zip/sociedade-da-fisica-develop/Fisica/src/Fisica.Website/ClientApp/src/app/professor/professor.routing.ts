import { Routes } from "@angular/router";
import { ProfessorPerfilComponent } from "./professor-perfil";

export const ProfessorRoutes: Routes = [
    { path: 'professor-perfil/:loginProfessor', component: ProfessorPerfilComponent }
];
