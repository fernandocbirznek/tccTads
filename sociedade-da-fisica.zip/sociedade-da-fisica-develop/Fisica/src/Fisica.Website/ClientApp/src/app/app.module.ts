import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { NgxMaskDirective, NgxMaskPipe, provideNgxMask } from 'ngx-mask';
import { environment } from 'src/environments/environment';
import { AdminModule } from './admin/admin.module';
import { MaterialModule } from './angular-material-modules';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing';
import { AulaModule } from './aula/aula.module';
import { ModalExcluirComponent, ToastComponent } from './components-genericos';
import { FooterComponent } from './footer';
import { HeaderComponent } from './header';
import { HomeComponent } from './home';
import { ProfessorModule } from './professor';
import { SharedModule } from './shared/shared.module';
import { 
  ContaModule, TemaForumModule, TopicoForumModule, AreaFisicaModule, NoticiaStateModule, UsuarioModule, InstituicaoModule, 
  CidadeEstadoStateModule, InformacaoSistemaModule
} from './store';
import { AulaStoreModule } from './store/aula';
import { TopicosModule } from './topicos/topicos.module';
import { UsuarioComumModule } from './usuario-comum/usuario-comum.module';
import { NoticiaModule } from './noticia';

import { KatexModule } from 'ng-katex';
import { CKEditorModule } from 'ckeditor4-angular';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FooterComponent,
    HeaderComponent,
    ToastComponent,
    ModalExcluirComponent,
  ],
  imports: [
    AreaFisicaModule,
    KatexModule,
    CKEditorModule,
    AulaModule,
    AulaStoreModule,
    NoticiaModule,
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    BrowserAnimationsModule,
    HttpClientModule,
    AdminModule,
    UsuarioComumModule,
    ProfessorModule,
    RouterModule,
    AppRoutingModule,
    SharedModule,
    FlexLayoutModule,
    MaterialModule,
    TopicosModule,
    MatDialogModule,
    ContaModule,
    TemaForumModule,
    TopicoForumModule,
    NoticiaStateModule,
    UsuarioModule,
    InstituicaoModule,
    CidadeEstadoStateModule,
    InformacaoSistemaModule,
    MatButtonModule,
    NgxMaskDirective, NgxMaskPipe,
    StoreModule.forRoot([]),
    EffectsModule.forRoot([]),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: environment.production }),
  ],
  providers: [provideNgxMask()],
  bootstrap: [AppComponent]
})
export class AppModule { }
