import { environment } from './../../../environments/environment';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { NotificacoesService } from '../services/notificacoes.service';
import { UsuarioService } from '../services/usuario.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToastComponent } from 'src/app/components-genericos';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

  constructor(
    private router: Router,
    private usuarioService: UsuarioService,
    private snackBar: MatSnackBar,
  ) { }

  public intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          this.handleError(error);
          return throwError(error);
        })
      );
  }

  private handleError(erro: HttpErrorResponse) {
    let mensagensErro: string[] = [];
    const body = (erro != null && erro != undefined) && typeof erro === 'object' ? JSON.parse(JSON.stringify(erro)) : erro;
    if (erro.status === Status.CONEXAO_RECUSADA) {
      mensagensErro.unshift('Servidor Indisponível');
    } else if (erro.status === Status.NAO_AUTORIZADO) {
      this.snackBar.openFromComponent(ToastComponent, {
        data: 'Não autorizado. Efetue o login antes de usar o sistema',
        duration: 5 * 1000,
        panelClass: 'css-toast',
        horizontalPosition: 'right',
        verticalPosition: 'top',
      });
      this.usuarioService.limparDados();
      this.router.navigate(['/login']);
      return;
    } else if (erro.status >= 400 && erro.status <= 500) {
      var error = body.error;
      if (typeof error === 'object' && Object.keys(error).length === 0) {
        if (Object.prototype.toString.call(erro.error) === '[object ArrayBuffer]') {
          const dec = new TextDecoder();
          error = dec.decode(erro.error);
          if (error.length >= 4) {
            error = error.substr(2, error.length - 4);
            if (!error) {
              mensagensErro.unshift("Erro inesperado");
            } else {
              if (error.indexOf(":") > -1)
                error = error.split(":")[1];
              mensagensErro.unshift(error);
            }
          } else {
            mensagensErro.unshift(error);
          }
        }
      } else {
        try {
          error = (error ? JSON.parse(error) : []);
          if (error.errors) {
            mensagensErro = error.errors;
          } else {
            if (error.length > 0) {
              mensagensErro.unshift(error);
            } else {
              mensagensErro.unshift(erro.statusText + " " + erro.url);
            }
          }
        } catch (e) {
          if (error) {
            mensagensErro.unshift(error);
          } else {
            mensagensErro.unshift('Erro ao tratar mensagens de erro');
          }
        }
      }
      if (erro.status === Status.ERRO_INTERNO_SERVIDOR) {
        mensagensErro.unshift('Erro interno no servidor');
      }
    } else {
      if (!environment.production) {
        if (erro.message.includes('Http failure during parsing')) {
          mensagensErro.unshift('Erro ao tentar converter resposta do servidor');
        } else {
          mensagensErro.unshift('Erro inesperado');
        }
      }
    }
    this.snackBar.openFromComponent(ToastComponent, {
      data: mensagensErro,
      duration: 5 * 1000,
      panelClass: 'css-toast',
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }
}

export enum Status {
  CONEXAO_RECUSADA = <number>0,
  ERRO_INTERNO_SERVIDOR = <number>500,
  NAO_AUTORIZADO = <number>401
}
