import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions/conta.actions';
import { UsuarioService } from 'src/app/shared/services/usuario.service';
import { Router } from '@angular/router';
import { WidgetService } from 'src/app/shared/services/widget.service';
import { Store } from '@ngrx/store';
import { FavoritoService } from 'src/app/shared/services/favorito.service';
import { SegueService } from 'src/app/shared/services/segue.service';



@Injectable()
export class ContaEffects {

  constructor(
    private actions$: Actions,
    private contaService: UsuarioService,
    private widgetService: WidgetService,
    private favoritoService: FavoritoService,
    private segueService: SegueService,
    private router: Router,
    public store: Store,
    ) 
  {}

  criarConta$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.autoCadastroConta),
      concatMap((action) =>
        this.contaService.autoCadastro(action.autocadastro).pipe(
          map(response => actions.autoCadastroContaSuccess({ autocadastro: action.autocadastro, response: response })),
          catchError(error => of(actions.autoCadastroContaFailure({ error }))))
      )
    );
  });

  loginConta$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.loginConta),
      concatMap((action) =>
        this.contaService.login(action.login.email_usuario, action.login.senha_usuario).pipe(
          map(response => {
            switch (response.tipoUsuario) {
              case 1:
                this.router.navigate([`perfil/${action.login.email_usuario}`]);
                break;
              case 2:
              case 3:
                this.router.navigate([`professor-perfil/${action.login.email_usuario}`]);
                break;
              case 4:
                this.router.navigate([`admin-perfil/${action.login.email_usuario}`]);
                break;
              default:
                this.router.navigate([``]);
                break;
            }
            
            return actions.loginContaSuccess({ login: action.login, response: response })
          }),
          catchError(response => of(actions.loginContaFailure({ response }))))
      )
    );
  });

  deslogarConta$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.deslogarConta),
      map(() => {
        this.contaService.logout();
        return actions.deslogarContaSuccess({ response: true });
      })
    );
  });

  selecionarInformacoesPerfil$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarInformacoesPerfil),
      concatMap((action) =>
        this.contaService.selecionarInformacoesPerfil(action.loginUsuario).pipe(
          map(response => actions.selecionarInformacoesPerfilSuccess({ loginUsuario: action.loginUsuario, response: response })),
          catchError(error => of(actions.selecionarInformacoesPerfilFailure({ error }))))
      )
    );
  });

  selecionarAulasWidget$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarWidgetAulas),
      concatMap(() =>
        this.widgetService.selecionarWigetsAulas().pipe(
          map(response => actions.selecionarWidgetAulasSuccess({ response: response })),
          catchError(error => of(actions.selecionarWidgetAulasFailure({ error }))))
      )
    );
  });

  selecionarProfessoresSegue$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarProfessorSegue),
      concatMap(() =>
        this.segueService.getProfessoresSegue().pipe(
          map(response => actions.selecionarProfessorSegueSuccess({ response: response })),
          catchError(error => of(actions.selecionarProfessorSegueFailure({ error }))))
      )
    );
  });

  selecionarAulasFavoritadas$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarAulasFavoritadas),
      concatMap(() =>
        this.favoritoService.selecionarFavoritos().pipe(
          map(response => actions.selecionarAulasFavoritadasSuccess({ response: response })),
          catchError(error => of(actions.selecionarAulasFavoritadasFailure({ error }))))
      )
    );
  });

  inserirAulaWidget$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.inserirAulaWidget),
      concatMap((action) =>
        this.widgetService.inserirAula(action.aula.id!, action.widget).pipe(
          map(response => actions.inserirAulaWidgetSuccess({ aula: action.aula, widget: action.widget })),
          catchError(error => of(actions.inserirAulaWidgetFailure({ error }))))
      )
    );
  });

  excluirAulaWidget$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.excluirAulaWidget),
      concatMap((action) =>
        this.widgetService.excluirAula(action.aulaId, action.widget).pipe(
          map(response => actions.excluirAulaWidgetSuccess({ aulaId: action.aulaId, widget: action.widget })),
          catchError(error => of(actions.excluirAulaWidgetFailure({ error }))))
      )
    );
  });

  excluirFavorito$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.excluirFavoritado),
      concatMap((action) =>
        this.favoritoService.removerFavorito(action.aulaId, action.sessaoAulaId).pipe(
          map(response => actions.excluirFavoritadoSuccess({ favoritoId: action.favoritoId, aulaId: action.aulaId, sessaoAulaId: action.sessaoAulaId })),
          catchError(error => of(actions.excluirFavoritadoFailure({ error }))))
      )
    );
  });

  atualizarAulaWidget$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.atualizarAulaWidget),
      concatMap((action) =>
        this.widgetService.excluirAula(action.aula.id!, action.widgetAntigo).pipe(
          map(response => {
            this.store.dispatch(actions.inserirAulaWidget({aula: action.aula, widget: action.widgetNovo}));
            return actions.excluirAulaWidgetSuccess({ aulaId: action.aula.id!, widget: action.widgetAntigo })
          }),
          catchError(error => of(actions.atualizarAulaWidgetFailure({ error }))))
      )
    );
  });
  
//   deletarConta$ = createEffect(() => {
//     return this.actions$.pipe( 
//       ofType(actions.deletarConta),
//       concatMap((action) =>
//         this.manipularContaService.deletarConta(action.email).pipe(
//           map(response => actions.deletarContaSuccess({ response: response })),
//           catchError(response => of(actions.deletarContaFailure({ response }))))
//       )
//     );
//   });

}
