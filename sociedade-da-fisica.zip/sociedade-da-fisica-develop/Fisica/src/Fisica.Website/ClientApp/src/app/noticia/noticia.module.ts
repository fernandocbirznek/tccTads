import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgSelectModule } from '@ng-select/ng-select';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MaterialModule } from '../angular-material-modules';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { StoreModule } from '@ngrx/store';
import { CadastroNoticiaComponent } from './cadastro-noticia';
import { NoticiaRoutes } from './noticia.routing';
import { AlterarNoticiaComponent } from './alterar-noticia/alterar-noticia.component';
import { VisualizarNoticiaComponent } from './visualizar-noticia/visualizar-noticia.component';
import { HomeNoticiaComponent } from './home-noticia/home-noticia.component';
import { GridNoticiasComponent } from './grid-noticias/grid-noticias.component';
import { CKEditorModule } from 'ckeditor4-angular';

@NgModule({
  declarations: [
    CadastroNoticiaComponent,
    AlterarNoticiaComponent,
    VisualizarNoticiaComponent,
    HomeNoticiaComponent,
    GridNoticiasComponent,
  ],
  imports: [
    CommonModule,
    CKEditorModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule, 
    RouterModule.forChild(NoticiaRoutes),
    NgSelectModule,
    FlexLayoutModule,
    MaterialModule,
    StoreModule,
    NgSelectModule
  ],
  exports: [
    HomeNoticiaComponent,
    GridNoticiasComponent
  ]
})
export class NoticiaModule { }
