import { RespostaTopico } from "./resposta-topico.model";

export class TopicoForum {
  constructor(
    public id?: number,
    public titulo?: string,
    public descricao?: string,
    public usuarioCadastro?: string,
    public usuarioCadastroId?: number,
    public usuarioCadastroLogin?: string,
    public dataCadastro?: Date,
    public forumId?: number,
    public respostas?: RespostaTopico[],
    public quantidadeRespostas?: number
  ) { }
}
