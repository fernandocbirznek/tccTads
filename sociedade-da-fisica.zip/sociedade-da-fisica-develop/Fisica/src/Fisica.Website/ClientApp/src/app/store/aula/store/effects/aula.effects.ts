import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions/aula.actions';
import { AulaService } from 'src/app/shared/services/aula.service';

@Injectable()
export class AulaEffects {

  constructor(
    private actions$: Actions,
    private aulaService: AulaService) 
  {}

  //selecionarAula$ = createEffect(() => {
  //  return this.actions$.pipe(
  //    ofType(actions.selecionarAula),
  //    concatMap((action) =>
  //      this.aulaService.selecioanarAula(action.aulaId).pipe(
  //        map(response => actions.selecionarAulaSuccess({ AulaId: action.aulaId, response: response })),
  //        catchError(error => of(actions.selecionarAulaFailure({ error }))))
  //    )
  //  );
  //});

  selecionarProfessorAulas$ = createEffect(() => {
   return this.actions$.pipe(
     ofType(actions.selecionarAulaByProfessorId),
     concatMap((action) =>
       this.aulaService.buscarAulasPorProfessorId().pipe(
         map(response => actions.selecionarAulaByProfessorIdSuccess({ response: response })),
         catchError(error => of(actions.selecionarAulaByProfessorIdFailure({ error }))))
     )
   );
  });

  inserirAula$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(actions.inserirAula),
      concatMap((action) =>
        this.aulaService.inserir(action.aula).pipe(
          map(response => actions.inserirAulaSuccess({ aula: action.aula, response: response })),
          catchError(error => of(actions.inserirAulaFailure({ error }))))
      )
    );
  });

  atualizarAula$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(actions.atualizarAula),
      concatMap((action) =>
        this.aulaService.atualizar(action.aula).pipe(
          map(response => actions.inserirAulaSuccess({ aula: action.aula, response: response })),
          catchError(error => of(actions.atualizarAulaFailure({ error }))))
      )
    );
  });

  excluirAula$ = createEffect(() => {
   return this.actions$.pipe( 
     ofType(actions.excluirAula),
     concatMap((action) =>
       this.aulaService.excluirAula(action.aulaId).pipe(
         map(response => actions.excluirAulaSuccess({ aulaId: action.aulaId })),
         catchError(error => of(actions.excluirAulaFailure({ error }))))
     )
   );
  });
}
