export class AtualizarInstituicaoCommand {
  constructor(
    public instituicaoId?: number,
    public nome?: string,
    public descricao?: string,
    public email?: string,
    public site?: string,
    public logradouro?: string,
    public bairro?: string,
    public numero?: number,
    public cidadeId?: number,
    public uF?: string
  ) { }
}
