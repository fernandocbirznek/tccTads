import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { InformacoesPerfil } from '../../../shared/models/informacoes-perfil.model';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';

import { 
    deslogarConta,
  selecionarAulasFavoritadas, selecionarConta, selecionarInformacoesPerfil, 
  selecionarLoginUsuario, selecionarNoticias, selecionarProfessorSegue, selecionarWidgetAulas 
} from 'src/app/store';


@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.component.html',
  styleUrls: ['./perfil.component.css']
})
export class PerfilComponent implements OnInit {

  // 1)	Deve carregar as Aulas marcadas como ‘favorita’.                                                         OK
  // 2)	Deve carregar as Aulas adicionadas a ‘Concluída’, ‘Cursando’ e ‘Para Cursar’ (Widget).                   OK
  // 3)	Deve carregar as notícias do feed.                                                                       OK
  // 4)	Acessar aulas do Widget.                                                                                 OK
  // 5)	Acessar aulas favoritadas.                                                                               OK
  // 6)	Deve carregar as notícias.                                                                               OK
  // 7)	Deve ser possível filtrar as notícias por ‘Apenas professores Seguidos’.                              ALTERADO
  // 8)	Deve filtrar as notícias pelo professor informado.                                                       OK
  // 9)	Deve ser possível limpar os filtros de pesquisa.                                                         OK
  // 10)	 Deve ser possível alterar perfil.
  // 11)	 Deve ser possível adicionar a aula no grupo “Para cursar”.                                            OK
  // 12)	 Deve ser possível adicionar a aula no grupo “Cursando”.                                               OK
  // 13)	 Deve ser possível adicionar a aula no grupo “Aula concluída”.                                         OK
  // 14)	 Remover aula de algum grupo do Widget.                                                                OK
  // 15)	 Remover a aula de favoritos.                                                                          OK
  // 16)	 Deve ser possível acessar uma notícias.                                                               OK

  //exibirLoading: boolean = true;

  stateUsuario$: Observable<any> = new Observable<any>();

  loginUsuario$: Observable<string> = new Observable<string>();
  loginUsuario: string = "";

  informacao: InformacoesPerfil = new InformacoesPerfil();
  srcFoto: string = "../../../../assets/img/default-avatar.png";

  selecionado: string = '0';

  constructor(
    private route: ActivatedRoute,
    public store: Store,
    public router: Router
  ) {
    this.store.dispatch(selecionarWidgetAulas());
    this.store.dispatch(selecionarNoticias());
    this.store.dispatch(selecionarAulasFavoritadas());
    this.store.dispatch(selecionarProfessorSegue());
  }

  public ngOnInit() {
    this.setupLoginUsuario();
    this.setupStateUsuario();
  }

  setupLoginUsuario() {
    this.loginUsuario$ = this.store.select(selecionarLoginUsuario);
    /*this.loginUsuario$.subscribe(item => {
      if(item != "")
        this.store.dispatch(selecionarInformacoesPerfil({ loginUsuario: item }));
    });*/

    let usu = this.route.snapshot.paramMap.get('loginUsuario')!;
  
    this.store.dispatch(selecionarInformacoesPerfil({ loginUsuario: usu }));
  }

  setupStateUsuario() {
    this.stateUsuario$ = this.store.select(selecionarConta);
    this.stateUsuario$.subscribe(item => {
      this.informacao = item.perfilInformacoes;
      //this.infos.perfil?.foto != null
    });
  }

  buscarFoto() {
    //TO-DO: Implementar a busca da foto
  }

  selecionou(item: string) {
    this.selecionado = item;
  }

  deslogar() {
    this.store.dispatch(deslogarConta());
    this.router.navigate(['']);
  }
}
