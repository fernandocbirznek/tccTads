import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forum-inicial',
  templateUrl: './forum-inicial.component.html',
  styleUrls: ['./forum-inicial.component.css']
})
export class ForumInicialComponent implements OnInit {
  
  //aparentemente tudo é estatico
  /**
   *	Deve carregar os temas padrões de fórum do sistema.                  OK
	 *  Deve ser possível clicar em algum dos temas em “Acessar”.            OK
	 *  Deve ser possível acessar o menu.                                    OK
   *  
   * */

  ngOnInit(): void {
  }

}
