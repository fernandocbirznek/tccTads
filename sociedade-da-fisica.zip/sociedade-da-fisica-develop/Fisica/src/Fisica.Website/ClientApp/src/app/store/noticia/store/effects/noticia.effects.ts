import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions/noticia.actions';
import { NoticiaService } from 'src/app/shared/services/noticia.service';

@Injectable()
export class NoticiaEffects {

  constructor(
    private actions$: Actions,
    private noticiaService: NoticiaService) 
  {}

  selecionarNoticia$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarNoticias),
      concatMap((action) =>
        this.noticiaService.getUltimasNoticias().pipe(
          map(response => actions.selecionarNoticiasSuccess({ response: response })),
          catchError(error => of(actions.selecionarNoticiasFailure({ error }))))
      )
    );
  });

  selecionarNoticiaById$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarNoticiaById),
      concatMap((action) =>
        this.noticiaService.getNoticiaById(action.noticiaId).pipe(
          map(response => actions.selecionarNoticiaByIdSuccess({ response: response })),
          catchError(error => of(actions.selecionarNoticiaByIdFailure({ error }))))
      )
    );
  });

  inserirNoticia$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.inserirNoticia),
      concatMap((action) =>
        this.noticiaService.inserir(action.noticia).pipe(
          map(response => actions.inserirNoticiaSuccess({ noticia: action.noticia, response: response })),
          catchError(error => of(actions.inserirNoticiaFailure({ error }))))
      )
    );
  });

  atualizarNoticia$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.atualizarNoticia),
      concatMap((action) =>
        this.noticiaService.atualizarNoticia(action.noticiaAlterar).pipe(
          map(response => actions.atualizarNoticiaSuccess({ noticiaAlterar: action.noticiaAlterar, response: response })),
          catchError(error => of(actions.atualizarNoticiaFailure({ error })))
        )
      )
    );
  });

  excluirNoticia$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.excluirNoticia),
      concatMap((action) =>
        this.noticiaService.excluirNoticia(action.noticiaId).pipe(
          map(response => actions.excluirNoticiaSuccess({ noticiaId: action.noticiaId, response: response })),
          catchError(error => of(actions.excluirNoticiaFailure({ error })))
        )
      )
    );
  });

}
