import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ToastComponent } from '../../components-genericos';

declare const $: any;

@Injectable()
export class NotificacoesService {

  constructor(
    private snackBar: MatSnackBar
  ) { }

  mostrarErros(mensagens: string[]) {
    for (var i = 0; i < mensagens.length; i++) {
      this.mostrarErro(mensagens[i]);
    }
  }

  public mostrarErro(mensagem: string) {
    this.snackBar.openFromComponent(ToastComponent, {
      data: mensagem,
      duration: 5 * 1000,
      panelClass: 'css-toast',
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }

  public mostrarSucesso(mensagem: string) {
    this.snackBar.openFromComponent(ToastComponent, {
      data: mensagem,
      duration: 5 * 1000,
      panelClass: 'css-toast',
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }

  public mostrarInformacao(mensagem: string) {
    this.snackBar.openFromComponent(ToastComponent, {
      data: mensagem,
      duration: 5 * 1000,
      panelClass: 'css-toast',
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }

  public mostrarAviso(mensagem: string) {
    this.snackBar.openFromComponent(ToastComponent, {
      data: mensagem,
      duration: 5 * 1000,
      panelClass: 'css-toast',
      horizontalPosition: 'right',
      verticalPosition: 'top',
    });
  }
}
