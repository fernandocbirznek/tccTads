import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Noticia } from 'src/app/shared';
import { getNoticias } from 'src/app/store';

@Component({
  selector: 'app-grid-noticias',
  templateUrl: './grid-noticias.component.html',
  styleUrls: ['./grid-noticias.component.css']
})
export class GridNoticiasComponent implements OnInit, AfterViewInit {

  displayedColumns: string[] = ['titulo', 'autor', 'data-postagem'];
  dataSource: any;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  noticias$: Observable<Noticia[]> = new Observable<Noticia[]>();

  constructor(
    public router: Router,
    public store: Store,
    private dialog: MatDialog,
  ) {
    this.noticias$ = this.store.select(getNoticias);
  }

  public ngOnInit() {
    this.noticias$.subscribe(noticias => {
      this.dataSource = new MatTableDataSource(noticias)
    });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  aplicarFiltro(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  criarNoticia() {
    this.router.navigate(['noticia/cadastro']);
  }

  acessarNoticia(item: any) {

  }
}
