export class UsuarioStateHelper {

    public static usuario(): any {
        let usuario: any = {
            usuarioId: parseInt(localStorage.getItem("uid")!),
            tipoUsuario: parseInt(localStorage.getItem("tipoUsuario")!),
            nomeUsuario: localStorage.getItem("nomeUsuario"),
            token: localStorage.getItem("TOKEN"),
            loginUsuario: localStorage.getItem("loginUsuario")
        }
        return usuario;
    }
  }