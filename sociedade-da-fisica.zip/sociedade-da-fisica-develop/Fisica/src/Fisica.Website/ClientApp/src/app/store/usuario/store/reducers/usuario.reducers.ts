import { createReducer, on } from '@ngrx/store';
import { Usuario } from 'src/app/shared';
import * as actions from '../actions/usuario.actions';

export const usuarioFeatureKey = 'usuario';

export interface UsuarioState {
  usuarioComum: Usuario[];
  usuarioProfessor: Usuario[];
  usuarioAdministrador: Usuario[];
  isSuccess: boolean;
  isLoading: boolean;
  isFailure: boolean;
  mensagem: string;
}

export const usuarioInitialState: UsuarioState = {
  usuarioComum: [],
  usuarioProfessor: [],
  usuarioAdministrador: [],
  isSuccess: false,
  isLoading: false,
  isFailure: false,
  mensagem: "",
};

export const usuarioReducer = createReducer(
  usuarioInitialState,

  on(actions.selecionarUsuarioComum, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarUsuarioComumSuccess, (state, action) => {
    let item: Usuario[] = action.response;
    return {
      ...state,
      usuarioComum: item,
      isLoading: false,
      isSuccess: true,
      isFailure: false,
    };
  }),
  on(actions.selecionarUsuarioComumFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar usuários comuns do sistema" };
  }),

  on(actions.selecionarUsuarioProfessor, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarUsuarioProfessorSuccess, (state, action) => {
    let item: Usuario[] = action.response;
    return {
      ...state,
      usuarioProfessor: item,
      isLoading: false,
      isSuccess: true,
      isFailure: false,
    };
  }),
  on(actions.selecionarUsuarioProfessorFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar usuários professores do sistema" };
  }),

  on(actions.selecionarUsuarioAdministrador, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.selecionarUsuarioAdministradorSuccess, (state, action) => {
    let item: Usuario[] = action.response;
    return {
      ...state,
      usuarioAdministrador: item,
      isLoading: false,
      isSuccess: true,
      isFailure: false,
    };
  }),
  on(actions.selecionarUsuarioAdministradorFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao buscar usuários administradores do sistema" };
  }),

  on(actions.atualizarUsuario, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.atualizarUsuarioSuccess, (state, action) => {
    let itens: Usuario[] = [];
    let usuarioComum: Usuario | undefined = state.usuarioComum.find(item => item.id == action.usuario.id);

    if (usuarioComum) {
      itens = [...state.usuarioComum].map(item => {
        if (item.id == action.usuario.id) {
          let usuario = {
            ...item
            //TODO, VERIFICAR O QUE VAI ATUALIZAR
          }
          return usuario;
        }
        return item;
      })
      return {
        ...state,
        usuarioComum: itens,
        isLoading: false,
        isSuccess: true,
        isFailure: false,
      };
    } else {
      let usuarioProfessor: Usuario | undefined = state.usuarioProfessor.find(item => item.id == action.usuario.id);
      if (usuarioProfessor) {
        itens = [...state.usuarioProfessor].map(item => {
          if (item.id == action.usuario.id) {
            let usuario = {
              ...item
              //TODO, VERIFICAR O QUE VAI ATUALIZAR
            }
            return usuario;
          }
          return item;
        })
      }
      return {
        ...state,
        usuarioProfessor: itens,
        isLoading: false,
        isSuccess: true,
        isFailure: false,
      };
    }
  }),
  on(actions.atualizarUsuarioFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao atualizar usuário do sistema" };
  }),

  on(actions.inserirUsuario, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.inserirUsuarioSuccess, (state, action) => {
    let itens: Usuario[] = [];
    if (action.usuario.tipoUsuario == 1) {
      let usuario = {
        ...action.usuario,
        dataCadastro: action.response.dataCadastro,
      }
      itens = [...state.usuarioComum, usuario];
      return {
        ...state,
        usuarioComum: itens,
        isLoading: false,
        isSuccess: true,
        isFailure: false,
      };
    }
    if (action.usuario.tipoUsuario == 2) {
      let usuario = {
        ...action.usuario,
        dataCadastro: action.response.dataCadastro,
      }
      itens = [...state.usuarioProfessor, usuario];
      return {
        ...state,
        usuarioProfessor: itens,
        isLoading: false,
        isSuccess: true,
        isFailure: false,
      };
    }
    return {
      ...state,
      isLoading: false,
      isSuccess: true,
      isFailure: false,
    };
  }),
  on(actions.inserirUsuarioFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao cadastrar usuário no sistema" };
  }),

  on(actions.excluirUsuario, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.excluirUsuarioSuccess, (state, action) => {
    let itens: Usuario[] = [];

    let usuarioComum: Usuario | undefined = state.usuarioComum.find(item => item.id == action.usuarioId);

    if (usuarioComum) {
      itens = state.usuarioComum.filter(item => item.id != action.usuarioId);
      return {
        ...state,
        usuarioComum: itens,
        isLoading: false,
        isSuccess: true,
        isFailure: false,
      };
    } else {
      let usuarioProfessor: Usuario | undefined = state.usuarioProfessor.find(item => item.id == action.usuarioId);
      if (usuarioProfessor) {
        itens = state.usuarioProfessor.filter(item => item.id != action.usuarioId);
        return {
          ...state,
          usuarioProfessor: itens,
          isLoading: false,
          isSuccess: true,
          isFailure: false,
        };
      }
    }
    return {
      ...state,
      isLoading: false,
      isSuccess: true,
      isFailure: false,
    };
  }),
  on(actions.excluirUsuarioFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao excluir usuário do sistema" };
  }),

  on(actions.atualizarTipoUsuario, state => {
    return { ...state, isLoading: true, isSuccess: false, isFailure: false, error: "" };
  }),
  on(actions.atualizarTipoUsuarioSuccess, (state, action) => {
    let usuarioAlterado: Usuario | undefined = state.usuarioComum.find(item => item.id == action.atualizarTipoUsuario.id);

    if (usuarioAlterado == undefined)
      usuarioAlterado = state.usuarioProfessor.find(item => item.id == action.atualizarTipoUsuario.id);

    let tipoUsuario = action.atualizarTipoUsuario.tipoUsuario;

    const novoUsuario = { ...usuarioAlterado };

    novoUsuario!.tipoUsuario = tipoUsuario;

    let comuns: Usuario[] = state.usuarioComum.filter(item => item.id != action.atualizarTipoUsuario.id);
    let professores: Usuario[] = state.usuarioProfessor.filter(item => item.id != action.atualizarTipoUsuario.id);;

    if (tipoUsuario == 1) {
      comuns = [...comuns, novoUsuario];

    } else if (tipoUsuario == 2 || tipoUsuario == 3) {
      professores = [...professores, novoUsuario];
    }

    return {
      ...state,
      usuarioComum: comuns,
      usuarioProfessor: professores,
      isLoading: false,
      isSuccess: true,
      isFailure: false,
    };
  }),
  on(actions.atualizarTipoUsuarioFailure, (state, action) => {
    return { ...state, isLoading: false, isSuccess: false, isFailure: true, mensagem: "Erro ao atualizar usuário do sistema" };
  }),
);
