import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, concatMap } from 'rxjs/operators';
import { of } from 'rxjs';

import * as actions from '../actions/cidade-estado.actions';
import { CidadeService } from 'src/app/shared/services/cidade.service';

@Injectable()
export class CidadeEstadoEffects {

  constructor(
    private actions$: Actions,
    private cidadeService: CidadeService) 
  {}

  selecionarCidade$ = createEffect(() => {
    return this.actions$.pipe( 
      ofType(actions.selecionarCidades),
      concatMap(() =>
        this.cidadeService.BuscarCidades().pipe(
          map(response => actions.selecionarCidadesSuccess({ response: response })),
          catchError(error => of(actions.selecionarCidadesFailure({ error }))))
      )
    );
  });

}
