export class Replica {
  constructor(
    public id?: number,
    public descricao?: string,
    public dataCadastro?: Date,
    public nomeUsuario?: string,
    public usuarioCadastroId?: number,
    public usuarioCadastroLogin?: string,
    public respostaTopicoId?: number
  ) { }
}
