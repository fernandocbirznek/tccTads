import { createAction, props } from '@ngrx/store';
import { Replica } from 'src/app/shared/models/replica.model';
import { RespostaTopico } from 'src/app/shared/models/resposta-topico.model';
import { TopicoForum } from 'src/app/shared/models/topico-forum.model';

export const selecionarTopicoForum = createAction(
  '[TopicoForum] selecionarTopicoForum',
  props<{ topicoForumId: number }>()
);

export const selecionarTopicoForumSuccess = createAction(
  '[TopicoForum] selecionarTopicoForum Success',
  props<{ topicoForumId: number, response: TopicoForum }>()
);

export const selecionarTopicoForumFailure = createAction(
  '[TopicoForum] selecionarTopicoForum Failure',
  props<{ error: any }>()
);

export const atualizarTopicoForum = createAction(
  '[TopicoForum] atualizarTopicoForum',
  props<{ topicoForum: TopicoForum }>()
);

export const atualizarTopicoForumSuccess = createAction(
  '[TopicoForum] atualizarTopicoForum Success',
  props<{ topicoForum: TopicoForum, response: TopicoForum }>()
);

export const atualizarTopicoForumFailure = createAction(
  '[TopicoForum] atualizarTopicoForum Failure',
  props<{ error: any }>()
);

export const inserirRespostaTopicoForum = createAction(
  '[RespostaTopicoForum] inserirRespostaTopico',
  props<{ respostaTopico: RespostaTopico }>()
);

export const inserirRespostaTopicoSuccess = createAction(
  '[RespostaTopicoForum] inserirRespostaTopico Success',
  props<{ respostaTopico: RespostaTopico, response: any }>()
);

export const inserirRespostaTopicoFailure = createAction(
  '[RespostaTopicoForum] inserirRespostaTopico Failure',
  props<{ error: any }>()
);

export const atualizarRespostaTopico = createAction(
  '[RespostaTopicoForum] atualizarRespostaTopico',
  props<{ atualizarRespostaTopico: RespostaTopico }>()
);

export const atualizarRespostaTopicoSuccess = createAction(
  '[RespostaTopicoForum] atualizarRespostaTopico Success',
  props<{ atualizarRespostaTopico: RespostaTopico, response: any }>()
);

export const atualizarRespostaTopicoFailure = createAction(
  '[RespostaTopicoForum] atualizarRespostaTopico Failure',
  props<{ error: any }>()
);

export const excluirRespostaTopicoForum = createAction(
  '[RespostaTopicoForum] excluirRespostaTopico',
  props<{ excluirRespostaTopicoId: number }>()
);

export const excluirRespostaTopicoSuccess = createAction(
  '[RespostaTopicoForum] excluirRespostaTopico Success',
  props<{ excluirRespostaTopicoId: number }>()
);

export const excluirRespostaTopicoFailure = createAction(
  '[RespostaTopicoForum] excluirRespostaTopico Failure',
  props<{ error: any }>()
);

export const inserirReplicaTopicoForum = createAction(
  '[ReplicaTopicoForum] inserirReplicaTopico',
  props<{ replicaTopico: Replica }>()
);

export const inserirReplicaTopicoSuccess = createAction(
  '[ReplicaTopicoForum] inserirReplicaTopico Success',
  props<{ replicaTopico: Replica, response: any }>()
);

export const inserirReplicaTopicoFailure = createAction(
  '[ReplicaTopicoForum] inserirReplicaTopico Failure',
  props<{ error: any }>()
);

export const atualizarReplicaTopico = createAction(
  '[RespostaTopicoForum] atualizarReplicaTopico',
  props<{ atualizarReplicaTopico: Replica }>()
);

export const atualizarReplicaTopicoSuccess = createAction(
  '[RespostaTopicoForum] atualizarReplicaTopico Success',
  props<{ atualizarReplicaTopico: Replica, response: any }>()
);

export const atualizarReplicaTopicoFailure = createAction(
  '[RespostaTopicoForum] atualizarReplicaTopico Failure',
  props<{ error: any }>()
);

export const excluirReplicaTopicoForum = createAction(
  '[RespostaTopicoForum] excluirReplicaTopico',
  props<{ excluirReplicaTopicoId: number, topicoForumId: number }>()
);

export const excluirReplicaTopicoSuccess = createAction(
  '[RespostaTopicoForum] excluirReplicaTopico Success',
  props<{ excluirReplicaTopicoId: number, topicoForumId: number }>()
);

export const excluirReplicaTopicoFailure = createAction(
  '[RespostaTopicoForum] excluirReplicaTopico Failure',
  props<{ error: any }>()
);